/**
 * Trang Airport Loy Krathong 2026 - Perspective River View
 * Features:
 * 1. Realistic River Water Simulation, Moonlight Reflection Trail & Krathong Light Reflections (Canvas)
 * 2. Celebratory Fireworks Engine (Sky Canvas with Web Audio FX)
 * 3. Skyline of Thai Temples & City Buildings with Illuminated Windows
 * 4. Real-time SSE Stream, Dynamic QR Code & 2.5D Slow Perspective Drift
 */

(() => {
  // DOM Elements
  const scenicSky = document.getElementById('scenicSky');
  const scenicMoon = document.getElementById('scenicMoon');
  const riverStage = document.getElementById('riverStage');
  const krathongsRiverLayer = document.getElementById('krathongsRiverLayer');
  const effectsLayer = document.getElementById('effectsLayer');
  const starsLayer = document.getElementById('starsLayer');
  const lanternsContainer = document.getElementById('lanternsContainer');
  const krCountEl = document.getElementById('krCount');
  const newToast = document.getElementById('newToast');
  const toastSender = document.getElementById('toastSender');
  const toastWish = document.getElementById('toastWish');

  // Canvases
  const riverCanvas = document.getElementById('riverCanvas');
  const riverCtx = riverCanvas.getContext('2d');
  const fireworksCanvas = document.getElementById('fireworksCanvas');
  const fwCtx = fireworksCanvas.getContext('2d');

  // Controls & QR
  const qrCard = document.getElementById('qrCard');
  const qrToggleBtn = document.getElementById('qrToggleBtn');
  const qrUrlBox = document.getElementById('qrUrlBox');
  const qrSubtitle = document.getElementById('qrSubtitle');
  const qrcodeContainer = document.getElementById('qrcode');
  const btnModePublic = document.getElementById('btnModePublic');
  const btnModeLocal = document.getElementById('btnModeLocal');
  const btnAudio = document.getElementById('btnAudio');
  const btnFireworks = document.getElementById('btnFireworks');
  const btnFullscreen = document.getElementById('btnFullscreen');
  const btnSimulate = document.getElementById('btnSimulate');
  const btnPhysics = document.getElementById('btnPhysics');

  // Feature Flag: 2.5D Water Collision Physics (Toggable Anytime)
  let ENABLE_COLLISION_PHYSICS = true;

  // Modal Detail
  const krModalBackdrop = document.getElementById('krModalBackdrop');
  const krDetailModal = document.getElementById('krDetailModal');
  const krModalClose = document.getElementById('krModalClose');
  const modalKrImg = document.getElementById('modalKrImg');
  const modalSender = document.getElementById('modalSender');
  const modalType = document.getElementById('modalType');
  const modalTime = document.getElementById('modalTime');
  const modalWish = document.getElementById('modalWish');

  // Krathong Types Meta (Pristine Transparent Cutout PNGs)
  const KR_TYPES = {
    royal: { title: 'ราชพฤกษ์ทอง', image: 'assets/images/royal.png' },
    minimal: { title: 'บัวมินิมัล', image: 'assets/images/minimal.png' },
    lotus: { title: 'บัวจันทร์', image: 'assets/images/lotus.png' },
    marigold: { title: 'มณีบุปผา', image: 'assets/images/marigold.png' },
    eco: { title: 'ธาราธรรมชาติ', image: 'assets/images/eco.png' },
    bread: { title: 'ขนมปังนำโชค', image: 'assets/images/bread.png' },
    airplane: { title: 'เวหานำโชค', image: 'assets/images/airplane.png' },
    dugong: { title: 'พะยูนธารา', image: 'assets/images/dugong.png' }
  };

  // State
  const krathongsMap = new Map(); // id -> RiverKrathong
  let audioEnabled = false;
  let audioCtx = null;
  let activeMode = 'public';
  let currentPublicUrl = '';
  let currentLocalUrl = '';

  // Resize Canvases
  let skyWidth = 0, skyHeight = 0;
  let rWidth = 0, rHeight = 0;

  function resizeCanvases() {
    if (scenicSky && fireworksCanvas) {
      skyWidth = scenicSky.clientWidth || window.innerWidth;
      skyHeight = scenicSky.clientHeight || (window.innerHeight * 0.52);
      fireworksCanvas.width = skyWidth;
      fireworksCanvas.height = skyHeight;
    }
    if (riverStage && riverCanvas) {
      rWidth = riverStage.clientWidth || window.innerWidth;
      rHeight = riverStage.clientHeight || (window.innerHeight * 0.5);
      riverCanvas.width = rWidth;
      riverCanvas.height = rHeight;
    }
  }

  window.addEventListener('resize', resizeCanvases);
  resizeCanvases();

  // ================= 1. Background Environment (Stars & Lanterns) =================
  function initStars() {
    if (!starsLayer) return;
    const count = 65;
    for (let i = 0; i < count; i++) {
      const star = document.createElement('div');
      star.className = 'star';
      const size = Math.random() < 0.2 ? 2.5 : (Math.random() < 0.6 ? 1.8 : 1.2);
      star.style.width = `${size}px`;
      star.style.height = `${size}px`;
      star.style.left = `${Math.random() * 100}%`;
      star.style.top = `${Math.random() * 95}%`;
      star.style.setProperty('--duration', `${2 + Math.random() * 3.5}s`);
      star.style.animationDelay = `${Math.random() * 3}s`;
      starsLayer.appendChild(star);
    }
  }

  function initLanterns() {
    if (!lanternsContainer) return;
    const count = 12;
    for (let i = 0; i < count; i++) {
      const lantern = document.createElement('div');
      lantern.className = 'lantern';
      lantern.style.left = `${5 + Math.random() * 90}%`;
      const speed = 18 + Math.random() * 16;
      lantern.style.setProperty('--speed', `${speed}s`);
      lantern.style.setProperty('--drift-x', `${(Math.random() - 0.5) * 80}px`);
      lantern.style.animationDelay = `${Math.random() * speed}s`;
      lanternsContainer.appendChild(lantern);
    }
  }

  // ================= 1.2 Moon Water Sparkles Pool (ประกายระยิบระยับผิวน้ำกระทบแสงจันทร์) =================
  const MOON_SPARKLE_COUNT = 90;
  const moonSparkles = [];
  function initMoonSparkles() {
    moonSparkles.length = 0;
    for (let i = 0; i < MOON_SPARKLE_COUNT; i++) {
      moonSparkles.push({
        depth: 0.03 + Math.random() * 0.95, // 0 (horizon) to 1 (foreground)
        offsetNorm: (Math.random() + Math.random() - 1), // Gaussian-like bell distribution (-1 to 1)
        baseSize: 1.0 + Math.random() * 1.8,
        twinklePhase: Math.random() * Math.PI * 2,
        twinkleSpeed: 0.003 + Math.random() * 0.005
      });
    }
  }

  // ================= 1.3 Flowing River Micro-Wavelets (ริ้วคลื่นน้ำระลอกสลับฟันปลาไหลเอื่อยๆ ทั่วลำน้ำ) =================
  const RIVER_WAVELET_COUNT = 64;
  const riverMicroWavelets = [];
  function initRiverMicroWavelets() {
    riverMicroWavelets.length = 0;
    for (let i = 0; i < RIVER_WAVELET_COUNT; i++) {
      const depth = 0.04 + Math.random() * 0.94; // 0 (horizon) to 1 (foreground)
      riverMicroWavelets.push({
        xNorm: Math.random(), // 0 to 1
        depth: depth,
        baseLength: 35 + Math.random() * 50, // base pixel length
        phase: Math.random() * Math.PI * 2,
        wobbleSpeed: 0.002 + Math.random() * 0.0025,
        driftSpeed: (0.00003 + depth * 0.00007) * (0.8 + Math.random() * 0.4), // flows gently downstream
        curveAmp: 1.2 + Math.random() * 1.6,
        colorTone: Math.random() < 0.55 ? 'cyan' : (Math.random() < 0.8 ? 'gold' : 'jade')
      });
    }
  }

  // ================= 2. Web Audio Sound Engine =================
  function initAudio() {
    if (!audioCtx) {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      audioCtx = new AudioContext();
    }
    if (audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
  }

  function playLandingChime() {
    if (!audioEnabled || !audioCtx) return;
    try {
      const now = audioCtx.currentTime;

      // Soft water splash
      const bufferSize = audioCtx.sampleRate * 0.45;
      const buffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
      const output = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        output[i] = (Math.random() * 2 - 1) * Math.exp(-i / (audioCtx.sampleRate * 0.12));
      }
      const noise = audioCtx.createBufferSource();
      noise.buffer = buffer;
      const noiseFilter = audioCtx.createBiquadFilter();
      noiseFilter.type = 'lowpass';
      noiseFilter.frequency.setValueAtTime(800, now);

      const noiseGain = audioCtx.createGain();
      noiseGain.gain.setValueAtTime(0.08, now);
      noiseGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.45);

      noise.connect(noiseFilter);
      noiseFilter.connect(noiseGain);
      noiseGain.connect(audioCtx.destination);
      noise.start(now);

      // Tibetan singing bowl bell chime
      const freqs = [528, 792, 1056];
      freqs.forEach((freq, idx) => {
        const osc = audioCtx.createOscillator();
        const oscGain = audioCtx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + idx * 0.08);

        oscGain.gain.setValueAtTime(0.12 / (idx + 1), now + idx * 0.08);
        oscGain.gain.exponentialRampToValueAtTime(0.0001, now + 2.2);

        osc.connect(oscGain);
        oscGain.connect(audioCtx.destination);
        osc.start(now + idx * 0.08);
        osc.stop(now + 2.4);
      });
    } catch (e) {
      console.warn('Audio play error:', e);
    }
  }

  function playFireworkSound() {
    if (!audioEnabled || !audioCtx) return;
    try {
      const now = audioCtx.currentTime;
      const osc = audioCtx.createOscillator();
      const oscGain = audioCtx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(140, now);
      osc.frequency.exponentialRampToValueAtTime(35, now + 0.45);

      oscGain.gain.setValueAtTime(0.18, now);
      oscGain.gain.exponentialRampToValueAtTime(0.001, now + 0.5);

      osc.connect(oscGain);
      oscGain.connect(audioCtx.destination);
      osc.start(now);
      osc.stop(now + 0.55);

      const bufferSize = audioCtx.sampleRate * 0.6;
      const buffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = (Math.random() < 0.08 ? (Math.random() * 2 - 1) : 0) * Math.exp(-i / (audioCtx.sampleRate * 0.2));
      }
      const crackle = audioCtx.createBufferSource();
      crackle.buffer = buffer;
      const cGain = audioCtx.createGain();
      cGain.gain.setValueAtTime(0.06, now + 0.08);
      cGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.7);

      crackle.connect(cGain);
      cGain.connect(audioCtx.destination);
      crackle.start(now + 0.08);
    } catch (e) {
      console.warn('Firework audio error:', e);
    }
  }

  // Soft harmonious chimes for Live Reactions from mobile
  function playHeartChime() {
    if (!audioEnabled || !audioCtx) return;
    try {
      const now = audioCtx.currentTime;
      [523.25, 659.25, 783.99, 1046.50].forEach((freq, idx) => { // C5, E5, G5, C6
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, now + idx * 0.05);

        gain.gain.setValueAtTime(0, now + idx * 0.05);
        gain.gain.linearRampToValueAtTime(0.09, now + idx * 0.05 + 0.02);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + idx * 0.05 + 0.55);

        osc.connect(gain);
        gain.connect(audioCtx.destination);

        osc.start(now + idx * 0.05);
        osc.stop(now + idx * 0.05 + 0.6);
      });
    } catch (e) {}
  }

  function playSparkleChime() {
    if (!audioEnabled || !audioCtx) return;
    try {
      const now = audioCtx.currentTime;
      [1318.51, 1567.98, 1975.53, 2637.02].forEach((freq, idx) => { // E6, G6, B6, E7
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + idx * 0.04);

        gain.gain.setValueAtTime(0, now + idx * 0.04);
        gain.gain.linearRampToValueAtTime(0.07, now + idx * 0.04 + 0.015);
        gain.gain.exponentialRampToValueAtTime(0.0001, now + idx * 0.04 + 0.45);

        osc.connect(gain);
        gain.connect(audioCtx.destination);

        osc.start(now + idx * 0.04);
        osc.stop(now + idx * 0.04 + 0.5);
      });
    } catch (e) {}
  }

  function playBubblePopSound() {
    if (!audioEnabled || !audioCtx) return;
    try {
      const now = audioCtx.currentTime;
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(650 + Math.random() * 200, now);
      osc.frequency.exponentialRampToValueAtTime(1400 + Math.random() * 300, now + 0.05);

      gain.gain.setValueAtTime(0.025, now);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.07);

      osc.connect(gain);
      gain.connect(audioCtx.destination);

      osc.start(now);
      osc.stop(now + 0.08);
    } catch (e) {}
  }

  // ================= 3. Fireworks Engine =================
  const fireworks = [];
  const activeRiverFlashes = [];

  function hexToRgba(hex, alpha) {
    if (!hex) return `rgba(255,255,255,${alpha})`;
    let c = hex.replace('#', '');
    if (c.length === 3) c = c.split('').map(x => x + x).join('');
    const num = parseInt(c, 16);
    return `rgba(${(num >> 16) & 255}, ${(num >> 8) & 255}, ${num & 255}, ${Math.max(0, Math.min(1, alpha)).toFixed(3)})`;
  }

  const FW_COLORS = [
    { name: 'gold', primary: '#ffeaa7', glow: '#fdcb6e' },
    { name: 'ruby', primary: '#ff7675', glow: '#d63031' },
    { name: 'emerald', primary: '#55efc4', glow: '#00b894' },
    { name: 'sapphire', primary: '#74b9ff', glow: '#0984e3' },
    { name: 'orchid', primary: '#fd79a8', glow: '#e84393' },
    { name: 'amethyst', primary: '#a29bfe', glow: '#6c5ce7' },
    { name: 'diamond', primary: '#ffffff', glow: '#dfe6e9' }
  ];

  class FireworkRocket {
    constructor(startX, startY, targetX, targetY, color, pattern = 'peony') {
      this.x = startX;
      this.y = startY;
      this.targetX = targetX;
      this.targetY = targetY;
      this.color = color;
      this.pattern = pattern;
      this.speed = 4.4 + Math.random() * 1.8;
      const angle = Math.atan2(targetY - startY, targetX - startX);
      this.vx = Math.cos(angle) * this.speed;
      this.vy = Math.sin(angle) * this.speed;
      this.trail = [];
      this.exploded = false;
    }

    update() {
      this.trail.push({ x: this.x, y: this.y, alpha: 0.8 });
      if (this.trail.length > 8) this.trail.shift();

      this.x += this.vx;
      this.y += this.vy;

      if (this.vy < 0 && this.y <= this.targetY) {
        this.explode();
      }
    }

    explode() {
      this.exploded = true;
      playFireworkSound();

      // Trigger dynamic water reflection flash
      activeRiverFlashes.push({
        normX: this.x / Math.max(1, skyWidth),
        color: this.color.primary,
        glow: this.color.glow,
        alpha: 0.65,
        decay: 0.024
      });

      if (this.pattern === 'willow') {
        // Golden/Silver Weeping Willow Cascade
        const count = 75;
        for (let i = 0; i < count; i++) {
          fireworks.push(new WillowParticle(this.x, this.y, this.color));
        }
      } else if (this.pattern === 'ring') {
        // Ring Pattern
        const count = 48;
        const radiusSpeed = 2.8 + Math.random() * 0.8;
        for (let i = 0; i < count; i++) {
          const angle = (i / count) * Math.PI * 2;
          fireworks.push(new RingParticle(this.x, this.y, this.color, angle, radiusSpeed));
        }
        for (let j = 0; j < 15; j++) {
          fireworks.push(new FireworkParticle(this.x, this.y, { primary: '#ffffff', glow: this.color.glow }));
        }
      } else {
        // Classic Peony Sphere Burst
        const count = 65 + Math.floor(Math.random() * 25);
        for (let i = 0; i < count; i++) {
          fireworks.push(new FireworkParticle(this.x, this.y, this.color));
        }
      }
    }

    draw(ctx) {
      ctx.save();
      for (let i = 0; i < this.trail.length; i++) {
        const pt = this.trail[i];
        const alpha = (i / this.trail.length) * 0.8;
        ctx.fillStyle = `rgba(255, 230, 150, ${alpha})`;
        ctx.beginPath();
        ctx.arc(pt.x, pt.y, 1.8, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(this.x, this.y, 2.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  }

  class FireworkParticle {
    constructor(x, y, color) {
      this.x = x;
      this.y = y;
      this.color = color;
      const angle = Math.random() * Math.PI * 2;
      const speed = 1.2 + Math.random() * 4.5;
      this.vx = Math.cos(angle) * speed;
      this.vy = Math.sin(angle) * speed;
      this.friction = 0.955;
      this.gravity = 0.055;
      this.alpha = 1.0;
      this.decay = 0.012 + Math.random() * 0.014;
      this.radius = 1.6 + Math.random() * 1.6;
    }

    update() {
      this.vx *= this.friction;
      this.vy *= this.friction;
      this.vy += this.gravity;
      this.x += this.vx;
      this.y += this.vy;
      this.alpha -= this.decay;
    }

    draw(ctx) {
      if (this.alpha <= 0) return;
      ctx.save();
      ctx.globalAlpha = Math.max(0, this.alpha);

      ctx.fillStyle = this.color.primary;
      ctx.shadowColor = this.color.glow;
      ctx.shadowBlur = 6;
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
      ctx.fill();

      if (Math.random() < 0.25) {
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius * 0.6, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    }
  }

  class WillowParticle {
    constructor(x, y, color) {
      this.x = x;
      this.y = y;
      this.color = color;
      const angle = Math.random() * Math.PI * 2;
      const speed = 0.6 + Math.random() * 2.8;
      this.vx = Math.cos(angle) * speed;
      this.vy = Math.sin(angle) * speed - 0.5;
      this.friction = 0.965;
      this.gravity = 0.045;
      this.alpha = 1.0;
      this.decay = 0.007 + Math.random() * 0.006;
      this.radius = 1.8 + Math.random() * 1.4;
      this.trail = [];
    }

    update() {
      this.trail.push({ x: this.x, y: this.y, alpha: this.alpha });
      if (this.trail.length > 6) this.trail.shift();

      this.vx *= this.friction;
      this.vy *= this.friction;
      this.vy += this.gravity;
      this.x += this.vx;
      this.y += this.vy;
      this.alpha -= this.decay;
    }

    draw(ctx) {
      if (this.alpha <= 0) return;
      ctx.save();
      for (let i = 0; i < this.trail.length; i++) {
        const pt = this.trail[i];
        const tAlpha = (i / this.trail.length) * this.alpha * 0.6;
        ctx.fillStyle = hexToRgba(this.color.primary, tAlpha);
        ctx.beginPath();
        ctx.arc(pt.x, pt.y, this.radius * 0.7, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.globalAlpha = Math.max(0, this.alpha);
      ctx.fillStyle = Math.random() < 0.3 ? '#ffffff' : this.color.primary;
      ctx.shadowColor = this.color.glow;
      ctx.shadowBlur = 6;
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  }

  class RingParticle {
    constructor(x, y, color, angle, speed) {
      this.x = x;
      this.y = y;
      this.color = color;
      this.vx = Math.cos(angle) * speed;
      this.vy = Math.sin(angle) * speed;
      this.friction = 0.96;
      this.gravity = 0.038;
      this.alpha = 1.0;
      this.decay = 0.011 + Math.random() * 0.008;
      this.radius = 2.0;
    }

    update() {
      this.vx *= this.friction;
      this.vy *= this.friction;
      this.vy += this.gravity;
      this.x += this.vx;
      this.y += this.vy;
      this.alpha -= this.decay;
    }

    draw(ctx) {
      if (this.alpha <= 0) return;
      ctx.save();
      ctx.globalAlpha = Math.max(0, this.alpha);
      ctx.fillStyle = this.color.primary;
      ctx.shadowColor = this.color.glow;
      ctx.shadowBlur = 7;
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  }

  function launchFirework(startX, targetX, targetY, pattern) {
    if (!skyWidth || !skyHeight) resizeCanvases();
    const sx = startX ?? (skyWidth * (0.15 + Math.random() * 0.7));
    const sy = skyHeight + 10;
    const tx = targetX ?? (sx + (Math.random() - 0.5) * 120);
    const ty = targetY ?? (skyHeight * (0.12 + Math.random() * 0.32));
    const color = FW_COLORS[Math.floor(Math.random() * FW_COLORS.length)];
    const chosenPattern = pattern || (Math.random() < 0.35 ? 'willow' : (Math.random() < 0.65 ? 'ring' : 'peony'));

    fireworks.push(new FireworkRocket(sx, sy, tx, ty, color, chosenPattern));
  }

  function launchCelebrationBurst() {
    launchFirework(skyWidth * 0.32, skyWidth * 0.30, skyHeight * 0.22, 'willow');
    setTimeout(() => {
      launchFirework(skyWidth * 0.68, skyWidth * 0.70, skyHeight * 0.18, 'ring');
    }, 380);
    setTimeout(() => {
      launchFirework(skyWidth * 0.50, skyWidth * 0.50, skyHeight * 0.14, 'peony');
    }, 800);
  }

  let lastMilestoneCelebrated = 0;
  function checkMilestoneCelebration(count) {
    if (count > 0 && count % 10 === 0 && count !== lastMilestoneCelebrated) {
      lastMilestoneCelebrated = count;
      triggerGrandMilestoneShow(count);
    }
  }

  function triggerGrandMilestoneShow(count) {
    showToast(
      `🎉 ร่วมฉลองครบ ${count} กระทง! ✨`,
      'ท่าอากาศยานตรัง ขอขอบคุณทุกท่านที่ร่วมสืบสานประเพณีลอยกระทง 2569'
    );

    const positions = [0.22, 0.78, 0.36, 0.64, 0.50, 0.28, 0.72, 0.50];
    const heights = [0.24, 0.22, 0.18, 0.17, 0.13, 0.26, 0.25, 0.11];
    const patterns = ['willow', 'ring', 'peony', 'willow', 'ring', 'peony', 'willow', 'ring'];

    positions.forEach((pos, idx) => {
      setTimeout(() => {
        launchFirework(skyWidth * pos, skyWidth * pos, skyHeight * heights[idx], patterns[idx]);
      }, idx * 360);
    });
  }

  let lastAmbientFwTime = performance.now();
  let nextAmbientFwInterval = 4500;

  function updateFireworks(now) {
    if (!fwCtx || !fireworksCanvas) return;
    fwCtx.clearRect(0, 0, skyWidth, skyHeight);

    if (now - lastAmbientFwTime > nextAmbientFwInterval) {
      lastAmbientFwTime = now;
      nextAmbientFwInterval = 3800 + Math.random() * 3500;
      launchFirework();
    }

    for (let i = fireworks.length - 1; i >= 0; i--) {
      const p = fireworks[i];
      p.update();
      p.draw(fwCtx);

      if (p.exploded || p.alpha <= 0) {
        fireworks.splice(i, 1);
      }
    }
  }

  // ================= 4. Realistic River Canvas: Waves, Moonlight & Reflections =================
  function renderRiverWater(now) {
    if (!rWidth || !rHeight) return;

    riverCtx.clearRect(0, 0, rWidth, rHeight);

    // 1. Deep Water Gradient (Calm River Night Water)
    const waterGrad = riverCtx.createLinearGradient(0, 0, 0, rHeight);
    waterGrad.addColorStop(0, '#0c1a36');
    waterGrad.addColorStop(0.35, '#071229');
    waterGrad.addColorStop(0.75, '#040b1b');
    waterGrad.addColorStop(1, '#02050e');
    riverCtx.fillStyle = waterGrad;
    riverCtx.fillRect(0, 0, rWidth, rHeight);

    // 2A. Flowing River Micro-Wavelets with 2.5D Perspective (ริ้วคลื่นน้ำระลอกสลับฟันปลาไหลเอื่อยๆ ทั่วลำน้ำ)
    riverMicroWavelets.forEach(wv => {
      // Drift slowly downstream (to the right)
      wv.xNorm += wv.driftSpeed;
      if (wv.xNorm > 1.1) wv.xNorm = -0.1;

      const d = wv.depth;
      const py = d * rHeight;
      const px = wv.xNorm * rWidth;

      // 2.5D perspective scaling (distant horizon is small & delicate, foreground is broad)
      const pScale = 0.28 + d * 0.72;
      const waveW = wv.baseLength * pScale * (0.85 + Math.sin(now * wv.wobbleSpeed + wv.phase) * 0.25);
      const waveH = (wv.curveAmp * pScale) * Math.sin(now * (wv.wobbleSpeed * 1.4) + wv.phase);

      const undulateY = Math.sin(now * 0.0018 + px * 0.008 + wv.phase) * (1.2 * pScale);
      const cy = py + undulateY;

      // Natural breathing luminescence
      const breath = 0.5 + 0.5 * Math.sin(now * wv.wobbleSpeed * 0.8 + wv.phase);
      const alpha = (0.08 + d * 0.16) * breath;

      riverCtx.save();
      const waveGrad = riverCtx.createLinearGradient(px - waveW * 0.5, cy, px + waveW * 0.5, cy);
      if (wv.colorTone === 'gold') {
        waveGrad.addColorStop(0, 'rgba(255, 235, 170, 0)');
        waveGrad.addColorStop(0.5, `rgba(255, 240, 190, ${(alpha * 1.1).toFixed(3)})`);
        waveGrad.addColorStop(1, 'rgba(255, 235, 170, 0)');
      } else if (wv.colorTone === 'jade') {
        waveGrad.addColorStop(0, 'rgba(139, 212, 176, 0)');
        waveGrad.addColorStop(0.5, `rgba(168, 230, 207, ${(alpha * 0.95).toFixed(3)})`);
        waveGrad.addColorStop(1, 'rgba(139, 212, 176, 0)');
      } else {
        waveGrad.addColorStop(0, 'rgba(79, 195, 247, 0)');
        waveGrad.addColorStop(0.5, `rgba(144, 215, 255, ${(alpha * 1.0).toFixed(3)})`);
        waveGrad.addColorStop(1, 'rgba(79, 195, 247, 0)');
      }

      riverCtx.strokeStyle = waveGrad;
      riverCtx.lineWidth = Math.max(0.7, 1.4 * pScale);
      riverCtx.beginPath();
      riverCtx.moveTo(px - waveW * 0.5, cy);
      riverCtx.quadraticCurveTo(px, cy + waveH, px + waveW * 0.5, cy);
      riverCtx.stroke();
      riverCtx.restore();
    });

    // 2B. Midnight River Mist (ไอหมอกบางๆ เรี่ยผิวน้ำช่วงรอยต่อขอบฟ้า)
    riverCtx.save();
    riverCtx.globalCompositeOperation = 'screen';

    // Layer 1: Broad soft horizon gradient fog (เบลนด์รอยต่อเงาวัดกับแม่น้ำ)
    const mistBaseHeight = Math.min(105, rHeight * 0.22);
    const horizonMistGrad = riverCtx.createLinearGradient(0, 0, 0, mistBaseHeight);
    const mistBreath = 0.85 + Math.sin(now * 0.001) * 0.15;
    horizonMistGrad.addColorStop(0, `rgba(160, 205, 240, ${(0.22 * mistBreath).toFixed(3)})`);
    horizonMistGrad.addColorStop(0.4, `rgba(140, 185, 225, ${(0.12 * mistBreath).toFixed(3)})`);
    horizonMistGrad.addColorStop(0.8, `rgba(100, 150, 200, ${(0.04 * mistBreath).toFixed(3)})`);
    horizonMistGrad.addColorStop(1, 'rgba(80, 130, 180, 0)');

    riverCtx.fillStyle = horizonMistGrad;
    riverCtx.fillRect(0, 0, rWidth, mistBaseHeight);

    // Layer 2: Undulating horizontal mist ribbons slowly drifting (ไอหมอกระลอกนุ่มลอยเลื้อยช้าๆ)
    const mistRibbonCount = 3;
    for (let m = 0; m < mistRibbonCount; m++) {
      const mProg = m / mistRibbonCount;
      const mY = mistBaseHeight * (0.25 + mProg * 0.65);
      const mWaveH = 5 + m * 3.5;

      riverCtx.beginPath();
      riverCtx.moveTo(0, mY);
      for (let x = 0; x <= rWidth; x += 40) {
        const mSin = Math.sin(x * 0.004 + now * 0.0012 + m * 1.8) * mWaveH
                   + Math.cos(x * 0.009 - now * 0.0008 + m) * (mWaveH * 0.4);
        riverCtx.lineTo(x, mY + mSin);
      }
      riverCtx.lineTo(rWidth, 0);
      riverCtx.lineTo(0, 0);
      riverCtx.closePath();

      const mRibbonGrad = riverCtx.createLinearGradient(0, 0, 0, mY + mWaveH);
      mRibbonGrad.addColorStop(0, `rgba(175, 215, 250, ${(0.11 * mistBreath).toFixed(3)})`);
      mRibbonGrad.addColorStop(0.5, `rgba(150, 195, 235, ${(0.05 * mistBreath).toFixed(3)})`);
      mRibbonGrad.addColorStop(1, 'rgba(120, 170, 220, 0)');

      riverCtx.fillStyle = mRibbonGrad;
      riverCtx.fill();
    }
    riverCtx.restore();

    // 3. Realistic Shimmering Moonlight Water Reflection (เงาพระจันทร์บนน้ำงดงามสมจริง)
    let moonCenterX = rWidth * 0.81; // default fallback aligned with moon
    if (scenicMoon) {
      const moonRect = scenicMoon.getBoundingClientRect();
      const riverRect = riverStage ? riverStage.getBoundingClientRect() : null;
      if (moonRect.width > 0 && window.innerWidth > 0) {
        moonCenterX = (moonRect.left + moonRect.width * 0.5);
        if (riverRect && riverRect.left > 0) {
          moonCenterX -= riverRect.left;
        }
      }
    }

    // 3A. Deep Ambient Radiant Water Sheen (แสงจันทร์ตกกระทบแผ่ซึมลงผิวน้ำอย่างนุ่มนวล ไร้รอยตัด)
    const ambientSlices = 12;
    for (let s = 0; s < ambientSlices; s++) {
      const sDepth = s / (ambientSlices - 1);
      const sy = sDepth * rHeight;
      const sWidth = (80 + sDepth * 340);
      const sAlpha = (0.32 * (1 - sDepth * 0.45)) * (0.85 + Math.sin(now * 0.002 + s * 0.5) * 0.15);

      const sGrad = riverCtx.createRadialGradient(moonCenterX, sy, 2, moonCenterX, sy, sWidth * 0.65);
      sGrad.addColorStop(0, `rgba(255, 248, 220, ${(sAlpha * 0.8).toFixed(3)})`);
      sGrad.addColorStop(0.35, `rgba(255, 228, 145, ${(sAlpha * 0.4).toFixed(3)})`);
      sGrad.addColorStop(0.7, `rgba(243, 212, 137, ${(sAlpha * 0.12).toFixed(3)})`);
      sGrad.addColorStop(1, 'rgba(243, 212, 137, 0)');

      riverCtx.fillStyle = sGrad;
      riverCtx.beginPath();
      riverCtx.ellipse(moonCenterX, sy, sWidth * 0.5, (rHeight / ambientSlices) * 1.5, 0, 0, Math.PI * 2);
      riverCtx.fill();
    }

    // 3B. Cascading Organic Caustic Wave Ribbons (ริ้วคลื่นน้ำระยับสะท้อนแสงจันทร์)
    const moonSteps = 42;
    const stepH = rHeight / moonSteps;

    for (let i = 1; i < moonSteps; i++) {
      const depthRatio = i / moonSteps; // 0 to 1
      const y = i * stepH;

      // Perspective width expansion from horizon to foreground
      const colWidth = (36 + depthRatio * 250) * (0.92 + Math.sin(now * 0.0018 + depthRatio * 4.2) * 0.08);

      // Multi-harmonic current wobble
      const wobble = Math.sin(y * 0.025 + now * 0.0022) * (7 + depthRatio * 18)
                   + Math.sin(y * 0.06 - now * 0.0038) * (3 + depthRatio * 8);

      const cx = moonCenterX + wobble;
      const pulseAlpha = (0.55 * (1 - depthRatio * 0.35)) * (0.8 + Math.sin(now * 0.003 + i * 0.65) * 0.2);

      // Soft radiant elliptical glow disc at this step
      const radGrad = riverCtx.createRadialGradient(cx, y, 1, cx, y, colWidth * 0.5);
      radGrad.addColorStop(0, `rgba(255, 252, 225, ${(pulseAlpha * 0.75).toFixed(3)})`);
      radGrad.addColorStop(0.35, `rgba(255, 230, 145, ${(pulseAlpha * 0.42).toFixed(3)})`);
      radGrad.addColorStop(0.7, `rgba(243, 212, 137, ${(pulseAlpha * 0.15).toFixed(3)})`);
      radGrad.addColorStop(1, 'rgba(243, 212, 137, 0)');

      riverCtx.fillStyle = radGrad;
      riverCtx.beginPath();
      riverCtx.ellipse(cx, y, colWidth * 0.48, stepH * 0.85, 0, 0, Math.PI * 2);
      riverCtx.fill();

      // Main undulating wave ribbon with specular ivory crest
      const ribbonW = colWidth * (0.55 + Math.sin(now * 0.0035 + i * 0.75) * 0.32);
      const waveWave1 = Math.sin(now * 0.0045 + i * 0.8) * (1.8 + depthRatio * 3.5);
      const waveWave2 = -Math.cos(now * 0.004 + i * 0.8) * (1.8 + depthRatio * 3.5);

      const strokeGrad = riverCtx.createLinearGradient(cx - ribbonW * 0.5, y, cx + ribbonW * 0.5, y);
      strokeGrad.addColorStop(0, 'rgba(255, 240, 180, 0)');
      strokeGrad.addColorStop(0.25, `rgba(255, 235, 170, ${(pulseAlpha * 0.65).toFixed(3)})`);
      strokeGrad.addColorStop(0.5, `rgba(255, 255, 240, ${(pulseAlpha * 0.95).toFixed(3)})`); // Ivory crest
      strokeGrad.addColorStop(0.75, `rgba(255, 235, 170, ${(pulseAlpha * 0.65).toFixed(3)})`);
      strokeGrad.addColorStop(1, 'rgba(255, 240, 180, 0)');

      riverCtx.strokeStyle = strokeGrad;
      riverCtx.lineWidth = 1.0 + depthRatio * 1.8;
      riverCtx.beginPath();
      riverCtx.moveTo(cx - ribbonW * 0.5, y);
      riverCtx.bezierCurveTo(
        cx - ribbonW * 0.22, y + waveWave1,
        cx + ribbonW * 0.22, y + waveWave2,
        cx + ribbonW * 0.5, y
      );
      riverCtx.stroke();

      // Secondary fine shimmering filament on alternate steps
      if (i % 2 === 0) {
        const subW = ribbonW * 0.65;
        const subY = y + stepH * 0.4;
        riverCtx.strokeStyle = `rgba(255, 250, 220, ${(pulseAlpha * 0.7).toFixed(3)})`;
        riverCtx.lineWidth = 0.8 + depthRatio * 0.9;
        riverCtx.beginPath();
        riverCtx.moveTo(cx - subW * 0.5, subY);
        riverCtx.bezierCurveTo(
          cx - subW * 0.15, subY - waveWave2 * 0.7,
          cx + subW * 0.15, subY + waveWave1 * 0.7,
          cx + subW * 0.5, subY
        );
        riverCtx.stroke();
      }
    }

    // 3C. Dancing Specular Water Glints / Sparkles (ประกายระยิบระยับผิวน้ำกระทบแสงจันทร์)
    moonSparkles.forEach(sp => {
      const sy = sp.depth * rHeight;
      const d = sp.depth;
      const colW = (38 + d * 240);
      const wobbleY = Math.sin(sy * 0.025 + now * 0.0022) * (7 + d * 18);
      const sx = (moonCenterX + wobbleY) + sp.offsetNorm * (colW * 0.44);

      const twinkle = (Math.sin(now * sp.twinkleSpeed + sp.twinklePhase) + 1) * 0.5; // 0 to 1
      if (twinkle < 0.28) return; // Only draw when glowing

      const alpha = (twinkle * (0.35 + (1 - d * 0.25))) * (0.75 + 0.25 * Math.sin(now * 0.004 + sp.twinklePhase));
      const sz = sp.baseSize * (0.85 + d * 0.8) * (0.7 + twinkle * 0.6);

      riverCtx.save();
      riverCtx.fillStyle = `rgba(255, 255, 240, ${alpha.toFixed(3)})`;
      riverCtx.shadowColor = 'rgba(255, 235, 170, 0.95)';
      riverCtx.shadowBlur = 4 * (1 + d * 0.6);

      // Horizontal specular diamond / ellipse glint
      riverCtx.beginPath();
      riverCtx.ellipse(sx, sy, sz * 2.4, sz * 0.65, 0, 0, Math.PI * 2);
      riverCtx.fill();

      // Bright white specular core
      if (twinkle > 0.72) {
        riverCtx.fillStyle = `rgba(255, 255, 255, ${(alpha * 1.1).toFixed(3)})`;
        riverCtx.beginPath();
        riverCtx.arc(sx, sy, sz * 0.55, 0, Math.PI * 2);
        riverCtx.fill();
      }
      riverCtx.restore();
    });

    // 4. Realistic Organic Caustic Light Reflections under EVERY Krathong (เงาแสงเทียนสะท้อนผิวน้ำสมจริง)
    krathongsMap.forEach(kr => {
      if (kr.isDescending && kr.descentProgress < 0.6) return;

      const posX = kr.x * rWidth;
      const posY = kr.currentY;
      const scale = kr.currentScale;
      const depth = kr.depth;

      // Candle Light reflection origin at water contact line
      const baseWaterY = posY + 22 * scale;
      const flameAlpha = (0.65 + depth * 0.28) * (0.85 + Math.sin(now * 0.006 + kr.bobPhase) * 0.15);

      riverCtx.save();
      riverCtx.globalCompositeOperation = 'screen';

      // 4A. Soft ambient warmth right around the hull water-contact base (ไร้ขอบแข็ง ไร้ทรงแคปซูล)
      const discW = 54 * scale;
      const discH = 12 * scale;
      const baseGlow = riverCtx.createRadialGradient(posX, baseWaterY, 1, posX, baseWaterY, discW * 0.5);
      baseGlow.addColorStop(0, `rgba(255, 230, 150, ${(0.38 * flameAlpha).toFixed(3)})`);
      baseGlow.addColorStop(0.35, `rgba(255, 175, 70, ${(0.18 * flameAlpha).toFixed(3)})`);
      baseGlow.addColorStop(0.8, `rgba(243, 140, 40, ${(0.05 * flameAlpha).toFixed(3)})`);
      baseGlow.addColorStop(1, 'rgba(243, 140, 40, 0)');

      riverCtx.fillStyle = baseGlow;
      riverCtx.beginPath();
      riverCtx.ellipse(posX, baseWaterY, discW * 0.5, discH * 0.5, 0, 0, Math.PI * 2);
      riverCtx.fill();

      // 4B. Horizontal Shimmering Caustic Wavelets (ระลอกคลื่นสะท้อนแสงเทียนพริ้วไหวตามสายน้ำ)
      const rippleCount = 7;
      for (let r = 1; r <= rippleCount; r++) {
        const depthFrac = r / rippleCount; // 0 to 1
        const ry = baseWaterY + (r * 6.2 + Math.sin(now * 0.0035 + kr.bobPhase + r * 1.1) * 1.4) * scale;
        const waveWobble = Math.sin(now * 0.004 + ry * 0.04 + kr.bobPhase) * (3.8 * scale);
        const rw = (discW * (1.0 - depthFrac * 0.44)) * (0.82 + 0.36 * Math.sin(now * 0.005 + kr.bobPhase * 1.3 + r * 1.4));
        const waveAlpha = flameAlpha * (1 - depthFrac * 0.72) * (0.50 + 0.30 * Math.sin(now * 0.006 + kr.bobPhase + r * 1.6));

        const lineGrad = riverCtx.createLinearGradient(posX - rw * 0.5 + waveWobble, ry, posX + rw * 0.5 + waveWobble, ry);
        lineGrad.addColorStop(0, 'rgba(255, 180, 80, 0)');
        lineGrad.addColorStop(0.25, `rgba(255, 215, 130, ${(waveAlpha * 0.65).toFixed(3)})`);
        lineGrad.addColorStop(0.5, `rgba(255, 250, 210, ${(waveAlpha * 0.95).toFixed(3)})`); // Specular core crest
        lineGrad.addColorStop(0.75, `rgba(255, 215, 130, ${(waveAlpha * 0.65).toFixed(3)})`);
        lineGrad.addColorStop(1, 'rgba(255, 180, 80, 0)');

        riverCtx.strokeStyle = lineGrad;
        riverCtx.lineWidth = Math.max(0.75, (2.0 - depthFrac * 1.0) * scale);
        riverCtx.beginPath();
        const curve = Math.sin(now * 0.0045 + r + kr.bobPhase) * (1.4 * scale);
        riverCtx.moveTo(posX - rw * 0.5 + waveWobble, ry);
        riverCtx.quadraticCurveTo(posX + waveWobble, ry + curve, posX + rw * 0.5 + waveWobble, ry);
        riverCtx.stroke();
      }

      // 4C. Specular Candle Glints on Nearest Wave Facets (ประกายแสงแวววาวระยิบระยับผิวน้ำ)
      for (let s = 1; s <= 3; s++) {
        const sPhase = kr.bobPhase + s * 2.2;
        const twinkle = Math.sin(now * 0.008 + sPhase);
        if (twinkle > 0.35) {
          const sy = baseWaterY + (s * 6.5) * scale;
          const sx = posX + Math.sin(now * 0.003 + sPhase) * (6.5 * scale);
          const sAlpha = flameAlpha * (twinkle - 0.35) * 0.75;
          riverCtx.fillStyle = `rgba(255, 255, 230, ${sAlpha.toFixed(3)})`;
          riverCtx.beginPath();
          riverCtx.ellipse(sx, sy, 2.6 * scale, 0.9 * scale, 0, 0, Math.PI * 2);
          riverCtx.fill();
        }
      }

      // 4D. Subtle Buoyant Hull Wake & Displacement Ring (ระลอกน้ำโอบรอบฐานกระทงตามแรงโยก)
      const bobDisplacement = Math.sin(now * 0.004 + kr.bobPhase); // -1 to 1
      const wakeAlpha = flameAlpha * (0.28 + bobDisplacement * 0.08);
      const hullRadiusX = (discW * 0.58 + bobDisplacement * 2.2) * scale;
      const hullRadiusY = hullRadiusX * 0.35; // 2.5D perspective ellipse

      // Outer gentle water displacement ring
      riverCtx.strokeStyle = `rgba(235, 245, 255, ${(wakeAlpha * 0.45).toFixed(3)})`;
      riverCtx.lineWidth = Math.max(0.65, 1.2 * scale);
      riverCtx.beginPath();
      riverCtx.ellipse(posX, baseWaterY, hullRadiusX, hullRadiusY, 0, 0, Math.PI * 2);
      riverCtx.stroke();

      // Inner contact water crease
      const innerWakeX = hullRadiusX * 0.72;
      const innerWakeY = hullRadiusY * 0.72;
      riverCtx.strokeStyle = `rgba(255, 235, 170, ${(wakeAlpha * 0.60).toFixed(3)})`;
      riverCtx.lineWidth = Math.max(0.6, 1.0 * scale);
      riverCtx.beginPath();
      riverCtx.ellipse(posX, baseWaterY, innerWakeX, innerWakeY, 0, 0, Math.PI * 2);
      riverCtx.stroke();

      riverCtx.restore();
    });

    // 5. Dynamic Sky Fireworks Reflection on River Water (แสงพลุสะท้อนผิวน้ำแบบธรรมชาติ ไร้ขอบเหลี่ยม)
    if (activeRiverFlashes.length > 0) {
      for (let f = activeRiverFlashes.length - 1; f >= 0; f--) {
        const fl = activeRiverFlashes[f];
        fl.alpha -= fl.decay;
        if (fl.alpha <= 0) {
          activeRiverFlashes.splice(f, 1);
          continue;
        }

        const fx = fl.normX * rWidth;
        const colSpread = 90 + (1 - fl.alpha) * 80;
        const reachY = rHeight * 0.35;

        riverCtx.save();
        riverCtx.globalCompositeOperation = 'screen';

        // 5A. Soft downward radial glow from water horizon directly below explosion (ไร้กรอบ ไร้รอยต่อ)
        const colGrad = riverCtx.createRadialGradient(fx, 0, 2, fx, 0, reachY);
        colGrad.addColorStop(0, hexToRgba(fl.glow, fl.alpha * 0.25));
        colGrad.addColorStop(0.35, hexToRgba(fl.color, fl.alpha * 0.12));
        colGrad.addColorStop(0.7, hexToRgba(fl.color, fl.alpha * 0.03));
        colGrad.addColorStop(1, 'rgba(0,0,0,0)');

        riverCtx.fillStyle = colGrad;
        riverCtx.beginPath();
        riverCtx.ellipse(fx, 0, colSpread, reachY, 0, 0, Math.PI);
        riverCtx.fill();

        // 5B. Shimmering horizontal wave crests under firework (ระลอกคลื่นรับแสงพลุระยิบระยับ)
        const fireworkRipples = 5;
        for (let w = 1; w <= fireworkRipples; w++) {
          const depthRatio = w / fireworkRipples;
          const wy = w * (reachY / (fireworkRipples + 1));
          const wSpread = (colSpread * (1.1 - depthRatio * 0.4)) * (0.85 + 0.3 * Math.sin(now * 0.006 + w * 1.7));
          const wAlpha = fl.alpha * (0.22 * (1 - depthRatio * 0.6));
          const wJitter = Math.sin(now * 0.005 + wy * 0.04) * 5;

          const strokeGrad = riverCtx.createLinearGradient(fx - wSpread * 0.5 + wJitter, wy, fx + wSpread * 0.5 + wJitter, wy);
          strokeGrad.addColorStop(0, 'rgba(0,0,0,0)');
          strokeGrad.addColorStop(0.3, hexToRgba(fl.color, wAlpha * 0.6));
          strokeGrad.addColorStop(0.5, hexToRgba(fl.glow, wAlpha));
          strokeGrad.addColorStop(0.7, hexToRgba(fl.color, wAlpha * 0.6));
          strokeGrad.addColorStop(1, 'rgba(0,0,0,0)');

          riverCtx.strokeStyle = strokeGrad;
          riverCtx.lineWidth = Math.max(0.7, 1.3 - depthRatio * 0.5);
          riverCtx.beginPath();
          riverCtx.moveTo(fx - wSpread * 0.5 + wJitter, wy);
          riverCtx.quadraticCurveTo(
            fx + wJitter, wy + Math.sin(now * 0.005 + w) * 1.5,
            fx + wSpread * 0.5 + wJitter, wy
          );
          riverCtx.stroke();
        }

        riverCtx.restore();
      }
    }

    // 6. Realistic River Fish School & Bread Krathong Nibbling Simulation (ฝูงปลาแหวกว่ายตอดกระทงขนมปัง)
    updateAndDrawRiverRipples(riverCtx);
    riverFishSchool.forEach(fish => {
      fish.update(now);
      fish.draw(riverCtx);
    });
    updateAndDrawRiverBubbles(riverCtx);
  }

  // ================= 4D. Realistic River Fish School, Perspective Scaling & Darting Ripples =================
  const riverRipples = [];
  const riverBubbles = [];
  const riverFishSchool = [];

  function spawnFishThrustRipple(x, y, scale) {
    const s = scale || 1;
    riverRipples.push({
      x, y,
      scale: s,
      radius: 4 * s,
      maxRadius: (36 + Math.random() * 22) * s,
      growthSpeed: (0.75 + Math.random() * 0.35) * s,
      alpha: 0.95,
      decay: 0.013,
      lineWidth: Math.max(1.0, 1.8 * s)
    });
  }

  function updateAndDrawRiverRipples(ctx) {
    for (let i = riverRipples.length - 1; i >= 0; i--) {
      const rp = riverRipples[i];
      rp.radius += rp.growthSpeed || 0.7;
      rp.alpha -= rp.decay || 0.013;

      if (rp.alpha <= 0 || rp.radius >= rp.maxRadius) {
        riverRipples.splice(i, 1);
        continue;
      }

      ctx.save();
      const ry = rp.radius * 0.36; // 2.5D perspective elliptical flattening

      // Candlelit & moonlit luminous glow on ripples
      ctx.shadowColor = 'rgba(255, 245, 200, 0.55)';
      ctx.shadowBlur = Math.max(2, 6 * (rp.scale || 1));

      // Subtle water disturbance sheen
      if (rp.alpha > 0.35 && rp.radius > 6) {
        ctx.fillStyle = `rgba(180, 230, 255, ${(rp.alpha * 0.08).toFixed(3)})`;
        ctx.beginPath();
        ctx.ellipse(rp.x, rp.y, rp.radius, ry, 0, 0, Math.PI * 2);
        ctx.fill();
      }

      // 1. Primary outer ripple ring (2.5D perspective ellipse)
      ctx.strokeStyle = `rgba(255, 252, 235, ${(rp.alpha * 0.95).toFixed(3)})`;
      ctx.lineWidth = rp.lineWidth || 1.3;
      ctx.beginPath();
      ctx.ellipse(rp.x, rp.y, rp.radius, ry, 0, 0, Math.PI * 2);
      ctx.stroke();

      // 2. Secondary inner echo wave (concentric ring)
      if (rp.radius > 8) {
        const innerR = rp.radius * 0.62;
        ctx.strokeStyle = `rgba(243, 218, 150, ${(rp.alpha * 0.65).toFixed(3)})`;
        ctx.lineWidth = Math.max(0.7, (rp.lineWidth || 1.3) * 0.75);
        ctx.beginPath();
        ctx.ellipse(rp.x, rp.y, innerR, innerR * 0.36, 0, 0, Math.PI * 2);
        ctx.stroke();
      }

      // 3. Faint tertiary trailing echo ring
      if (rp.radius > 16) {
        const trailingR = rp.radius * 0.34;
        ctx.strokeStyle = `rgba(210, 240, 255, ${(rp.alpha * 0.4).toFixed(3)})`;
        ctx.lineWidth = Math.max(0.6, (rp.lineWidth || 1.3) * 0.5);
        ctx.beginPath();
        ctx.ellipse(rp.x, rp.y, trailingR, trailingR * 0.36, 0, 0, Math.PI * 2);
        ctx.stroke();
      }

      ctx.restore();
    }
  }

  function updateAndDrawRiverBubbles(ctx) {
    for (let i = riverBubbles.length - 1; i >= 0; i--) {
      const b = riverBubbles[i];
      b.life++;
      b.x += b.vx;
      b.y += b.vy;
      b.alpha = (1 - b.life / b.maxLife) * 0.85;

      if (b.life >= b.maxLife || b.alpha <= 0) {
        riverBubbles.splice(i, 1);
        continue;
      }

      ctx.save();
      ctx.strokeStyle = `rgba(200, 240, 255, ${(b.alpha * 0.9).toFixed(3)})`;
      ctx.fillStyle = `rgba(255, 255, 255, ${(b.alpha * 0.35).toFixed(3)})`;
      ctx.lineWidth = 0.8;
      ctx.beginPath();
      ctx.arc(b.x, b.y, b.size, 0, Math.PI * 2);
      ctx.fill();
      ctx.stroke();

      // Specular highlight glint
      ctx.fillStyle = `rgba(255, 255, 255, ${(b.alpha * 0.95).toFixed(3)})`;
      ctx.beginPath();
      ctx.arc(b.x - b.size * 0.35, b.y - b.size * 0.35, b.size * 0.3, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  }

  class RiverFish {
    constructor(preferredDepthRatio) {
      this.baseLength = 48; // Base length in foreground
      this.reset(preferredDepthRatio);
    }

    reset(preferredDepthRatio) {
      this.preferredDepth = preferredDepthRatio !== undefined 
        ? preferredDepthRatio 
        : (0.12 + Math.random() * 0.82);

      this.y = (this.preferredDepth * (rHeight || 600)) + (Math.random() * 24 - 12);
      this.x = Math.random() < 0.5 ? -60 : (rWidth || 1920) + 60;

      // Dynamic depth scaling calculation
      this.updateDynamicDimensions();

      this.baseSpeed = (0.75 + Math.random() * 0.45);
      this.thrustBoost = 0;
      this.thrustCooldown = 80 + Math.floor(Math.random() * 160);
      this.angle = this.x < 0 ? (Math.random() * 0.25 - 0.12) : (Math.PI + Math.random() * 0.25 - 0.12);

      const randColor = Math.random();
      if (randColor < 0.45) {
        this.colorType = 'gold';
        this.primary = '#ff9f43';
        this.secondary = '#feca57';
        this.belly = '#fff5d7';
      } else if (randColor < 0.8) {
        this.colorType = 'kohaku';
        this.primary = '#ee5253';
        this.secondary = '#ffffff';
        this.belly = '#ffffff';
      } else {
        this.colorType = 'silver';
        this.primary = '#dfe4ea';
        this.secondary = '#ced6e0';
        this.belly = '#f1f2f6';
      }

      this.spineNodes = [];
      for (let i = 0; i < 5; i++) {
        this.spineNodes.push({ x: this.x, y: this.y });
      }

      this.swimPhase = Math.random() * Math.PI * 2;
      this.swimFreq = 0.0075 + Math.random() * 0.003;

      this.state = 'roam';
      this.targetKrathong = null;
      this.nibbleCount = 0;
      this.maxNibbles = 2 + Math.floor(Math.random() * 3);
      this.nibbleTimer = 0;
      this.stateTimer = 0;
      this.nibbleAngle = 0;
      this.trailingRippleTimer = 0;
    }

    updateDynamicDimensions() {
      // 2.5D Perspective depth calculation based on vertical river position Y
      const depthRatio = Math.max(0.06, Math.min(0.96, this.y / (rHeight || 600)));
      this.depth = depthRatio;

      // Realistic 2.5D Scale: 0.28 (tiny distant horizon) to 1.05 (large close foreground)
      this.scale = 0.28 + depthRatio * 0.77;
      this.length = this.baseLength * this.scale;
      this.width = this.length * 0.28;
      this.spineLength = this.length * 0.85;
    }

    update(now) {
      this.stateTimer++;
      this.updateDynamicDimensions();

      // Dynamic speed scaling with perspective foreshortening
      const perspectiveSpeedFactor = (0.42 + this.depth * 0.76);
      this.speed = (this.baseSpeed + this.thrustBoost) * perspectiveSpeedFactor;
      this.thrustBoost *= 0.94; // Smooth burst decay

      // 1. Natural Kick & Glide Water Ring Thrust (เวลาสะบัดหางพุ่งตัว)
      if (this.trailingRippleTimer > 0) {
        this.trailingRippleTimer--;
        if (this.trailingRippleTimer === 0) {
          const tail = this.spineNodes[4] || { x: this.x, y: this.y };
          spawnFishThrustRipple(tail.x, tail.y, this.scale * 0.85);
        }
      }

      if (this.state === 'roam') {
        this.thrustCooldown--;
        if (this.thrustCooldown <= 0) {
          this.thrustBoost = this.baseSpeed * 1.55;
          this.thrustCooldown = 130 + Math.floor(Math.random() * 190);
          this.trailingRippleTimer = 9;
          const tail = this.spineNodes[4] || { x: this.x, y: this.y };
          spawnFishThrustRipple(tail.x, tail.y, this.scale);
        }

        if (this.stateTimer % 55 === 0) {
          this.findBreadTarget();
        }
      }

      // 2. State Machine
      if (this.state === 'seek_bread') {
        if (!this.targetKrathong || !this.targetKrathong.el || !this.targetKrathong.el.parentNode) {
          this.state = 'roam';
          this.targetKrathong = null;
        } else {
          const kx = this.targetKrathong.x * rWidth;
          const ky = this.targetKrathong.currentY + 22 * this.targetKrathong.currentScale;
          const dx = kx - this.x;
          const dy = ky - this.y;
          const dist = Math.hypot(dx, dy);

          const targetAngle = Math.atan2(dy, dx);
          let diff = targetAngle - this.angle;
          while (diff < -Math.PI) diff += Math.PI * 2;
          while (diff > Math.PI) diff -= Math.PI * 2;
          this.angle += diff * 0.06;

          if (dist < 40 * this.scale) {
            this.state = 'nibble';
            this.nibbleTimer = 0;
            this.nibbleCount = 0;
            this.nibbleAngle = Math.atan2(this.y - ky, this.x - kx);
          }
        }
      } else if (this.state === 'nibble') {
        if (!this.targetKrathong || !this.targetKrathong.el || !this.targetKrathong.el.parentNode) {
          this.state = 'roam';
          this.targetKrathong = null;
        } else {
          const kx = this.targetKrathong.x * rWidth;
          const ky = this.targetKrathong.currentY + 20 * this.targetKrathong.currentScale;
          this.nibbleTimer++;

          const nibblePhase = (this.nibbleTimer % 48) / 48;
          const dartDist = (24 + Math.sin(nibblePhase * Math.PI * 2) * 11) * this.scale;

          const targetX = kx + Math.cos(this.nibbleAngle) * dartDist;
          const targetY = ky + Math.sin(this.nibbleAngle) * (dartDist * 0.45);

          this.x += (targetX - this.x) * 0.12;
          this.y += (targetY - this.y) * 0.12;
          this.angle = Math.atan2(ky - this.y, kx - this.x);

          // Water ripple on tail flick when thrusting toward bread
          if (this.nibbleTimer % 48 === 8) {
            const tail = this.spineNodes[4];
            spawnFishThrustRipple(tail.x, tail.y, this.scale);
          }

          // Apex contact (nibble point)
          if (this.nibbleTimer % 48 === 24) {
            this.nibbleCount++;
            this.spawnNibbleEffects(kx + Math.cos(this.nibbleAngle) * 16 * this.scale, ky);

            if (this.targetKrathong) {
              this.targetKrathong.impactTilt = (Math.random() < 0.5 ? 1 : -1) * (1.1 * this.scale);
              this.targetKrathong.vy = (this.targetKrathong.vy || 0) + 0.28;
            }

            this.nibbleAngle += (Math.random() * 0.8 - 0.4);

            if (this.nibbleCount >= this.maxNibbles) {
              this.state = 'depart';
              this.stateTimer = 0;
              this.angle += Math.PI * 0.75;
              this.thrustBoost = this.baseSpeed * 1.5;
              const tail = this.spineNodes[4];
              spawnFishThrustRipple(tail.x, tail.y, this.scale);
            }
          }
        }
      } else if (this.state === 'depart') {
        if (this.stateTimer > 80) {
          this.state = 'roam';
          this.targetKrathong = null;
        }
      } else {
        // Roaming: gentle sway + keep near preferred depth band
        this.angle += Math.sin(now * 0.0012 + this.swimPhase) * 0.014;
        const targetY = this.preferredDepth * rHeight;
        const dy = targetY - this.y;
        this.y += dy * 0.008; // subtle spring back to preferred depth band

        const minY = rHeight * 0.08;
        const maxY = rHeight * 0.94;
        if (this.y < minY) this.angle += 0.035;
        if (this.y > maxY) this.angle -= 0.035;
      }

      if (this.state !== 'nibble') {
        this.x += Math.cos(this.angle) * this.speed;
        this.y += Math.sin(this.angle) * this.speed;
      }

      if (this.x < -100 && Math.cos(this.angle) < 0) this.reset(this.preferredDepth);
      if (this.x > (rWidth || 1920) + 100 && Math.cos(this.angle) > 0) this.reset(this.preferredDepth);

      this.swimPhase += this.swimFreq * (this.speed / Math.max(0.1, this.baseSpeed));
      this.updateSpine();
    }

    findBreadTarget() {
      let bestDist = 420 * this.scale;
      let bestKr = null;

      for (const kr of krathongsMap.values()) {
        if (kr.isDescending) continue;
        if (kr.data && kr.data.krathongType === 'bread') {
          const kx = kr.x * rWidth;
          const ky = kr.currentY + 22 * kr.currentScale;
          const d = Math.hypot(kx - this.x, ky - this.y);
          if (d < bestDist) {
            bestDist = d;
            bestKr = kr;
          }
        }
      }

      if (bestKr) {
        this.targetKrathong = bestKr;
        this.state = 'seek_bread';
        this.thrustBoost = this.baseSpeed * 1.5;
        const tail = this.spineNodes[4] || { x: this.x, y: this.y };
        spawnFishThrustRipple(tail.x, tail.y, this.scale);
      }
    }

    spawnNibbleEffects(x, y) {
      spawnFishThrustRipple(x, y, this.scale * 0.75);

      const bubbleCount = 2 + Math.floor(Math.random() * 2);
      for (let b = 0; b < bubbleCount; b++) {
        riverBubbles.push({
          x: x + (Math.random() * 8 - 4) * this.scale,
          y: y + (Math.random() * 6 - 3) * this.scale,
          size: (2.0 + Math.random() * 2.4) * this.scale,
          vx: (Math.random() * 0.35 - 0.175),
          vy: -(0.65 + Math.random() * 0.5) * this.scale,
          alpha: 0.85,
          life: 0,
          maxLife: 42 + Math.random() * 28
        });
      }

      if (audioEnabled) {
        playBubblePopSound();
      }
    }

    updateSpine() {
      this.spineNodes[0].x = this.x;
      this.spineNodes[0].y = this.y;

      const segLen = this.spineLength / (this.spineNodes.length - 1);
      for (let i = 1; i < this.spineNodes.length; i++) {
        const prev = this.spineNodes[i - 1];
        const curr = this.spineNodes[i];

        const swayAmp = (i * 1.8) * this.scale;
        const sway = Math.sin(this.swimPhase - i * 0.75) * swayAmp;
        const perpX = -Math.sin(this.angle) * sway;
        const perpY = Math.cos(this.angle) * sway;

        curr.x = prev.x - (Math.cos(this.angle) * segLen) + perpX * 0.25;
        curr.y = prev.y - (Math.sin(this.angle) * segLen) + perpY * 0.25;
      }
    }

    draw(ctx) {
      ctx.save();
      // Atmospheric depth fog: distant fish blend softly with dark water
      const depthAlpha = Math.min(0.96, 0.42 + this.depth * 0.52);
      ctx.globalAlpha = depthAlpha;

      const head = this.spineNodes[0];
      const chest = this.spineNodes[1];
      const waist = this.spineNodes[2];
      const tailBase = this.spineNodes[3];
      const tailTip = this.spineNodes[4];

      const swimDir = Math.atan2(head.y - chest.y, head.x - chest.x);
      const normalX = -Math.sin(swimDir);
      const normalY = Math.cos(swimDir);

      // Flap oscillation
      const finFlap = Math.sin(this.swimPhase * 1.5) * 0.22;
      const finLen = this.length * 0.44;
      const finWidth = this.width * 0.42;

      // ================= 1. PECTORAL FINS (ครีบอก ลู่ไปข้างหลังตามหลักชลศาสตร์) =================
      // Left Fin (Root on left chest flank, sweeps backward towards tail)
      const rootLeftX = chest.x + normalX * (this.width * 0.48);
      const rootLeftY = chest.y + normalY * (this.width * 0.48);
      const finAngleLeft = swimDir + Math.PI - 0.52 + finFlap;
      const finCenterLeftX = rootLeftX + Math.cos(finAngleLeft) * (finLen * 0.46);
      const finCenterLeftY = rootLeftY + Math.sin(finAngleLeft) * (finLen * 0.46);

      // Right Fin (Root on right chest flank, sweeps backward towards tail)
      const rootRightX = chest.x - normalX * (this.width * 0.48);
      const rootRightY = chest.y - normalY * (this.width * 0.48);
      const finAngleRight = swimDir + Math.PI + 0.52 - finFlap;
      const finCenterRightX = rootRightX + Math.cos(finAngleRight) * (finLen * 0.46);
      const finCenterRightY = rootRightY + Math.sin(finAngleRight) * (finLen * 0.46);

      // Fin gradient from body color to translucent ivory edge
      const finGradLeft = ctx.createLinearGradient(rootLeftX, rootLeftY, finCenterLeftX, finCenterLeftY);
      finGradLeft.addColorStop(0, hexToRgba(this.primary, depthAlpha * 0.85));
      finGradLeft.addColorStop(0.65, hexToRgba(this.secondary, depthAlpha * 0.65));
      finGradLeft.addColorStop(1, hexToRgba('#ffffff', depthAlpha * 0.25));

      ctx.fillStyle = finGradLeft;
      ctx.beginPath();
      ctx.ellipse(finCenterLeftX, finCenterLeftY, finLen * 0.5, finWidth * 0.5, finAngleLeft, 0, Math.PI * 2);
      ctx.fill();

      const finGradRight = ctx.createLinearGradient(rootRightX, rootRightY, finCenterRightX, finCenterRightY);
      finGradRight.addColorStop(0, hexToRgba(this.primary, depthAlpha * 0.85));
      finGradRight.addColorStop(0.65, hexToRgba(this.secondary, depthAlpha * 0.65));
      finGradRight.addColorStop(1, hexToRgba('#ffffff', depthAlpha * 0.25));

      ctx.fillStyle = finGradRight;
      ctx.beginPath();
      ctx.ellipse(finCenterRightX, finCenterRightY, finLen * 0.5, finWidth * 0.5, finAngleRight, 0, Math.PI * 2);
      ctx.fill();

      // Delicate translucent fin rays (เส้นครีบพริ้ว)
      ctx.strokeStyle = `rgba(255, 255, 255, ${(depthAlpha * 0.38).toFixed(2)})`;
      ctx.lineWidth = Math.max(0.5, 0.8 * this.scale);
      ctx.beginPath();
      ctx.moveTo(rootLeftX, rootLeftY);
      ctx.lineTo(rootLeftX + Math.cos(finAngleLeft) * finLen, rootLeftY + Math.sin(finAngleLeft) * finLen);
      ctx.moveTo(rootRightX, rootRightY);
      ctx.lineTo(rootRightX + Math.cos(finAngleRight) * finLen, rootRightY + Math.sin(finAngleRight) * finLen);
      ctx.stroke();

      // ================= 2. PELVIC FINS (ครีบท้องคู่หลังแนบชิดลำตัว) =================
      const pelvicLen = finLen * 0.52;
      const pelvicW = finWidth * 0.38;
      const pelvicRootLeftX = waist.x + normalX * (this.width * 0.34);
      const pelvicRootLeftY = waist.y + normalY * (this.width * 0.34);
      const pelvicAngleLeft = swimDir + Math.PI - 0.28 + finFlap * 0.5;

      ctx.fillStyle = hexToRgba(this.secondary, depthAlpha * 0.55);
      ctx.beginPath();
      ctx.ellipse(
        pelvicRootLeftX + Math.cos(pelvicAngleLeft) * (pelvicLen * 0.45),
        pelvicRootLeftY + Math.sin(pelvicAngleLeft) * (pelvicLen * 0.45),
        pelvicLen * 0.5, pelvicW * 0.5, pelvicAngleLeft, 0, Math.PI * 2
      );
      ctx.fill();

      const pelvicRootRightX = waist.x - normalX * (this.width * 0.34);
      const pelvicRootRightY = waist.y - normalY * (this.width * 0.34);
      const pelvicAngleRight = swimDir + Math.PI + 0.28 - finFlap * 0.5;

      ctx.beginPath();
      ctx.ellipse(
        pelvicRootRightX + Math.cos(pelvicAngleRight) * (pelvicLen * 0.45),
        pelvicRootRightY + Math.sin(pelvicAngleRight) * (pelvicLen * 0.45),
        pelvicLen * 0.5, pelvicW * 0.5, pelvicAngleRight, 0, Math.PI * 2
      );
      ctx.fill();

      // ================= 3. CAUDAL TAIL FIN (หางปลาแบบสองแฉกพริ้วไหว ดุจปลาคาร์ป/ปลาทอง) =================
      const tailDir = Math.atan2(tailTip.y - tailBase.y, tailTip.x - tailBase.x);
      const tailFanLen = this.length * 0.58;
      const tailFanWidth = this.width * 1.05;
      const tailNormalX = -Math.sin(tailDir);
      const tailNormalY = Math.cos(tailDir);

      const tailGrad = ctx.createLinearGradient(tailBase.x, tailBase.y, tailTip.x, tailTip.y);
      tailGrad.addColorStop(0, hexToRgba(this.primary, depthAlpha * 0.90));
      tailGrad.addColorStop(0.55, hexToRgba(this.secondary, depthAlpha * 0.75));
      tailGrad.addColorStop(1, hexToRgba('#ffffff', depthAlpha * 0.35));

      ctx.fillStyle = tailGrad;
      ctx.beginPath();
      ctx.moveTo(tailBase.x, tailBase.y);

      // Upper lobe
      const upperTipX = tailTip.x + tailNormalX * tailFanWidth + Math.cos(tailDir) * tailFanLen;
      const upperTipY = tailTip.y + tailNormalY * tailFanWidth + Math.sin(tailDir) * tailFanLen;
      // Center notch
      const centerNotchX = tailTip.x + Math.cos(tailDir) * (tailFanLen * 0.62);
      const centerNotchY = tailTip.y + Math.sin(tailDir) * (tailFanLen * 0.62);
      // Lower lobe
      const lowerTipX = tailTip.x - tailNormalX * tailFanWidth + Math.cos(tailDir) * tailFanLen;
      const lowerTipY = tailTip.y - tailNormalY * tailFanWidth + Math.sin(tailDir) * tailFanLen;

      ctx.quadraticCurveTo(tailTip.x + tailNormalX * (tailFanWidth * 0.8), tailTip.y + tailNormalY * (tailFanWidth * 0.8), upperTipX, upperTipY);
      ctx.quadraticCurveTo(tailTip.x + tailNormalX * (tailFanWidth * 0.3) + Math.cos(tailDir) * (tailFanLen * 0.7), tailTip.y + tailNormalY * (tailFanWidth * 0.3) + Math.sin(tailDir) * (tailFanLen * 0.7), centerNotchX, centerNotchY);
      ctx.quadraticCurveTo(tailTip.x - tailNormalX * (tailFanWidth * 0.3) + Math.cos(tailDir) * (tailFanLen * 0.7), tailTip.y - tailNormalY * (tailFanWidth * 0.3) + Math.sin(tailDir) * (tailFanLen * 0.7), lowerTipX, lowerTipY);
      ctx.quadraticCurveTo(tailTip.x - tailNormalX * (tailFanWidth * 0.8), tailTip.y - tailNormalY * (tailFanWidth * 0.8), tailBase.x, tailBase.y);
      ctx.closePath();
      ctx.fill();

      // Tail fin ray filaments
      ctx.strokeStyle = `rgba(255, 255, 255, ${(depthAlpha * 0.35).toFixed(2)})`;
      ctx.lineWidth = Math.max(0.5, 0.75 * this.scale);
      ctx.beginPath();
      ctx.moveTo(tailBase.x, tailBase.y);
      ctx.lineTo(upperTipX * 0.9 + tailBase.x * 0.1, upperTipY * 0.9 + tailBase.y * 0.1);
      ctx.moveTo(tailBase.x, tailBase.y);
      ctx.lineTo(centerNotchX, centerNotchY);
      ctx.moveTo(tailBase.x, tailBase.y);
      ctx.lineTo(lowerTipX * 0.9 + tailBase.x * 0.1, lowerTipY * 0.9 + tailBase.y * 0.1);
      ctx.stroke();

      // ================= 4. FISH BODY (ลำตัวปลาทรงหยดน้ำเรียวพริ้วไหว) =================
      const bodyGrad = ctx.createLinearGradient(head.x, head.y, tailBase.x, tailBase.y);
      bodyGrad.addColorStop(0, this.primary);
      bodyGrad.addColorStop(0.35, this.secondary);
      bodyGrad.addColorStop(0.75, this.primary);
      bodyGrad.addColorStop(1, this.belly);

      ctx.fillStyle = bodyGrad;
      ctx.beginPath();
      ctx.moveTo(head.x + Math.cos(swimDir) * (this.length * 0.18), head.y + Math.sin(swimDir) * (this.length * 0.18));
      ctx.quadraticCurveTo(
        chest.x + normalX * (this.width * 0.65),
        chest.y + normalY * (this.width * 0.65),
        waist.x + normalX * (this.width * 0.45),
        waist.y + normalY * (this.width * 0.45)
      );
      ctx.lineTo(tailBase.x + normalX * (this.width * 0.2), tailBase.y + normalY * (this.width * 0.2));
      ctx.lineTo(tailBase.x, tailBase.y);
      ctx.lineTo(tailBase.x - normalX * (this.width * 0.2), tailBase.y - normalY * (this.width * 0.2));
      ctx.quadraticCurveTo(
        waist.x - normalX * (this.width * 0.45),
        waist.y - normalY * (this.width * 0.45),
        chest.x - normalX * (this.width * 0.65),
        chest.y - normalY * (this.width * 0.65)
      );
      ctx.closePath();
      ctx.fill();

      // Kohaku Koi Authentic Red Patches (ลายแต้มแดงปลาคาร์ปโคฮาคุ)
      if (this.colorType === 'kohaku') {
        ctx.fillStyle = hexToRgba('#ee5253', depthAlpha * 0.95);
        // Head Hi Patch
        ctx.beginPath();
        ctx.ellipse(head.x - Math.cos(swimDir) * (this.length * 0.04), head.y - Math.sin(swimDir) * (this.length * 0.04), this.width * 0.38, this.width * 0.32, swimDir, 0, Math.PI * 2);
        ctx.fill();

        // Saddle Hi Patch on Mid-Body
        ctx.beginPath();
        ctx.ellipse(waist.x, waist.y, this.length * 0.18, this.width * 0.36, swimDir, 0, Math.PI * 2);
        ctx.fill();
      }

      // ================= 5. DORSAL FIN & SPECULAR SHIMMER (ครีบหลังและประกายแสง) =================
      // Translucent dorsal fin along spine
      ctx.fillStyle = hexToRgba(this.secondary, depthAlpha * 0.65);
      ctx.beginPath();
      ctx.moveTo(chest.x, chest.y);
      const finApexX = waist.x + normalX * (this.width * 0.18) - Math.cos(swimDir) * (this.length * 0.08);
      const finApexY = waist.y + normalY * (this.width * 0.18) - Math.sin(swimDir) * (this.length * 0.08);
      ctx.quadraticCurveTo(finApexX, finApexY, tailBase.x, tailBase.y);
      ctx.lineTo(waist.x, waist.y);
      ctx.closePath();
      ctx.fill();

      // Dorsal Specular Spine Highlight
      ctx.strokeStyle = `rgba(255, 255, 255, ${(depthAlpha * 0.60).toFixed(2)})`;
      ctx.lineWidth = Math.max(0.65, 1.8 * this.scale);
      ctx.beginPath();
      ctx.moveTo(head.x, head.y);
      ctx.quadraticCurveTo(chest.x, chest.y, waist.x, waist.y);
      ctx.stroke();

      // ================= 6. EYES & BARBELS (ตาและหนวดปลาคาร์ปแท้) =================
      const eyeOffset = this.width * 0.38;
      const eyeForward = this.length * 0.08;
      const eyeRadius = Math.max(0.9, 1.4 * this.scale);

      // Eye bases
      const eyeLeftX = head.x + normalX * eyeOffset + Math.cos(swimDir) * eyeForward;
      const eyeLeftY = head.y + normalY * eyeOffset + Math.sin(swimDir) * eyeForward;
      const eyeRightX = head.x - normalX * eyeOffset + Math.cos(swimDir) * eyeForward;
      const eyeRightY = head.y - normalY * eyeOffset + Math.sin(swimDir) * eyeForward;

      // Dark pupil
      ctx.fillStyle = '#1e272e';
      ctx.beginPath();
      ctx.arc(eyeLeftX, eyeLeftY, eyeRadius, 0, Math.PI * 2);
      ctx.arc(eyeRightX, eyeRightY, eyeRadius, 0, Math.PI * 2);
      ctx.fill();

      // White catchlight sparkle
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(eyeLeftX - eyeRadius * 0.3, eyeLeftY - eyeRadius * 0.3, eyeRadius * 0.38, 0, Math.PI * 2);
      ctx.arc(eyeRightX - eyeRadius * 0.3, eyeRightY - eyeRadius * 0.3, eyeRadius * 0.38, 0, Math.PI * 2);
      ctx.fill();

      // Cute Koi Barbels (หนวดคู่หน้าปลาคาร์ป)
      if (this.scale > 0.45) {
        ctx.strokeStyle = hexToRgba(this.belly, depthAlpha * 0.7);
        ctx.lineWidth = Math.max(0.5, 0.75 * this.scale);
        const barbelLen = this.length * 0.15;
        const snoutX = head.x + Math.cos(swimDir) * (this.length * 0.16);
        const snoutY = head.y + Math.sin(swimDir) * (this.length * 0.16);

        ctx.beginPath();
        // Left barbel
        ctx.moveTo(snoutX + normalX * (this.width * 0.18), snoutY + normalY * (this.width * 0.18));
        ctx.quadraticCurveTo(
          snoutX + normalX * (this.width * 0.35) + Math.cos(swimDir) * (barbelLen * 0.5),
          snoutY + normalY * (this.width * 0.35) + Math.sin(swimDir) * (barbelLen * 0.5),
          snoutX + normalX * (this.width * 0.28) - Math.cos(swimDir) * (barbelLen * 0.8),
          snoutY + normalY * (this.width * 0.28) - Math.sin(swimDir) * (barbelLen * 0.8)
        );
        // Right barbel
        ctx.moveTo(snoutX - normalX * (this.width * 0.18), snoutY - normalY * (this.width * 0.18));
        ctx.quadraticCurveTo(
          snoutX - normalX * (this.width * 0.35) + Math.cos(swimDir) * (barbelLen * 0.5),
          snoutY - normalY * (this.width * 0.35) + Math.sin(swimDir) * (barbelLen * 0.5),
          snoutX - normalX * (this.width * 0.28) - Math.cos(swimDir) * (barbelLen * 0.8),
          snoutY - normalY * (this.width * 0.28) - Math.sin(swimDir) * (barbelLen * 0.8)
        );
        ctx.stroke();
      }

      ctx.restore();
    }
  }

  function initFishSchool() {
    riverFishSchool.length = 0;
    const fishCount = 8;
    // Layered 2.5D Depth Tiers:
    // 2 in far distance (0.13, 0.22) - small fish
    // 3 in mid river (0.38, 0.50, 0.62) - medium fish
    // 3 in foreground (0.75, 0.85, 0.94) - large fish
    const depthTiers = [0.14, 0.22, 0.38, 0.50, 0.62, 0.74, 0.85, 0.93];

    for (let i = 0; i < fishCount; i++) {
      const targetYRatio = depthTiers[i] + (Math.random() * 0.06 - 0.03);
      const f = new RiverFish(targetYRatio);
      f.x = (i / fishCount) * (rWidth || 1920) + (Math.random() * 100 - 50);
      riverFishSchool.push(f);
    }
  }

  // ================= 5. Krathong 2.5D River Physics =================
  class RiverKrathong {
    constructor(data, isNew = false) {
      this.data = data;
      this.id = data.id || `k_${Date.now()}_${Math.random()}`;
      this.isNew = isNew;

      this.rWidth = rWidth || window.innerWidth;
      this.rHeight = rHeight || (window.innerHeight * 0.5);

      // Depth (0.0 = Horizon/Far, 1.0 = Foreground/Near)
      if (isNew) {
        this.targetDepth = 0.65 + Math.random() * 0.3;
        this.depth = this.targetDepth;
        this.x = 0.25 + Math.random() * 0.5;
        this.isDescending = true;
        this.descentDuration = 3400; // ms
        this.descentStartTime = performance.now();
        this.descentStartY = -(rHeight * 0.76 || 420);
        this.descentProgress = 0;
      } else {
        this.depth = 0.08 + Math.random() * 0.88;
        this.x = Math.random();
        this.isDescending = false;
        this.descentProgress = 1;
      }

      // Very slow, tranquil river drift speed
      this.driftSpeed = (0.000005 + this.depth * 0.000008) * (Math.random() < 0.25 ? -1 : 1);
      this.bobPhase = Math.random() * Math.PI * 2;
      this.bobSpeed = 0.0016 + Math.random() * 0.0012;
      this.swayPhase = Math.random() * Math.PI * 2;

      this.currentY = 0;
      this.currentScale = 0.38 + this.depth * 0.62;

      // 2.5D Water Physics & Collision State
      this.vx = 0; // horizontal velocity impulse (px/frame)
      this.vy = 0; // vertical/depth velocity impulse (px/frame)
      this.impactTilt = 0; // dynamic torque tilt from collisions (deg)
      this.lastCollideTime = 0;

      this.createDOM();
    }

    createDOM() {
      const typeMeta = KR_TYPES[this.data.krathongType] || KR_TYPES.royal;

      this.el = document.createElement('div');
      this.el.className = 'krathong-river-item' + (this.isNew ? ' new-arrival' : '');
      this.el.dataset.id = this.id;

      this.el.innerHTML = `
        ${this.isNew ? `
          <div class="kr-new-badge">
            <span class="badge-sparkle">✨</span>
            <span class="badge-txt">กระทงใหม่</span>
          </div>
          <div class="kr-spotlight-aura"></div>
        ` : ''}
        <div class="kr-body-wrap">
          <img src="${typeMeta.image}" alt="${typeMeta.title}" class="kr-cutout-img">
        </div>
        <div class="kr-name-badge">${escapeHTML(this.data.senderName || 'ผู้โดยสารนิรนาม')} ✦</div>
      `;

      this.el.addEventListener('click', (e) => {
        e.stopPropagation();
        openKrathongDetail(this.data);
      });

      if (this.isDescending) {
        this.el.classList.add('is-descending');
      }

      krathongsRiverLayer.appendChild(this.el);

      if (this.isNew) {
        this.startStardustEmitter();
      }
    }

    startStardustEmitter() {
      const symbols = ['✨', '✦', '⋆', '•', '🌟'];
      this.stardustInterval = setInterval(() => {
        if (!this.el || !this.el.parentNode) {
          if (this.stardustInterval) clearInterval(this.stardustInterval);
          return;
        }
        const particle = document.createElement('div');
        particle.className = 'kr-stardust-particle';
        particle.textContent = symbols[Math.floor(Math.random() * symbols.length)];
        const startX = (Math.random() * 80 - 40);
        const startY = (Math.random() * 30 - 15);
        const driftX = (Math.random() * 50 - 25);
        particle.style.left = `calc(50% + ${startX.toFixed(1)}px)`;
        particle.style.top = `calc(40% + ${startY.toFixed(1)}px)`;
        particle.style.setProperty('--sd-dx', `${driftX.toFixed(1)}px`);
        this.el.appendChild(particle);

        setTimeout(() => {
          if (particle.parentNode) particle.parentNode.removeChild(particle);
        }, 1600);
      }, 220);

      // Fade out and cleanup new-arrival effects after 8.5 seconds
      setTimeout(() => {
        if (this.stardustInterval) clearInterval(this.stardustInterval);
        if (this.el) {
          const badge = this.el.querySelector('.kr-new-badge');
          const aura = this.el.querySelector('.kr-spotlight-aura');
          if (badge) badge.style.opacity = '0';
          if (aura) aura.style.opacity = '0';
          setTimeout(() => {
            if (badge && badge.parentNode) badge.parentNode.removeChild(badge);
            if (aura && aura.parentNode) aura.parentNode.removeChild(aura);
            if (this.el) this.el.classList.remove('new-arrival');
          }, 900);
        }
      }, 8500);
    }

    update(now) {
      this.currentScale = 0.38 + this.depth * 0.62;

      if (this.isDescending) {
        const elapsed = now - this.descentStartTime;
        this.descentProgress = Math.min(1, elapsed / this.descentDuration);
        const ease = 1 - Math.pow(1 - this.descentProgress, 3);

        const targetY = this.depth * rHeight;
        this.currentY = this.descentStartY + (targetY - this.descentStartY) * ease;
        this.currentScale = (0.35 + (this.currentScale - 0.35) * ease) * (1 + (1 - ease) * 0.4);

        if (this.descentProgress >= 1) {
          this.isDescending = false;
          this.el.classList.remove('is-descending');
          const splashX = this.x * rWidth;
          createWaterSplash(splashX, targetY + 30 * this.currentScale);
          createArrivalSpotlight(splashX, targetY + 18 * this.currentScale);
          playLandingChime();
        }
      } else {
        let deltaX = this.driftSpeed * 16;

        if (ENABLE_COLLISION_PHYSICS) {
          deltaX += (this.vx / (rWidth || 1920));
          this.depth += (this.vy / (rHeight || 600));
          this.depth = Math.max(0.08, Math.min(0.96, this.depth));

          // Fluid viscosity damping
          this.vx *= 0.93;
          this.vy *= 0.93;
          this.impactTilt *= 0.90;
        }

        this.x += deltaX;
        if (this.x > 1.06) this.x = -0.06;
        if (this.x < -0.06) this.x = 1.06;

        const bobAmp = 1.6 + this.depth * 3.4;
        const bobOffset = Math.sin(now * this.bobSpeed + this.bobPhase) * bobAmp;
        this.currentY = (this.depth * rHeight) + bobOffset;
      }

      const baseSway = Math.sin(now * 0.0014 + this.swayPhase) * (1.0 + this.depth * 1.2);
      const totalSway = baseSway + (ENABLE_COLLISION_PHYSICS ? this.impactTilt : 0);

      const posX = this.x * rWidth;
      const zIndex = this.isDescending ? 9999 : Math.floor(this.depth * 1000);

      this.el.style.left = `${posX}px`;
      this.el.style.top = `${this.currentY}px`;
      this.el.style.transform = `translate(-50%, -65%) scale(${this.currentScale.toFixed(3)}) rotate(${totalSway.toFixed(2)}deg)`;
      this.el.style.zIndex = zIndex;
    }

    triggerReaction(type) {
      if (!this.el) return;

      // 1. Subtle buoyant water bob (No heavy red smoke covering the krathong!)
      this.el.classList.remove('kr-pulse-react');
      void this.el.offsetWidth; // trigger reflow
      this.el.classList.add('kr-pulse-react');
      setTimeout(() => {
        if (this.el) this.el.classList.remove('kr-pulse-react');
      }, 700);

      // 2. TikTok Live Floating Stream (Lifting up along flanks into the high sky, never covering krathong or name)
      const count = type === 'heart' ? 2 : 3;
      const symbols = type === 'heart' 
        ? ['❤️', '💖', '💕', '💗', '💓', '🧡'] 
        : ['✨', '🌟', '✦', '💫', '⭐'];

      for (let i = 0; i < count; i++) {
        setTimeout(() => {
          if (!this.el || !this.el.parentNode) return;
          const p = document.createElement('div');
          p.className = `kr-tiktok-particle react-${type}`;
          p.textContent = symbols[Math.floor(Math.random() * symbols.length)];

          // Always rise along the LEFT flank (ลอยขึ้นฝั่งซ้ายของกระทงอย่างเดียว ตามที่ผู้ใช้กำหนด)
          const side = -1;
          const startX = -1 * (42 + Math.random() * 22);
          const sway1 = -(Math.random() * 16 + 10);
          const sway2 = (Math.random() * 14 + 6);
          const rot = (Math.random() * 32 - 16) + 'deg';
          const duration = 2.0 + Math.random() * 0.5; // 2.0s - 2.5s

          p.style.setProperty('--start-x', `${startX.toFixed(1)}px`);
          p.style.setProperty('--sway-1', `${sway1.toFixed(1)}px`);
          p.style.setProperty('--sway-2', `${sway2.toFixed(1)}px`);
          p.style.setProperty('--rot', rot);
          p.style.animationDuration = `${duration.toFixed(2)}s`;

          // Random font size variation like TikTok
          const fSize = 24 + Math.floor(Math.random() * 12);
          p.style.fontSize = `${fSize}px`;

          this.el.appendChild(p);

          setTimeout(() => {
            if (p.parentNode) p.parentNode.removeChild(p);
          }, duration * 1000);
        }, i * 150);
      }

      // 3. Play subtle audio chime if audio enabled
      if (audioEnabled) {
        if (type === 'heart') playHeartChime();
        else playSparkleChime();
      }
    }

    destroy() {
      if (this.stardustInterval) clearInterval(this.stardustInterval);
      if (this.el && this.el.parentNode) this.el.parentNode.removeChild(this.el);
    }
  }

  // Live Krathong Reaction Dispatcher
  function triggerKrathongReaction(krathongId, type) {
    if (!krathongId) return;
    let kr = krathongsMap.get(krathongId);
    if (!kr) {
      // Fallback: search by data.id
      for (const item of krathongsMap.values()) {
        if (item.data && (item.data.id === krathongId || item.id === krathongId)) {
          kr = item;
          break;
        }
      }
    }

    if (kr) {
      kr.triggerReaction(type);
    }
  }

  // ================= 6. Water Splash & Arrival Spotlight Effect =================
  function createWaterSplash(x, y) {
    const splash = document.createElement('div');
    splash.className = 'splash-container';
    splash.style.left = `${x}px`;
    splash.style.top = `${y}px`;

    const ring1 = document.createElement('div');
    ring1.className = 'splash-ring ring-1';
    const ring2 = document.createElement('div');
    ring2.className = 'splash-ring ring-2';
    const ring3 = document.createElement('div');
    ring3.className = 'splash-ring ring-3';

    splash.appendChild(ring1);
    splash.appendChild(ring2);
    splash.appendChild(ring3);

    effectsLayer.appendChild(splash);

    setTimeout(() => {
      if (splash.parentNode) splash.parentNode.removeChild(splash);
    }, 1800);
  }

  function createArrivalSpotlight(x, y) {
    if (!effectsLayer) return;
    const wrapper = document.createElement('div');
    wrapper.className = 'spotlight-arrival-wrapper';
    wrapper.style.left = `${x}px`;
    wrapper.style.top = `${y}px`;

    wrapper.innerHTML = `
            <div class="spotlight-water-rings">
        <div class="spotlight-ring r1"></div>
        <div class="spotlight-ring r2"></div>
        <div class="spotlight-ring r3"></div>
      </div>
      <div class="spotlight-glow-pool"></div>
    `;

    effectsLayer.appendChild(wrapper);

    setTimeout(() => {
      if (wrapper.parentNode) wrapper.parentNode.removeChild(wrapper);
    }, 8600);
  }

  // ================= 6B. 2.5D Water Surface Collision Physics =================
  function resolveKrathongCollisions(now) {
    if (!ENABLE_COLLISION_PHYSICS || krathongsMap.size < 2) return;

    const items = Array.from(krathongsMap.values());
    const len = items.length;

    for (let i = 0; i < len; i++) {
      const a = items[i];
      if (a.isDescending) continue;

      const aX = a.x * rWidth;
      const aY = a.depth * rHeight;
      const aRadius = 48 * a.currentScale;
      const aMass = a.currentScale * a.currentScale;

      for (let j = i + 1; j < len; j++) {
        const b = items[j];
        if (b.isDescending) continue;

        // 1. Perspective Depth Gate: Krathongs only collide if they are in nearly the same river depth lane
        const depthDiff = Math.abs(a.depth - b.depth);
        if (depthDiff > 0.075) continue; // One is clearly behind the other along the river slope!

        // 2. 2.5D Elliptical Distance Check (Foreshortened vertical water plane)
        const bX = b.x * rWidth;
        const bY = b.depth * rHeight;
        const bRadius = 48 * b.currentScale;

        const dx = aX - bX;
        const dy = (aY - bY) / 0.65;
        const distSq = dx * dx + dy * dy;
        const minDist = aRadius + bRadius;

        if (distSq < minDist * minDist && distSq > 0.001) {
          const dist = Math.sqrt(distSq);
          const overlap = minDist - dist;

          // Normalized collision normal vector
          const nx = dx / dist;
          const ny = dy / dist;

          // Mass weighting (closer krathongs have more mass/inertia)
          const bMass = b.currentScale * b.currentScale;
          const totalMass = aMass + bMass;
          const ratioA = bMass / totalMass;
          const ratioB = aMass / totalMass;

          // Soft fluid spring repulsion force
          const repulsion = Math.min(overlap * 0.045, 1.8);
          const impulseX = nx * repulsion;
          const impulseY = ny * repulsion * 0.35; // gentler vertical shift

          a.vx += impulseX * ratioA;
          a.vy += impulseY * ratioA;
          b.vx -= impulseX * ratioB;
          b.vy -= impulseY * ratioB;

          // Dynamic impact torque sway (กระทงโคลงเคลงเบาๆ เมื่อสัมผัสกัน)
          const tiltAmount = Math.min(overlap * 0.22, 3.5);
          const tiltSign = nx > 0 ? 1 : -1;
          a.impactTilt += tiltSign * tiltAmount * ratioA;
          b.impactTilt -= tiltSign * tiltAmount * ratioB;
          a.impactTilt = Math.max(-7, Math.min(7, a.impactTilt));
          b.impactTilt = Math.max(-7, Math.min(7, b.impactTilt));

          // Contact micro-ripple on water
          if (now - a.lastCollideTime > 750 && now - b.lastCollideTime > 750 && overlap > 3) {
            a.lastCollideTime = now;
            b.lastCollideTime = now;
            const midX = (aX + bX) * 0.5;
            const midY = (a.currentY + b.currentY) * 0.5 + 18 * a.currentScale;
            createMicroContactRipple(midX, midY, a.currentScale);
          }
        }
      }
    }
  }

  function createMicroContactRipple(x, y, scale) {
    if (!effectsLayer) return;
    const ripple = document.createElement('div');
    ripple.className = 'contact-micro-ripple';
    ripple.style.left = `${x}px`;
    ripple.style.top = `${y}px`;
    ripple.style.transform = `translate(-50%, -50%) scale(${scale.toFixed(2)})`;
    effectsLayer.appendChild(ripple);

    setTimeout(() => {
      if (ripple.parentNode) ripple.parentNode.removeChild(ripple);
    }, 1150);
  }

  // ================= 7. Toast Announcements =================
  let toastTimer = null;
  function showToast(sender, wish) {
    if (!newToast) return;
    toastSender.textContent = `คุณ ${sender}`;
    toastWish.textContent = `“${wish}”`;

    newToast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      newToast.classList.remove('show');
    }, 6500);
  }

  // ================= 8. Modal Krathong Detail =================
  function openKrathongDetail(data) {
    const typeMeta = KR_TYPES[data.krathongType] || KR_TYPES.royal;
    modalKrImg.src = typeMeta.image;
    modalSender.textContent = `คุณ ${data.senderName || 'ผู้โดยสารนิรนาม'}`;
    modalType.textContent = `“กระทง${typeMeta.title}”`;
    modalWish.textContent = data.wishText || 'ขอให้ปีนี้มีความสุข สมหวังทุกประการ';

    if (data.timestamp) {
      const d = new Date(data.timestamp);
      modalTime.textContent = `ลอยเมื่อเวลา ${d.getHours().toString().padStart(2, '0')}:${d.getMinutes().toString().padStart(2, '0')} น.`;
    } else {
      modalTime.textContent = 'ลอยในค่ำคืนนี้';
    }

    krModalBackdrop.classList.add('active');
    krDetailModal.classList.add('active');
  }

  function closeKrathongDetail() {
    krModalBackdrop.classList.remove('active');
    krDetailModal.classList.remove('active');
  }

  if (krModalClose) krModalClose.addEventListener('click', closeKrathongDetail);
  if (krModalBackdrop) krModalBackdrop.addEventListener('click', closeKrathongDetail);

  // ================= 9. Add & Manage Krathongs =================
  function addOrUpdateKrathong(data, isNew = false) {
    if (!data || !data.id) return;

    if (krathongsMap.has(data.id)) {
      return;
    }

    const rk = new RiverKrathong(data, isNew);
    krathongsMap.set(data.id, rk);

    updateKrCount();

    if (isNew) {
      showToast(data.senderName || 'ผู้โดยสารนิรนาม', data.wishText || 'เดินทางปลอดภัย ไร้อุปสรรค');
      launchCelebrationBurst();
    }
  }

  function updateKrCount() {
    if (krCountEl) {
      krCountEl.textContent = krathongsMap.size;
    }
    checkMilestoneCelebration(krathongsMap.size);
  }

  // ================= 10. QR Code Setup with Live Re-render =================
  function renderQRCode(urlToEncode) {
    if (!urlToEncode || !qrcodeContainer) return;
    if (qrUrlBox) qrUrlBox.textContent = urlToEncode;
    qrcodeContainer.innerHTML = '';

    if (window.QRCode) {
      new QRCode(qrcodeContainer, {
        text: urlToEncode,
        width: 150,
        height: 150,
        colorDark: '#040916',
        colorLight: '#ffffff',
        correctLevel: QRCode.CorrectLevel.M
      });
    }

    if (qrSubtitle) {
      if (activeMode === 'public') {
        qrSubtitle.textContent = '🟢 สแกนได้ทั้งเน็ต 4G/5G และ Wi-Fi';
        qrSubtitle.style.color = '#8bd4b0';
      } else {
        qrSubtitle.textContent = '🏠 สำหรับเครื่องที่ต่อ Wi-Fi เดียวกัน';
        qrSubtitle.style.color = '#f3d489';
      }
    }
  }

  async function fetchServerInfo() {
    try {
      const res = await fetch('/api/info');
      const info = await res.json();
      currentLocalUrl = info.localUrl || `http://${info.ip}:${info.port}/mobile.html`;
      if (info.publicUrl) {
        currentPublicUrl = info.publicUrl;
      } else if (window.location.protocol === 'https:' || (!window.location.hostname.includes('localhost') && !window.location.hostname.includes('127.0.0.1'))) {
        currentPublicUrl = `${window.location.origin}/mobile.html`;
      }

      const target = (activeMode === 'public' && currentPublicUrl) ? currentPublicUrl : (currentPublicUrl || currentLocalUrl);
      renderQRCode(target);
    } catch (e) {
      console.warn('Could not fetch server info, fallback to current origin:', e);
      renderQRCode(window.location.origin + '/mobile.html');
    }
  }

  if (btnModePublic) {
    btnModePublic.addEventListener('click', () => {
      activeMode = 'public';
      btnModePublic.classList.add('active');
      btnModeLocal.classList.remove('active');
      renderQRCode(currentPublicUrl || currentLocalUrl);
    });
  }

  if (btnModeLocal) {
    btnModeLocal.addEventListener('click', () => {
      activeMode = 'local';
      btnModeLocal.classList.add('active');
      btnModePublic.classList.remove('active');
      renderQRCode(currentLocalUrl);
    });
  }

  if (qrToggleBtn && qrCard) {
    qrToggleBtn.addEventListener('click', () => {
      qrCard.classList.toggle('minimized');
      qrToggleBtn.textContent = qrCard.classList.contains('minimized') ? '+' : '−';
    });
  }

  // ================= 11. Controls Bar =================
  if (btnAudio) {
    btnAudio.addEventListener('click', () => {
      initAudio();
      audioEnabled = !audioEnabled;
      btnAudio.querySelector('.icon').textContent = audioEnabled ? '🔊' : '🔇';
      btnAudio.querySelector('.label').textContent = audioEnabled ? 'เปิดเสียง' : 'ปิดเสียง';
    });
  }

  if (btnFireworks) {
    btnFireworks.addEventListener('click', () => {
      initAudio();
      triggerGrandMilestoneShow(krathongsMap.size || 10);
    });
  }

  if (btnFullscreen) {
    btnFullscreen.addEventListener('click', () => {
      if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen().catch(err => console.warn(err));
      } else {
        document.exitFullscreen().catch(err => console.warn(err));
      }
    });
  }

  if (btnPhysics) {
    btnPhysics.addEventListener('click', () => {
      ENABLE_COLLISION_PHYSICS = !ENABLE_COLLISION_PHYSICS;
      btnPhysics.classList.toggle('active', ENABLE_COLLISION_PHYSICS);
      console.log(`[Physics] 2.5D Collision Physics: ${ENABLE_COLLISION_PHYSICS ? 'ON' : 'OFF'}`);
    });
  }

  // Global toggle function for user or console
  window.togglePhysics = function(enable) {
    ENABLE_COLLISION_PHYSICS = (enable !== undefined) ? !!enable : !ENABLE_COLLISION_PHYSICS;
    if (btnPhysics) btnPhysics.classList.toggle('active', ENABLE_COLLISION_PHYSICS);
    console.log(`[Physics] 2.5D Collision Physics: ${ENABLE_COLLISION_PHYSICS ? 'ON' : 'OFF'}`);
    return ENABLE_COLLISION_PHYSICS;
  };

  // Simulator Test Button
  if (btnSimulate) {
    btnSimulate.addEventListener('click', () => {
      const sampleNames = ['น้องฟ้าใส', 'กัปตันชานนท์', 'แอนนา', 'คุณภีร์', 'ญาญ่า', 'ผู้โดยสารตรัง'];
      const sampleWishes = [
        'ขอให้ทุกเที่ยวบินปลอดภัย ราบรื่นตลอดเส้นทาง',
        'การงานก้าวหน้า ค้าขายร่ำรวย เงินทองไหลมาเทมา',
        'ขอให้ปีนี้เป็นปีที่ใจดี มีรอยยิ้มในทุกๆ วัน',
        'สุขภาพร่างกายแข็งแรง ไร้โรคภัยเบียดเบียน'
      ];
      const types = ['royal', 'minimal', 'lotus', 'marigold', 'eco', 'bread', 'airplane', 'dugong'];

      addOrUpdateKrathong({
        id: `sim_${Date.now()}`,
        senderName: sampleNames[Math.floor(Math.random() * sampleNames.length)],
        wishText: sampleWishes[Math.floor(Math.random() * sampleWishes.length)],
        krathongType: types[Math.floor(Math.random() * types.length)],
        timestamp: Date.now()
      }, true);
    });
  }

  // ================= 12. Real-time SSE Stream =================
  function initSSE() {
    const eventSource = new EventSource('/api/events');

    eventSource.onopen = () => {
      console.log('[SSE] River Display connected to real-time events.');
    };

    eventSource.addEventListener('init', (e) => {
      try {
        const list = JSON.parse(e.data);
        console.log(`[SSE] Initialized ${list.length} krathongs.`);
        list.forEach(k => addOrUpdateKrathong(k, false));
      } catch (err) {
        console.error('Error parsing init krathongs:', err);
      }
    });

    eventSource.addEventListener('tunnel_url', (e) => {
      try {
        const d = JSON.parse(e.data);
        console.log('[SSE] Live Tunnel URL received:', d);
        if (d.publicUrl) {
          currentPublicUrl = d.publicUrl;
          if (activeMode === 'public') {
            renderQRCode(currentPublicUrl);
          }
        }
        if (d.localUrl) currentLocalUrl = d.localUrl;
      } catch (err) {
        console.error('Error parsing tunnel_url:', err);
      }
    });

    eventSource.addEventListener('new_krathong', (e) => {
      try {
        const k = JSON.parse(e.data);
        console.log('[SSE] New Krathong arrived on river:', k);
        addOrUpdateKrathong(k, true);
      } catch (err) {
        console.error('Error parsing new krathong:', err);
      }
    });

    eventSource.addEventListener('krathong_reaction', (e) => {
      try {
        const d = JSON.parse(e.data);
        if (d && d.krathongId) {
          triggerKrathongReaction(d.krathongId, d.type);
        }
      } catch (err) {
        console.error('Error parsing krathong_reaction:', err);
      }
    });

    eventSource.addEventListener('clear', () => {
      krathongsMap.forEach(k => k.destroy());
      krathongsMap.clear();
      updateKrCount();
    });

    eventSource.addEventListener('delete_krathong', (e) => {
      try {
        const d = JSON.parse(e.data);
        if (d && d.id) {
          const kr = krathongsMap.get(d.id);
          if (kr) {
            kr.destroy();
            krathongsMap.delete(d.id);
            updateKrCount();
            console.log(`[Admin Event] Deleted krathong ${d.id} from display.`);
          }
        }
      } catch (err) {
        console.error('Error handling delete_krathong:', err);
      }
    });

    eventSource.addEventListener('highlight_krathong', (e) => {
      try {
        const d = JSON.parse(e.data);
        if (d && d.id) {
          const kr = krathongsMap.get(d.id);
          if (kr) {
            createArrivalSpotlight(kr.x * (rWidth || 1920), kr.currentY + 18 * kr.currentScale);
            if (audioEnabled) playLandingChime();
            console.log(`[Admin Event] Highlighted krathong ${d.id}`);
          }
        }
      } catch (err) {
        console.error('Error handling highlight_krathong:', err);
      }
    });

    eventSource.addEventListener('grand_fireworks', (e) => {
      try {
        const d = JSON.parse(e.data);
        const count = d.count || 6;
        for (let i = 0; i < count; i++) {
          setTimeout(() => launchFirework(), i * 320);
        }
        console.log(`[Admin Event] Triggered grand fireworks show (${count} bursts)`);
      } catch (err) {
        console.error('Error handling grand_fireworks:', err);
      }
    });

    eventSource.onerror = (err) => {
      console.warn('[SSE] EventSource disconnected, retrying automatically...', err);
    };
  }

  // ================= 13. 60 FPS Render Loop =================
  function animate(now) {
    // 1. Solve 2.5D Water Surface Collision Physics
    if (ENABLE_COLLISION_PHYSICS) {
      resolveKrathongCollisions(now);
    }

    // 2. Update Krathongs DOM physics & sway
    krathongsMap.forEach(k => k.update(now));

    // 3. Render Canvas River Water, Waves, Moonlight & Krathong Reflections
    renderRiverWater(now);

    // 4. Render Canvas Fireworks & Particle System
    updateFireworks(now);

    requestAnimationFrame(animate);
  }

  // Helper
  function escapeHTML(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  // ================= 8. Riverbank Fireflies =================
  function initFireflies() {
    const container = document.getElementById('firefliesLayer');
    if (!container) return;
    const fireflyCount = 18;
    for (let i = 0; i < fireflyCount; i++) {
      const f = document.createElement('div');
      f.className = 'firefly';

      // Cluster: 45% left shore, 45% right shore, 10% center water line
      let xPos;
      if (i < 8) {
        xPos = 2 + Math.random() * 26; // 2% to 28% (left shore reeds)
      } else if (i < 16) {
        xPos = 72 + Math.random() * 26; // 72% to 98% (right shore reeds)
      } else {
        xPos = 30 + Math.random() * 40; // 30% to 70% (center water pads)
      }
      const yPos = 32 + Math.random() * 62; // 32% to 94% of riverbank height

      f.style.left = `${xPos.toFixed(1)}%`;
      f.style.top = `${yPos.toFixed(1)}%`;

      const dur = (5 + Math.random() * 4).toFixed(1);
      const glowDur = (2.2 + Math.random() * 2.5).toFixed(1);
      const delay = (Math.random() * 5).toFixed(1);
      const driftX = (Math.random() * 40 - 20).toFixed(0);
      const driftY = (-(15 + Math.random() * 28)).toFixed(0);

      f.style.setProperty('--f-dur', `${dur}s`);
      f.style.setProperty('--f-glow-dur', `${glowDur}s`);
      f.style.setProperty('--f-drift-x', `${driftX}px`);
      f.style.setProperty('--f-drift-y', `${driftY}px`);
      f.style.animationDelay = `${delay}s`;

      container.appendChild(f);
    }
  }

  // Init Execution
  initStars();
  initLanterns();
  initMoonSparkles();
  initRiverMicroWavelets();
  initFireflies();
  initFishSchool();
  fetchServerInfo();
  initSSE();
  requestAnimationFrame(animate);

  // Periodic poll check in case Cloudflare tunnel was delayed
  setInterval(() => {
    if (!currentPublicUrl) {
      fetchServerInfo();
    }
  }, 5000);
})();
