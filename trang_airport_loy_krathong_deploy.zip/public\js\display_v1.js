/**
 * Trang Airport Loy Krathong 2026 - Big Screen Display Engine
 * 60 FPS Fluid Physics, Real-time SSE Sync & Web Audio FX
 */

(() => {
  // DOM Elements
  const pondContainer = document.getElementById('pondContainer');
  const krathongsLayer = document.getElementById('krathongsLayer');
  const krCountEl = document.getElementById('krCount');
  const newToast = document.getElementById('newToast');
  const toastSender = document.getElementById('toastSender');
  const toastWish = document.getElementById('toastWish');
  const qrCard = document.getElementById('qrCard');
  const qrToggleBtn = document.getElementById('qrToggleBtn');
  const qrUrlBox = document.getElementById('qrUrlBox');
  const qrSubtitle = document.getElementById('qrSubtitle');
  const qrcodeContainer = document.getElementById('qrcode');
  const btnModePublic = document.getElementById('btnModePublic');
  const btnModeLocal = document.getElementById('btnModeLocal');
  const btnAudio = document.getElementById('btnAudio');
  const btnFullscreen = document.getElementById('btnFullscreen');
  const btnSimulate = document.getElementById('btnSimulate');
  const btnClear = document.getElementById('btnClear');
  const lanternsContainer = document.getElementById('lanternsContainer');

  // Modals
  const krModal = document.getElementById('krModal');
  const krModalBackdrop = document.getElementById('krModalBackdrop');
  const krModalClose = document.getElementById('krModalClose');
  const modalKrImg = document.getElementById('modalKrImg');
  const modalKrType = document.getElementById('modalKrType');
  const modalSender = document.getElementById('modalSender');
  const modalTime = document.getElementById('modalTime');
  const modalWishText = document.getElementById('modalWishText');

  const simModal = document.getElementById('simModal');
  const simModalBackdrop = document.getElementById('simModalBackdrop');
  const simModalClose = document.getElementById('simModalClose');
  const btnConfirmSim = document.getElementById('btnConfirmSim');

  // Krathong Design Meta
  const KR_TYPES = {
    royal: { title: 'ราชพฤกษ์ทอง', image: 'assets/images/royal.jpeg' },
    minimal: { title: 'บัวมินิมัล', image: 'assets/images/minimal.jpeg' },
    lotus: { title: 'บัวจันทร์', image: 'assets/images/lotus.jpeg' },
    marigold: { title: 'มณีบุปผา', image: 'assets/images/marigold.jpeg' },
    eco: { title: 'ธาราธรรมชาติ', image: 'assets/images/eco.jpeg' }
  };

  // State
  let krathongList = []; // Array of { id, senderName, wishText, krathongType, x, y, vx, vy, el, ... }
  let audioEnabled = false;
  let audioCtx = null;
  let toastTimer = null;

  // Initialize Sky Lanterns in background
  function initLanterns() {
    for (let i = 0; i < 9; i++) {
      spawnLantern();
    }
  }

  function spawnLantern() {
    const l = document.createElement('div');
    l.className = 'sky-lantern';
    l.textContent = '🏮';
    const left = Math.random() * 95;
    const duration = 25 + Math.random() * 25;
    const delay = Math.random() * 20;
    const size = 14 + Math.random() * 12;

    l.style.left = `${left}%`;
    l.style.bottom = '-20px';
    l.style.fontSize = `${size}px`;
    l.style.animationDuration = `${duration}s`;
    l.style.animationDelay = `${delay}s`;

    lanternsContainer.appendChild(l);
  }

  // ================= Sound Effects (Web Audio API) =================
  function initAudio() {
    if (!audioCtx) {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      audioCtx = new AudioContext();
    }
    if (audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
  }

  function playWaterSplashChime() {
    if (!audioEnabled || !audioCtx) return;
    try {
      const now = audioCtx.currentTime;

      // Soft water plunge (Noise filtered)
      const bufferSize = audioCtx.sampleRate * 0.4;
      const buffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = Math.random() * 2 - 1;
      }
      const noise = audioCtx.createBufferSource();
      noise.buffer = buffer;

      const filter = audioCtx.createBiquadFilter();
      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(450, now);
      filter.frequency.exponentialRampToValueAtTime(80, now + 0.35);

      const gain = audioCtx.createGain();
      gain.gain.setValueAtTime(0.3, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(audioCtx.destination);
      noise.start(now);

      // Sweet pentatonic chime (Tibetan singing bowl / temple bell tone)
      const freqs = [528, 792, 1056]; // Solfeggio love & transformation tones
      freqs.forEach((freq, index) => {
        const osc = audioCtx.createOscillator();
        const oscGain = audioCtx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + index * 0.08);

        oscGain.gain.setValueAtTime(0.12 / (index + 1), now + index * 0.08);
        oscGain.gain.exponentialRampToValueAtTime(0.0001, now + 2.0);

        osc.connect(oscGain);
        oscGain.connect(audioCtx.destination);

        osc.start(now + index * 0.08);
        osc.stop(now + 2.2);
      });
    } catch (e) {
      console.warn('Audio play error:', e);
    }
  }

  // ================= Krathong DOM & Physics =================
  function createKrathongElement(data, isNew = false) {
    const item = document.createElement('div');
    item.className = 'krathong-item' + (isNew ? ' descending' : '');
    item.dataset.id = data.id;

    const typeMeta = KR_TYPES[data.krathongType] || KR_TYPES.royal;

    item.innerHTML = `
      <div class="candle-flame">🕯️</div>
      <div class="kr-ripple"></div>
      <img src="${typeMeta.image}" alt="${typeMeta.title}" class="kr-avatar">
      <div class="kr-badge">${escapeHTML(data.senderName)} ✦</div>
    `;

    // Click to view wish modal
    item.addEventListener('click', (e) => {
      e.stopPropagation();
      openKrathongDetail(data);
    });

    krathongsLayer.appendChild(item);
    return item;
  }

  // Create Water Splash effect when krathong lands
  function createWaterSplash(x, y) {
    const splash = document.createElement('div');
    splash.className = 'splash-container';
    splash.style.left = `${x}px`;
    splash.style.top = `${y}px`;

    const ring1 = document.createElement('div');
    ring1.className = 'splash-ring ring-1';
    const ring2 = document.createElement('div');
    ring2.className = 'splash-ring ring-2';
    const ring3 = document.createElement('div');
    ring3.className = 'splash-ring ring-3';
    splash.append(ring1, ring2, ring3);

    for (let i = 0; i < 8; i++) {
      const spark = document.createElement('div');
      spark.className = 'splash-spark';
      const angle = (i / 8) * Math.PI * 2;
      const dist = 35 + Math.random() * 45;
      spark.style.setProperty('--dx', `${Math.cos(angle) * dist}px`);
      spark.style.setProperty('--dy', `${Math.sin(angle) * (dist * 0.5) - 15}px`);
      splash.appendChild(spark);
    }

    pondContainer.appendChild(splash);
    setTimeout(() => splash.remove(), 2000);
  }

  function addOrUpdateKrathong(data, isNew = false) {
    const existing = krathongList.find(k => k.id === data.id);
    if (existing) return;

    const pondRect = pondContainer.getBoundingClientRect();
    const width = pondRect.width || window.innerWidth;
    const height = pondRect.height || (window.innerHeight * 0.75);

    let px, py;
    let isDescending = false;
    let startX = 0, startY = 0, targetX = 0, targetY = 0;

    if (isNew) {
      isDescending = true;
      // Land in the visible middle area of the pond (away from corners)
      targetX = width * (0.22 + Math.random() * 0.56);
      targetY = height * (0.22 + Math.random() * 0.35);

      // Start high up in the night sky (right below the moon)
      startX = targetX + (Math.random() - 0.5) * 50;
      startY = pondRect.top ? -(pondRect.top * 0.72) : -130;

      px = startX;
      py = startY;
    } else {
      px = (data.x !== undefined ? data.x : (0.15 + Math.random() * 0.7)) * width;
      py = (data.y !== undefined ? data.y : (0.15 + Math.random() * 0.7)) * height;
    }

    const el = createKrathongElement(data, isNew);

    const krObj = {
      ...data,
      el,
      x: px,
      y: py,
      isDescending,
      startTime: performance.now(),
      descentDuration: 2400, // 2.4 seconds majestic descent from sky to water
      startX,
      startY,
      targetX,
      targetY,
      vx: (Math.random() - 0.5) * 0.25,
      vy: (Math.random() - 0.5) * 0.2,
      bobAngle: Math.random() * Math.PI * 2,
      bobSpeed: 0.015 + Math.random() * 0.02
    };

    krathongList.push(krObj);
    updateCounter();
  }

  function updateCounter() {
    krCountEl.textContent = krathongList.length;
  }

  function triggerNewArrivalEvent(kr) {
    // Show toast
    toastSender.textContent = kr.senderName;
    toastWish.textContent = `“${kr.wishText}”`;
    newToast.classList.add('show');

    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      newToast.classList.remove('show');
    }, 6500);
  }

  // Physics Simulation Loop (60 FPS)
  function startPhysicsLoop() {
    let lastTime = performance.now();

    function loop(now) {
      const dt = Math.min((now - lastTime) / 1000, 0.1);
      lastTime = now;

      const pondRect = pondContainer.getBoundingClientRect();
      const pw = pondRect.width;
      const ph = pondRect.height;
      const margin = 65;

      const timeSec = now * 0.001;

      // Update positions
      for (let i = 0; i < krathongList.length; i++) {
        const k = krathongList[i];

        // 1. Descending from sky animation
        if (k.isDescending) {
          const elapsed = now - k.startTime;
          const p = Math.min(elapsed / k.descentDuration, 1);

          // Smooth cubic ease-out
          const ease = 1 - Math.pow(1 - p, 2.6);
          k.x = k.startX + (k.targetX - k.startX) * ease;
          k.y = k.startY + (k.targetY - k.startY) * ease;

          // Scale from 1.6 in the sky down to 1.0 at water level
          const scale = 1.6 - 0.6 * ease;
          // Gentle celestial wobble during descent
          const wobble = Math.sin(p * Math.PI * 2) * 3;

          k.el.style.transform = `translate(${k.x}px, ${k.y}px) scale(${scale}) rotate(${wobble}deg)`;

          if (p >= 1) {
            // Touchdown in water!
            k.isDescending = false;
            k.el.classList.remove('descending');
            k.x = k.targetX;
            k.y = k.targetY;
            k.vx = (Math.random() - 0.5) * 0.2;
            k.vy = 0.12;

            createWaterSplash(k.x, k.y);
            playWaterSplashChime();
            triggerNewArrivalEvent(k);
          }
          continue; // Skip water physics while in the air
        }

        // 2. Normal Water Physics
        // Organic current drift (Gentle wave vector)
        const currentForceX = Math.sin(timeSec * 0.5 + k.y * 0.005) * 0.12;
        const currentForceY = Math.cos(timeSec * 0.4 + k.x * 0.005) * 0.08;

        k.vx += currentForceX * dt;
        k.vy += currentForceY * dt;

        // Apply friction
        k.vx *= 0.985;
        k.vy *= 0.985;

        k.x += k.vx;
        k.y += k.vy;

        // Soft boundary repulsion (Gentle shore waves pushing back to center)
        if (k.x < margin) {
          k.vx += (margin - k.x) * 0.04;
        } else if (k.x > pw - margin) {
          k.vx -= (k.x - (pw - margin)) * 0.04;
        }

        if (k.y < margin) {
          k.vy += (margin - k.y) * 0.04;
        } else if (k.y > ph - margin) {
          k.vy -= (k.y - (ph - margin)) * 0.04;
        }

        // Soft inter-krathong repulsion so they don't overlap completely
        for (let j = i + 1; j < krathongList.length; j++) {
          const k2 = krathongList[j];
          if (k2.isDescending) continue;
          const dx = k2.x - k.x;
          const dy = k2.y - k.y;
          const distSq = dx * dx + dy * dy;
          const minDist = 90;

          if (distSq < minDist * minDist && distSq > 0.01) {
            const dist = Math.sqrt(distSq);
            const force = (minDist - dist) / minDist * 0.15;
            const fx = (dx / dist) * force;
            const fy = (dy / dist) * force;

            k.vx -= fx;
            k.vy -= fy;
            k2.vx += fx;
            k2.vy += fy;
          }
        }

        // Bobbing & GENTLE WAVE ROCKING (STRICTLY PREVENTS CAPSIZING!)
        k.bobAngle += k.bobSpeed;
        const bobOffset = Math.sin(k.bobAngle) * 5;

        // Max ±3.5 degrees gentle sway with the wave
        const rockAngle = Math.sin(timeSec * 1.5 + k.bobAngle) * 3.5;
        // Subtle bank with movement (Max ±2.5 degrees)
        const bankAngle = Math.max(-2.5, Math.min(2.5, k.vx * 8));
        const totalAngle = rockAngle + bankAngle;

        // Apply transform to DOM element - always strictly upright!
        k.el.style.transform = `translate(${k.x}px, ${k.y + bobOffset}px) rotate(${totalAngle}deg)`;
      }

      requestAnimationFrame(loop);
    }

    requestAnimationFrame(loop);
  }

  // ================= Detail Modal =================
  function openKrathongDetail(data) {
    const meta = KR_TYPES[data.krathongType] || KR_TYPES.royal;
    modalKrImg.src = meta.image;
    modalKrType.textContent = meta.title;
    modalSender.textContent = data.senderName;
    modalWishText.textContent = data.wishText;

    if (data.timestamp) {
      const d = new Date(data.timestamp);
      modalTime.textContent = 'ลอยเมื่อ: ' + d.toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit' }) + ' น.';
    } else {
      modalTime.textContent = 'ลอยในค่ำคืนนี้';
    }

    krModal.classList.add('show');
  }

  function closeKrathongDetail() {
    krModal.classList.remove('show');
  }

  krModalClose.addEventListener('click', closeKrathongDetail);
  krModalBackdrop.addEventListener('click', closeKrathongDetail);

  // ================= QR Code Setup =================
  let currentPublicUrl = '';
  let currentLocalUrl = '';
  let activeMode = 'public';

  function renderQRCode(urlToEncode) {
    if (!urlToEncode) return;
    qrUrlBox.textContent = urlToEncode;
    qrcodeContainer.innerHTML = '';

    if (window.QRCode) {
      new QRCode(qrcodeContainer, {
        text: urlToEncode,
        width: 140,
        height: 140,
        colorDark: '#08172c',
        colorLight: '#ffffff',
        correctLevel: QRCode.CorrectLevel.M
      });
    }

    if (qrSubtitle) {
      if (activeMode === 'public') {
        qrSubtitle.textContent = '🟢 สแกนได้ทั้งเน็ต 4G/5G และ Wi-Fi';
        qrSubtitle.style.color = '#8bd4b0';
      } else {
        qrSubtitle.textContent = '🏠 สำหรับเครื่องที่ต่อ Wi-Fi เดียวกัน';
        qrSubtitle.style.color = '#f3d489';
      }
    }
  }

  async function setupQRCode() {
    try {
      const res = await fetch('/api/info');
      const info = await res.json();
      currentLocalUrl = info.localUrl || `http://${info.ip}:${info.port}/mobile.html`;
      currentPublicUrl = info.publicUrl || '';

      const targetUrl = (activeMode === 'public' && currentPublicUrl) ? currentPublicUrl : currentLocalUrl;
      renderQRCode(targetUrl);
    } catch (e) {
      console.warn('Could not fetch server info, fallback to current origin:', e);
      const fallbackUrl = window.location.origin + '/mobile.html';
      renderQRCode(fallbackUrl);
    }
  }

  if (btnModePublic) {
    btnModePublic.addEventListener('click', () => {
      activeMode = 'public';
      btnModePublic.classList.add('active');
      btnModeLocal.classList.remove('active');
      renderQRCode(currentPublicUrl || currentLocalUrl);
    });
  }

  if (btnModeLocal) {
    btnModeLocal.addEventListener('click', () => {
      activeMode = 'local';
      btnModeLocal.classList.add('active');
      btnModePublic.classList.remove('active');
      renderQRCode(currentLocalUrl);
    });
  }

  qrToggleBtn.addEventListener('click', () => {
    qrCard.classList.toggle('minimized');
    qrToggleBtn.textContent = qrCard.classList.contains('minimized') ? '+' : '−';
  });

  // ================= Controls =================
  btnAudio.addEventListener('click', () => {
    initAudio();
    audioEnabled = !audioEnabled;
    btnAudio.querySelector('.icon').textContent = audioEnabled ? '🔊' : '🔇';
    btnAudio.querySelector('.label').textContent = audioEnabled ? 'เปิดเสียง' : 'ปิดเสียง';
    if (audioEnabled) {
      playWaterSplashChime();
    }
  });

  btnFullscreen.addEventListener('click', () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
    } else {
      document.exitFullscreen().catch(() => {});
    }
  });

  // Quick Simulator Modal
  btnSimulate.addEventListener('click', () => {
    simModal.classList.add('show');
  });

  simModalClose.addEventListener('click', () => simModal.classList.remove('show'));
  simModalBackdrop.addEventListener('click', () => simModal.classList.remove('show'));

  btnConfirmSim.addEventListener('click', async () => {
    const name = document.getElementById('simName').value.trim() || 'ผู้โดยสารทดสอบ';
    const wish = document.getElementById('simWish').value.trim() || 'ขอให้มีความสุข';
    const type = document.querySelector('input[name="simKrType"]:checked').value || 'royal';

    btnConfirmSim.disabled = true;
    btnConfirmSim.textContent = 'กำลังลอย...';

    try {
      const res = await fetch('/api/float', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          senderName: name,
          wishText: wish,
          krathongType: type
        })
      });
      await res.json();
      simModal.classList.remove('show');
    } catch (e) {
      alert('ส่งกระทงไม่สำเร็จ ตรวจสอบการเชื่อมต่อเซิร์ฟเวอร์');
    } finally {
      btnConfirmSim.disabled = false;
      btnConfirmSim.textContent = '🕯️ ปล่อยกระทงลงสระทันที';
    }
  });

  // Clear pond
  btnClear.addEventListener('click', async () => {
    if (confirm('คุณต้องการล้างกระทงทั้งหมดออกจากสระน้ำใช่หรือไม่?')) {
      try {
        await fetch('/api/clear', { method: 'POST' });
      } catch (e) {
        console.error('Clear failed:', e);
      }
    }
  });

  // ================= Real-time SSE Sync =================
  function connectSSE() {
    console.log('[SSE] Connecting to event stream...');
    const eventSource = new EventSource('/api/events');

    eventSource.addEventListener('init', (e) => {
      try {
        const list = JSON.parse(e.data);
        console.log(`[SSE] Received initial ${list.length} krathongs.`);
        list.forEach(k => addOrUpdateKrathong(k, false));
      } catch (err) {
        console.error('Error parsing init krathongs:', err);
      }
    });

    eventSource.addEventListener('tunnel_url', (e) => {
      try {
        const d = JSON.parse(e.data);
        console.log('[SSE] Tunnel URL received:', d);
        if (d.publicUrl) {
          currentPublicUrl = d.publicUrl;
          if (activeMode === 'public') {
            renderQRCode(currentPublicUrl);
          }
        }
        if (d.localUrl) currentLocalUrl = d.localUrl;
      } catch (err) {
        console.error('Error parsing tunnel_url:', err);
      }
    });

    eventSource.addEventListener('new_krathong', (e) => {
      try {
        const k = JSON.parse(e.data);
        console.log('[SSE] New krathong received:', k);
        addOrUpdateKrathong(k, true);
      } catch (err) {
        console.error('Error parsing new krathong:', err);
      }
    });

    eventSource.addEventListener('clear_pond', () => {
      krathongsLayer.innerHTML = '';
      krathongList = [];
      updateCounter();
    });

    eventSource.onerror = () => {
      console.warn('[SSE] Connection error. Reconnecting in 3s...');
      eventSource.close();
      setTimeout(connectSSE, 3000);
    };
  }

  // Helper
  function escapeHTML(str) {
    return (str || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  // Bootstrap
  initLanterns();
  setupQRCode();
  connectSSE();
  startPhysicsLoop();
})();
