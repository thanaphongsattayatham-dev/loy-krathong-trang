/**
 * Trang Airport Loy Krathong 2026 - Mobile Controller
 * With Confirm Stage, Interactive Swipe-Up Gesture, 
 * 3D Holographic Foil Card (Gyroscope & Touch Parallax),
 * and Souvenir PNG Exporter.
 */

(() => {
  // Views
  const formView = document.getElementById('formView');
  const launchView = document.getElementById('launchView');
  const successView = document.getElementById('successView');

  // Form Inputs
  const krGallery = document.getElementById('krGallery');
  const senderNameInput = document.getElementById('senderName');
  const wishTextInput = document.getElementById('wishText');
  const charCount = document.getElementById('charCount');
  const presetWishes = document.getElementById('presetWishes');
  const btnConfirmToLaunch = document.getElementById('btnConfirmToLaunch');

  // Launch Stage Elements
  const btnBackToForm = document.getElementById('btnBackToForm');
  const swipeStage = document.getElementById('swipeStage');
  const swipeKrathong = document.getElementById('swipeKrathong');
  const swipeKrImg = document.getElementById('swipeKrImg');
  const swipeSenderBadge = document.getElementById('swipeSenderBadge');
  const swipeWishPreview = document.getElementById('swipeWishPreview');
  const btnTapToFloat = document.getElementById('btnTapToFloat');

  // 3D Holographic Foil Card Elements (Pokemon TCG Style)
  const holoStage = document.getElementById('holoStage');
  const holoCard = document.getElementById('holoCard');
  const holoCardImg = document.getElementById('holoCardImg');
  const holoFoil = document.getElementById('holoFoil');
  const holoGlare = document.getElementById('holoGlare');

  // Souvenir Actions
  const cardCanvas = document.getElementById('cardCanvas');
  const btnShareLine = document.getElementById('btnShareLine');
  const btnShareFb = document.getElementById('btnShareFb');
  const btnDownloadCard = document.getElementById('btnDownloadCard');
  const btnFloatAgain = document.getElementById('btnFloatAgain');
  const fbModal = document.getElementById('fbModal');
  const btnCloseFbModal = document.getElementById('btnCloseFbModal');

  // Live Cheer Panel Elements
  const btnCheerHeart = document.getElementById('btnCheerHeart');
  const btnCheerSparkle = document.getElementById('btnCheerSparkle');
  const heartCountEl = document.getElementById('heartCount');
  const sparkleCountEl = document.getElementById('sparkleCount');
  const cheerFloatingFx = document.getElementById('cheerFloatingFx');
  let currentKrathongId = null;
  let heartCount = 0;
  let sparkleCount = 0;

  // Krathong Meta (High-Res Transparent PNGs)
  const KR_INFO = {
    royal: { title: 'ราชพฤกษ์ทอง', image: 'assets/images/royal.png' },
    minimal: { title: 'บัวมินิมัล', image: 'assets/images/minimal.png' },
    lotus: { title: 'บัวจันทร์', image: 'assets/images/lotus.png' },
    marigold: { title: 'มณีบุปผา', image: 'assets/images/marigold.png' },
    eco: { title: 'ธาราธรรมชาติ', image: 'assets/images/eco.png' },
    bread: { title: 'ขนมปังนำโชค', image: 'assets/images/bread.png' },
    airplane: { title: 'เวหานำโชค', image: 'assets/images/airplane.png' },
    dugong: { title: 'พะยูนธารา', image: 'assets/images/dugong.png' }
  };

  // State
  let selectedType = 'royal';
  let currentSenderName = '';
  let currentWishText = '';
  let currentLuckyNumber = '89';
  let cardDataUrl = '';
  let isLaunched = false;

  // Haptic Feedback Engine (Smooth tactile sensation on mobile)
  function triggerHaptic(type = 'tap') {
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      try {
        if (type === 'tap') {
          navigator.vibrate(12);
        } else if (type === 'drag') {
          navigator.vibrate(18);
        } else if (type === 'launch') {
          navigator.vibrate([35, 40, 70]);
        } else if (type === 'success') {
          navigator.vibrate([40, 50, 40]);
        }
      } catch (e) {}
    }
  }

  // Mobile Web Audio Gentle Ascending Whoosh Sound
  function playMobileWhoosh() {
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      if (ctx.state === 'suspended') ctx.resume();

      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(260, ctx.currentTime);
      osc.frequency.exponentialRampToValueAtTime(720, ctx.currentTime + 0.32);

      gain.gain.setValueAtTime(0.14, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.32);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.33);
    } catch (e) {}
  }

  // Auspicious Lucky Number Randomizer (2 digits or 3 digits)
  function generateLuckyNumber() {
    const isThreeDigit = Math.random() < 0.5;
    if (isThreeDigit) {
      const pool3 = ['789', '999', '168', '888', '569', '956', '365', '829', '639', '428', '289', '159', '919', '898'];
      if (Math.random() < 0.65) {
        return pool3[Math.floor(Math.random() * pool3.length)];
      } else {
        return String(Math.floor(100 + Math.random() * 900));
      }
    } else {
      const pool2 = ['89', '99', '28', '16', '68', '79', '88', '19', '59', '36', '42', '95', '65', '86'];
      if (Math.random() < 0.65) {
        return pool2[Math.floor(Math.random() * pool2.length)];
      } else {
        return String(Math.floor(10 + Math.random() * 90));
      }
    }
  }

  // 3D Touch / Pointer Parallax State (Gyro removed)
  let isTouchingCard = false;
  let targetRotX = 0;
  let targetRotY = 0;
  let currentRotX = 0;
  let currentRotY = 0;
  let idleTime = 0;

  // 1. Select Krathong in Gallery
  if (krGallery) {
    krGallery.querySelectorAll('.kr-card').forEach(card => {
      card.addEventListener('click', () => {
        triggerHaptic('tap');
        krGallery.querySelectorAll('.kr-card').forEach(c => c.classList.remove('selected'));
        card.classList.add('selected');
        selectedType = card.dataset.type;
      });
    });
  }

  // 2. Preset Wishes
  if (presetWishes) {
    presetWishes.querySelectorAll('.wish-tag').forEach(tag => {
      tag.addEventListener('click', () => {
        triggerHaptic('tap');
        const text = tag.textContent.replace(/^[^\s]+\s*/, ''); // strip leading emoji
        wishTextInput.value = text;
        updateCharCount();
        
        presetWishes.querySelectorAll('.wish-tag').forEach(t => t.classList.remove('active'));
        tag.classList.add('active');
      });
    });
  }

  // 3. Char Count
  if (wishTextInput) {
    wishTextInput.addEventListener('input', updateCharCount);
  }
  function updateCharCount() {
    if (charCount && wishTextInput) {
      charCount.textContent = wishTextInput.value.length;
    }
  }

  // ================= Background Profanity Filter (Silent, no UI warnings) =================
  const BAD_PATTERNS = [
    /เย็[\s._\-*]*ด[\s._\-*]*แม่+/gi,
    /เย[\s._\-*]*ด[\s._\-*]*แม่+/gi,
    /เ[\s._\-*]*ย็[\s._\-*]*ด+/gi,
    /เ[\s._\-*]*ย[\s._\-*]*ด+/gi,
    /ยสตน+/gi,
    /ค[\s._\-*]*ว[\s._\-*]*ย+/gi,
    /ค[\s._\-*]*ว[\s._\-*]*อ[\s._\-*]*ย+/gi,
    /ไอ้[\s._\-*]*ควย/gi,
    /อี[\s._\-*]*ควย/gi,
    /ค\.ว\.ย\./gi,
    /อม[\s._\-*]*ควย+/gi,
    /ดูด[\s._\-*]*ควย+/gi,
    /แดก[\s._\-*]*ควย+/gi,
    /เลีย[\s._\-*]*ควย+/gi,
    /เ[\s._\-*]*หี้[\s._\-*]*ย+/gi,
    /เ[\s._\-*]*หี[\s._\-*]*ย+/gi,
    /เ[\s._\-*]*ห้[\s._\-*]*ย+/gi,
    /ห[\s._\-*]*ยี่[\s._\-*]*ย+/gi,
    /ไอ้[\s._\-*]*เหี้ย/gi,
    /อี[\s._\-*]*เหี้ย/gi,
    /สั[\s._\-*]*ส+/gi,
    /สั[\s._\-*]*ด+/gi,
    /ไอ้[\s._\-*]*สัส/gi,
    /อี[\s._\-*]*สัส/gi,
    /ไอ้[\s._\-*]*สัด/gi,
    /อี[\s._\-*]*สัด/gi,
    /หี[\s._\-*]*แฉะ+/gi,
    /หี+/gi,
    /แตด+/gi,
    /หำ+/gi,
    /จู๋+/gi,
    /เงี่ยน+/gi,
    /นมโต+/gi,
    /แตก[\s._\-*]*ใน+/gi,
    /ดอ[\s._\-*]*ก[\s._\-*]*ทอ[\s._\-*]*ง/gi,
    /อี[\s._\-*]*ดอ[\s._\-*]*ก+/gi,
    /อี่[\s._\-*]*ดอ[\s._\-*]*ก+/gi,
    /อี[\s._\-*]*ห่า+/gi,
    /ไอ้[\s._\-*]*ห่า+/gi,
    /ห่า[\s._\-*]*ราก+/gi,
    /ส้น[\s._\-*]*ตี[\s._\-*]*น+/gi,
    /หน้า[\s._\-*]*ตัว[\s._\-*]*เมีย/gi,
    /ชาติ[\s._\-*]*หมา/gi,
    /ชาติ[\s._\-*]*ชั่ว/gi,
    /จัญ[\s._\-*]*ไร+/gi,
    /ระ[\s._\-*]*ยำ+/gi,
    /เสนียด+/gi,
    /สถุล+/gi,
    /แม่[\s._\-*]*มึง[\s._\-*]*ตาย+/gi,
    /พ่อ[\s._\-*]*มึง[\s._\-*]*ตาย+/gi,
    /มึง[\s._\-*]*ตาย+/gi,
    /ไป[\s._\-*]*ตาย+/gi,
    /ไอ้[\s._\-*]*เวร+/gi,
    /ควาย+/gi,
    /กู+/gi,
    /มึง+/gi,
    /วาง[\s._\-*]*ระ[\s._\-*]*เบิด+/gi,
    /ระ[\s._\-*]*เบิด+/gi,
    /บึ้ม+/gi,
    /ปล้น[\s._\-*]*เครื่อง[\s._\-*]*บิน+/gi,
    /ก่อ[\s._\-*]*การ[\s._\-*]*ร้าย+/gi,
    /\bf+[\s._\-*]*u+[\s._\-*]*c+[\s._\-*]*k+[\w]*/gi,
    /\bs+[\s._\-*]*h+[\s._\-*]*i+[\s._\-*]*t+[\w]*/gi,
    /\bb+[\s._\-*]*i+[\s._\-*]*t+[\s._\-*]*c+[\s._\-*]*h+[\w]*/gi,
    /\bc+[\s._\-*]*u+[\s._\-*]*n+[\s._\-*]*t+[\w]*/gi,
    /\bd+[\s._\-*]*i+[\s._\-*]*c+[\s._\-*]*k+[\w]*/gi,
    /\bp+[\s._\-*]*u+[\s._\-*]*s+[\s._\-*]*s+[\s._\-*]*y+[\w]*/gi,
    /\ba+[\s._\-*]*s+[\s._\-*]*s+[\s._\-*]*h+[\s._\-*]*o+[\s._\-*]*l+[\s._\-*]*e+[\w]*/gi,
    /\bb+[\s._\-*]*a+[\s._\-*]*s+[\s._\-*]*t+[\s._\-*]*a+[\s._\-*]*r+[\s._\-*]*d+[\w]*/gi,
    /\bs+[\s._\-*]*l+[\s._\-*]*u+[\s._\-*]*t+[\w]*/gi,
    /\bw+[\s._\-*]*h+[\s._\-*]*o+[\s._\-*]*r+[\s._\-*]*e+[\w]*/gi,
    /\bb+[\s._\-*]*o+[\s._\-*]*m+[\s._\-*]*b+[\w]*/gi,
    /\bt+[\s._\-*]*e+[\s._\-*]*r+[\s._\-*]*r+[\s._\-*]*o+[\s._\-*]*r+[\s._\-*]*i+[\s._\-*]*s+[\s._\-*]*t+[\w]*/gi,
    /\bh+[\s._\-*]*i+[\s._\-*]*j+[\s._\-*]*a+[\s._\-*]*c+[\s._\-*]*k+[\w]*/gi
  ];

  function filterQuietly(text, fallback) {
    if (!text || typeof text !== 'string') return fallback;
    let cleaned = text.trim();
    for (const p of BAD_PATTERNS) {
      cleaned = cleaned.replace(p, '***');
    }
    const realChars = cleaned.replace(/[*_.\-\s()]/g, '');
    if (realChars.length === 0) return fallback;
    return cleaned;
  }

  // 4. Confirm to Launch Stage
  if (btnConfirmToLaunch) {
    btnConfirmToLaunch.addEventListener('click', () => {
      const rawName = (senderNameInput.value.trim()) || 'ผู้โดยสารนิรนาม';
      const rawWish = (wishTextInput.value.trim()) || 'ขอให้ปีนี้มีแต่ความสุข รอยยิ้ม และความสมหวังทุกประการ';

      currentSenderName = filterQuietly(rawName, 'ผู้โดยสารท่าอากาศยานตรัง');
      currentWishText = filterQuietly(rawWish, 'ขอให้มีความสุข ความเจริญ และเดินทางปลอดภัยทุกเส้นทาง');

      // Populate Launch Stage
      const meta = KR_INFO[selectedType] || KR_INFO.royal;
      if (swipeKrImg) swipeKrImg.src = meta.image;
      if (swipeSenderBadge) swipeSenderBadge.textContent = currentSenderName + ' ✦';
      if (swipeWishPreview) swipeWishPreview.textContent = `“${currentWishText}”`;

      // Reset krathong position & state
      isLaunched = false;
      if (swipeKrathong) {
        swipeKrathong.classList.remove('launched', 'dragging');
        swipeKrathong.style.transform = 'translateY(0)';
        swipeKrathong.style.transition = '';
      }

      // Switch view
      formView.classList.remove('active');
      launchView.classList.add('active');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  // Back to Form
  if (btnBackToForm) {
    btnBackToForm.addEventListener('click', () => {
      launchView.classList.remove('active');
      formView.classList.add('active');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  // 5. Interactive Touch / Mouse Swipe-Up Gesture
  let startY = 0;
  let currentY = 0;
  let isDragging = false;
  let startTime = 0;

  function onDragStart(y) {
    if (isLaunched || !swipeKrathong) return;
    triggerHaptic('drag');
    isDragging = true;
    startY = y;
    currentY = y;
    startTime = performance.now();
    swipeKrathong.classList.add('dragging');
    swipeKrathong.style.transition = 'none';
  }

  function onDragMove(y) {
    if (!isDragging || isLaunched || !swipeKrathong) return;
    currentY = y;
    const dy = currentY - startY;

    // Only allow upward movement, with slight resistance for downward pull
    const translateY = dy < 0 ? dy : dy * 0.15;
    const scale = dy < 0 ? (1 + Math.min(0.2, Math.abs(dy) / 350)) : 1;

    swipeKrathong.style.transform = `translateY(${translateY}px) scale(${scale})`;
  }

  function onDragEnd() {
    if (!isDragging || isLaunched || !swipeKrathong) return;
    isDragging = false;
    swipeKrathong.classList.remove('dragging');

    const dy = currentY - startY;
    const dt = performance.now() - startTime;
    const velocity = Math.abs(dy) / Math.max(dt, 1);

    // 1) Swiped upwards threshold: dragged up 45px or quick upward flick
    if (dy < -45 || (dy < -25 && velocity > 0.3)) {
      launchKrathong();
    } 
    // 2) Tapped directly on krathong (quick touch without moving)
    else if (Math.abs(dy) < 12 && dt < 350) {
      launchKrathong();
    } 
    else {
      // Spring bounce back to resting water position
      swipeKrathong.style.transition = 'transform 0.35s cubic-bezier(0.18, 0.89, 0.32, 1.28)';
      swipeKrathong.style.transform = 'translateY(0)';
    }
  }

  // Touch Event Listeners (with non-passive preventDefault so mobile doesn't scroll page while swiping)
  if (swipeKrathong) {
    swipeKrathong.addEventListener('touchstart', (e) => {
      if (e.cancelable) e.preventDefault();
      onDragStart(e.touches[0].clientY);
    }, { passive: false });

    swipeKrathong.addEventListener('touchmove', (e) => {
      if (e.cancelable) e.preventDefault();
      if (isDragging && e.touches.length > 0) {
        onDragMove(e.touches[0].clientY);
      }
    }, { passive: false });

    swipeKrathong.addEventListener('click', () => {
      if (!isLaunched) launchKrathong();
    });

    swipeKrathong.addEventListener('mousedown', (e) => {
      e.preventDefault();
      onDragStart(e.clientY);
    });
  }

  window.addEventListener('touchmove', (e) => {
    if (isDragging && e.touches.length > 0) {
      if (e.cancelable) e.preventDefault();
      onDragMove(e.touches[0].clientY);
    }
  }, { passive: false });

  window.addEventListener('touchend', onDragEnd);
  window.addEventListener('touchcancel', onDragEnd);

  window.addEventListener('mousemove', (e) => {
    if (isDragging) {
      onDragMove(e.clientY);
    }
  });

  window.addEventListener('mouseup', () => {
    if (isDragging) onDragEnd();
  });

  if (btnTapToFloat) {
    btnTapToFloat.addEventListener('click', () => {
      if (!isLaunched) launchKrathong();
    });
  }

  // 6. Launch Krathong Execution
  async function launchKrathong() {
    if (isLaunched) return;
    isLaunched = true;

    // Haptic feedback & sound when launched
    triggerHaptic('launch');
    playMobileWhoosh();

    // Trigger flight animation off the top of screen
    if (swipeKrathong) {
      swipeKrathong.classList.add('launched');
    }

    try {
      currentKrathongId = 'kr_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6);
      heartCount = 0;
      sparkleCount = 0;
      if (heartCountEl) heartCountEl.textContent = '0';
      if (sparkleCountEl) sparkleCountEl.textContent = '0';

      // Send real-time request to Big Screen server
      fetch('/api/float', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: currentKrathongId,
          senderName: currentSenderName,
          wishText: currentWishText,
          krathongType: selectedType
        })
      }).catch(err => console.error('Fetch error:', err));

      // Generate Souvenir Card on Canvas (Single Flat Pokemon Card Art)
      currentLuckyNumber = generateLuckyNumber();
      generateSouvenirCard(currentSenderName, currentWishText, selectedType, currentLuckyNumber);

      // Transition to Success View as krathong leaves screen
      setTimeout(() => {
        launchView.classList.remove('active');
        successView.classList.add('active');
        triggerHaptic('success');
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }, 650);

    } catch (err) {
      console.error('Launch failed:', err);
    }
  }

  // 7. Float Again Action
  if (btnFloatAgain) {
    btnFloatAgain.addEventListener('click', () => {
      if (wishTextInput) wishTextInput.value = '';
      updateCharCount();
      if (presetWishes) {
        presetWishes.querySelectorAll('.wish-tag').forEach(t => t.classList.remove('active'));
      }

      currentKrathongId = null;
      heartCount = 0;
      sparkleCount = 0;
      if (heartCountEl) heartCountEl.textContent = '0';
      if (sparkleCountEl) sparkleCountEl.textContent = '0';

      // Reset krathong in launch view
      isLaunched = false;
      if (swipeKrathong) {
        swipeKrathong.classList.remove('launched', 'dragging');
        swipeKrathong.style.transform = 'translateY(0)';
        swipeKrathong.style.transition = '';
      }

      successView.classList.remove('active');
      formView.classList.add('active');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  // 7B. Live Krathong Cheering Reactions (ส่งหัวใจ & ประกายแสง)
  function spawnMobileEmoji(emoji, targetBtn) {
    if (!cheerFloatingFx || !targetBtn) return;
    const btnRect = targetBtn.getBoundingClientRect();
    const parentRect = cheerFloatingFx.getBoundingClientRect();

    const p = document.createElement('div');
    p.className = 'mobile-floating-emoji';
    p.textContent = emoji;

    const x = (btnRect.left + btnRect.width * 0.5) - parentRect.left;
    const y = (btnRect.top + btnRect.height * 0.2) - parentRect.top;
    const dx = (Math.random() * 44 - 22);

    p.style.left = `${x}px`;
    p.style.top = `${y}px`;
    p.style.setProperty('--dx', `${dx.toFixed(1)}px`);

    cheerFloatingFx.appendChild(p);
    setTimeout(() => {
      if (p.parentNode) p.parentNode.removeChild(p);
    }, 1200);
  }

  function sendReaction(type, btnEl) {
    if (!currentKrathongId) return;
    triggerHaptic('tap');

    if (type === 'heart') {
      spawnMobileEmoji('❤️', btnEl);
    } else {
      spawnMobileEmoji('✨', btnEl);
    }

    fetch('/api/reaction', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        krathongId: currentKrathongId,
        type: type
      })
    }).catch(err => console.error('Reaction error:', err));
  }

  if (btnCheerHeart) {
    btnCheerHeart.addEventListener('click', () => {
      sendReaction('heart', btnCheerHeart);
    });
  }

  if (btnCheerSparkle) {
    btnCheerSparkle.addEventListener('click', () => {
      sendReaction('sparkle', btnCheerSparkle);
    });
  }

  // 8. Share Card to LINE (Direct image attachment via Web Share API or LINE scheme)
  if (btnShareLine) {
    btnShareLine.addEventListener('click', async () => {
      if (!cardDataUrl) return;

      const shareUrl = window.location.origin + '/mobile.html';
      const shareText = `ฉันได้ร่วมลอยกระทงออนไลน์กับท่าอากาศยานตรังแล้ว! เลขนำโชคของฉันคือ [${currentLuckyNumber}] 🪷✨ มาร่วมลอยกระทงด้วยกันนะ: ${shareUrl}`;

      // 1. Auto-copy caption text to clipboard
      if (navigator.clipboard) {
        navigator.clipboard.writeText(shareText).catch(() => {});
      }

      // 2. Prepare file blob for sharing
      let file = null;
      try {
        const res = await fetch(cardDataUrl);
        const blob = await res.blob();
        file = new File([blob], `Trang-Airport-LoyKrathong-2569-${currentLuckyNumber}.png`, { type: 'image/png' });
      } catch (err) {
        console.warn('Blob conversion failed:', err);
      }

      // 3. Native Web Share with file (LINE attaches photo + caption directly)
      if (file && navigator.canShare && navigator.canShare({ files: [file] })) {
        try {
          await navigator.share({
            title: 'การ์ดที่ระลึกเทศกาลลอยกระทง 2569 | ท่าอากาศยานตรัง',
            text: shareText,
            files: [file]
          });
          return;
        } catch (err) {
          if (err.name !== 'AbortError') {
            console.log('Share error:', err);
          }
        }
      }

      // 4. Fallback for desktop / unsupported browsers: open LINE Share URL
      const lineUrl = `https://social-plugins.line.me/lineit/share?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(shareText)}`;
      window.open(lineUrl, '_blank');
    });
  }

  // 9. Post Card to Facebook (Auto-Save High-Res Image + Auto-Copy Caption + Guide Modal)
  if (btnShareFb) {
    btnShareFb.addEventListener('click', () => {
      if (!cardDataUrl) return;

      const shareUrl = window.location.origin + '/mobile.html';
      const shareText = `ฉันได้ร่วมลอยกระทงออนไลน์กับท่าอากาศยานตรังแล้ว! เลขนำโชคของฉันคือ [${currentLuckyNumber}] 🪷✨ มาร่วมลอยกระทงด้วยกันนะ: ${shareUrl}`;

      // 1. Auto-save card image to user device
      const a = document.createElement('a');
      a.download = `Trang-Airport-LoyKrathong-2569-${currentLuckyNumber}.png`;
      a.href = cardDataUrl;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);

      // 2. Auto-copy caption to clipboard
      if (navigator.clipboard) {
        navigator.clipboard.writeText(shareText).catch(() => {});
      }

      // 3. Show Facebook helper modal
      if (fbModal) {
        fbModal.style.display = 'flex';
      }
    });
  }

  // Close Facebook Modal
  if (btnCloseFbModal) {
    btnCloseFbModal.addEventListener('click', () => {
      if (fbModal) fbModal.style.display = 'none';
    });
  }
  if (fbModal) {
    fbModal.addEventListener('click', (e) => {
      if (e.target === fbModal) fbModal.style.display = 'none';
    });
  }

  // 10. Download Card PNG (Clean single download)
  if (btnDownloadCard) {
    btnDownloadCard.addEventListener('click', () => {
      if (!cardDataUrl) return;
      const a = document.createElement('a');
      a.download = `Trang-Airport-LoyKrathong-2569-${currentLuckyNumber}.png`;
      a.href = cardDataUrl;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);

      // Visual feedback on button
      const origText = btnDownloadCard.innerHTML;
      btnDownloadCard.innerHTML = '✅ บันทึกภาพการ์ดลงเครื่องแล้ว!';
      setTimeout(() => {
        btnDownloadCard.innerHTML = origText;
      }, 2500);
    });
  }

  // 10. Interactive 3D Touch / Pointer Parallax (Pure Finger Swipe, Gyro removed)
  function handlePointerTilt(clientX, clientY) {
    if (!holoCard) return;
    const rect = holoCard.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    const dx = clientX - centerX;
    const dy = clientY - centerY;

    const nx = Math.max(-1, Math.min(1, dx / (rect.width / 2)));
    const ny = Math.max(-1, Math.min(1, dy / (rect.height / 2)));

    targetRotY = nx * 22;
    targetRotX = -ny * 22;
  }

  if (holoStage) {
    holoStage.addEventListener('pointerdown', (e) => {
      isTouchingCard = true;
      handlePointerTilt(e.clientX, e.clientY);
    });

    window.addEventListener('pointermove', (e) => {
      if (isTouchingCard) {
        handlePointerTilt(e.clientX, e.clientY);
      }
    });

    window.addEventListener('pointerup', () => {
      if (isTouchingCard) {
        isTouchingCard = false;
        targetRotX = 0;
        targetRotY = 0;
      }
    });

    holoStage.addEventListener('touchmove', (e) => {
      if (e.touches.length > 0) {
        handlePointerTilt(e.touches[0].clientX, e.touches[0].clientY);
      }
    }, { passive: true });

    holoStage.addEventListener('touchend', () => {
      isTouchingCard = false;
      targetRotX = 0;
      targetRotY = 0;
    });
  }

  // 60 FPS Render Loop with Smooth Interpolation
  function render3DCard() {
    if (holoCard && successView && successView.classList.contains('active')) {
      if (!isTouchingCard) {
        idleTime += 0.025;
        targetRotX = Math.sin(idleTime) * 5;
        targetRotY = Math.cos(idleTime * 0.85) * 6;
      }

      currentRotX += (targetRotX - currentRotX) * 0.14;
      currentRotY += (targetRotY - currentRotY) * 0.14;

      holoCard.style.transform = `rotateX(${currentRotX.toFixed(2)}deg) rotateY(${currentRotY.toFixed(2)}deg)`;

      const foilX = 50 + (currentRotY / 22) * 45;
      const foilY = 50 + (-currentRotX / 22) * 45;
      const glareX = 50 + (currentRotY / 22) * 42;
      const glareY = 50 + (-currentRotX / 22) * 42;

      const tiltMag = Math.sqrt(currentRotX * currentRotX + currentRotY * currentRotY) / 22;
      const foilOpacity = 0.45 + Math.min(0.45, tiltMag * 0.4);
      const glareOpacity = 0.35 + Math.min(0.5, tiltMag * 0.45);

      holoCard.style.setProperty('--foil-pos-x', `${foilX.toFixed(1)}%`);
      holoCard.style.setProperty('--foil-pos-y', `${foilY.toFixed(1)}%`);
      holoCard.style.setProperty('--foil-opacity', foilOpacity.toFixed(2));

      holoCard.style.setProperty('--glare-x', `${glareX.toFixed(1)}%`);
      holoCard.style.setProperty('--glare-y', `${glareY.toFixed(1)}%`);
      holoCard.style.setProperty('--glare-opacity', glareOpacity.toFixed(2));
    }

    requestAnimationFrame(render3DCard);
  }

  requestAnimationFrame(render3DCard);

  // 11. Generate Souvenir Card on Canvas for High-Res PNG Download & Share
  function generateSouvenirCard(name, wish, type, luckyNum) {
    if (!cardCanvas) return;
    const ctx = cardCanvas.getContext('2d');
    const width = 765;
    const height = 1024;
    cardCanvas.width = width;
    cardCanvas.height = height;

    const bgImg = new Image();
    bgImg.crossOrigin = 'anonymous';
    bgImg.onload = () => {
      // 1. Draw Background Template (Official Trang Airport Loy Krathong Art)
      ctx.drawImage(bgImg, 0, 0, width, height);

      // 2. Draw Krathong on Golden Lotus Pedestal Pool
      const meta = KR_INFO[type] || KR_INFO.royal;
      const krImg = new Image();
      krImg.crossOrigin = 'anonymous';
      krImg.onload = () => {
        const cx = 382.5; // center X
        const cy = 608;   // center Y of lotus pool
        const kw = 260;
        const kh = 260;

        // Shadow & Glow
        ctx.save();
        ctx.shadowColor = 'rgba(0, 0, 0, 0.7)';
        ctx.shadowBlur = 24;
        ctx.shadowOffsetY = 12;
        ctx.drawImage(krImg, cx - kw / 2, cy - kh / 2 - 10, kw, kh);
        ctx.restore();

        // Extra Golden Glow Accent
        ctx.save();
        ctx.shadowColor = 'rgba(255, 215, 0, 0.5)';
        ctx.shadowBlur = 20;
        ctx.drawImage(krImg, cx - kw / 2, cy - kh / 2 - 10, kw, kh);
        ctx.restore();

        // 3. Draw Sender Name right after 'คำอธิษฐาน :' on the same line (inside frame)
        ctx.save();
        ctx.textAlign = 'left';
        ctx.textBaseline = 'middle';
        ctx.fillStyle = '#f7df96';
        ctx.font = 'bold 22px sans-serif';
        ctx.shadowColor = 'rgba(0, 0, 0, 0.95)';
        ctx.shadowBlur = 6;
        ctx.shadowOffsetX = 1;
        ctx.shadowOffsetY = 1;
        ctx.fillText(name + ' ✦', 246, 815);
        ctx.restore();

        // 4. Draw Wish Text on the next line below
        ctx.save();
        ctx.textAlign = 'left';
        ctx.textBaseline = 'top';
        ctx.fillStyle = '#ffffff';
        ctx.font = '19px sans-serif';
        ctx.shadowColor = 'rgba(0, 0, 0, 0.95)';
        ctx.shadowBlur = 5;
        ctx.shadowOffsetX = 1;
        ctx.shadowOffsetY = 1;
        wrapTextThai(ctx, `“${wish}”`, 138, 840, 360, 26, 3);
        ctx.restore();

        // 5. Draw Lucky Number inside Golden Medallion (centered at y=882)
        ctx.save();
        const coinX = 586;
        const coinY = 882;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.font = 'bold 36px "Trebuchet MS", "Courier New", sans-serif';
        ctx.fillStyle = '#503102';
        ctx.shadowColor = 'rgba(255, 255, 255, 0.8)';
        ctx.shadowOffsetX = 0;
        ctx.shadowOffsetY = 1;
        ctx.shadowBlur = 1;
        ctx.fillText(luckyNum, coinX, coinY);
        ctx.restore();

        // Export Data URL & immediately update 3D flat card surface (Pokemon TCG Style)
        cardDataUrl = cardCanvas.toDataURL('image/png');
        if (holoCardImg) {
          holoCardImg.src = cardDataUrl;
        }
      };
      krImg.src = meta.image;
    };
    bgImg.src = 'assets/images/card_template_trang.jpg';
  }

  // Thai text wrapper helper for canvas with max lines limit
  function wrapTextThai(ctx, text, x, y, maxWidth, lineHeight, maxLines = 3) {
    const chars = Array.from(text);
    let line = '';
    let currentY = y;
    let lineCount = 0;

    for (let i = 0; i < chars.length; i++) {
      const testLine = line + chars[i];
      const metrics = ctx.measureText(testLine);

      if (metrics.width > maxWidth && line.length > 0) {
        lineCount++;
        if (lineCount >= maxLines) {
          ctx.fillText(line + '…', x, currentY);
          return;
        }
        ctx.fillText(line, x, currentY);
        line = chars[i];
        currentY += lineHeight;
      } else {
        line = testLine;
      }
    }
    if (line.length > 0) {
      ctx.fillText(line, x, currentY);
    }
  }
})();
