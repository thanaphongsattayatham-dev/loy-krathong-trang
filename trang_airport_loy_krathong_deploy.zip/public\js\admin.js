/**
 * Admin Dashboard Client - Trang Airport Loy Krathong 2026
 * Real-time event moderation, statistics, remote triggers and data backup
 */

(() => {
  // DOM Elements
  const loginGate = document.getElementById('loginGate');
  const loginForm = document.getElementById('loginForm');
  const adminPasswordInput = document.getElementById('adminPassword');
  const loginError = document.getElementById('loginError');
  const btnLogin = document.getElementById('btnLogin');
  const adminApp = document.getElementById('adminApp');
  const btnLogout = document.getElementById('btnLogout');

  // Stats Elements
  const statTotalKrathongs = document.getElementById('statTotalKrathongs');
  const statTotalReactions = document.getElementById('statTotalReactions');
  const statTopType = document.getElementById('statTopType');
  const statTopCount = document.getElementById('statTopCount');
  const statServerUptime = document.getElementById('statServerUptime');
  const statServerTime = document.getElementById('statServerTime');
  const typeBarsContainer = document.getElementById('typeBarsContainer');

  // Control Buttons
  const btnTriggerFireworks = document.getElementById('btnTriggerFireworks');
  const btnExportCSV = document.getElementById('btnExportCSV');
  const btnRefreshData = document.getElementById('btnRefreshData');
  const btnResetAll = document.getElementById('btnResetAll');

  // Table & Filters
  const searchInput = document.getElementById('searchInput');
  const typeFilter = document.getElementById('typeFilter');
  const krathongsTableBody = document.getElementById('krathongsTableBody');

  // Reset Modal
  const resetModal = document.getElementById('resetModal');
  const confirmResetPassword = document.getElementById('confirmResetPassword');
  const resetError = document.getElementById('resetError');
  const btnCancelReset = document.getElementById('btnCancelReset');
  const btnConfirmReset = document.getElementById('btnConfirmReset');

  // Toast Container
  const toastContainer = document.getElementById('toastContainer');

  // State
  let adminToken = localStorage.getItem('trang_admin_token') || null;
  let allKrathongs = [];
  let sseSource = null;
  let uptimeSeconds = 0;
  let uptimeInterval = null;

  // Krathong Types Display Names & Image Icons
  const KRATHONG_TYPES = {
    royal: { name: 'ธาราราชพฤกษ์', icon: 'assets/images/royal.png' },
    lotus: { name: 'บัวสวรรค์นำโชค', icon: 'assets/images/lotus.png' },
    marigold: { name: 'ดาวเรืองสิริมงคล', icon: 'assets/images/marigold.png' },
    eco: { name: 'ธาราธรรมชาติ', icon: 'assets/images/eco.png' },
    bread: { name: 'ขนมปังนำโชค', icon: 'assets/images/bread.png' },
    airplane: { name: 'เวหานำโชค', icon: 'assets/images/airplane.png' },
    dugong: { name: 'พะยูนตรังใจดี', icon: 'assets/images/dugong.png' },
    minimal: { name: 'มินิมอลผ่องอำพัน', icon: 'assets/images/minimal.png' }
  };

  // Toast Helper
  function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    const icon = type === 'success' ? '✅' : (type === 'error' ? '❌' : 'ℹ️');
    toast.innerHTML = `<span>${icon}</span> <span>${message}</span>`;
    toastContainer.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(40px)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 350);
    }, 3800);
  }

  // ================= 1. Authentication =================
  if (adminToken) {
    verifySession();
  } else {
    showLogin();
  }

  function showLogin() {
    loginGate.style.display = 'flex';
    adminApp.style.display = 'none';
    if (adminPasswordInput) adminPasswordInput.focus();
  }

  function showApp() {
    loginGate.style.display = 'none';
    adminApp.style.display = 'block';
    initDashboard();
  }

  async function verifySession() {
    try {
      const res = await fetch('/api/admin/stats', {
        headers: { 'x-admin-token': adminToken }
      });
      if (res.ok) {
        showApp();
      } else {
        localStorage.removeItem('trang_admin_token');
        adminToken = null;
        showLogin();
      }
    } catch (e) {
      showLogin();
    }
  }

  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const password = adminPasswordInput.value.trim();
    if (!password) return;

    btnLogin.disabled = true;
    btnLogin.innerHTML = 'กำลังตรวจสอบ...';
    loginError.style.display = 'none';

    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password })
      });
      const data = await res.json();

      if (data.ok && data.token) {
        adminToken = data.token;
        localStorage.setItem('trang_admin_token', adminToken);
        showApp();
        showToast('เข้าสู่ระบบสำเร็จ ยินดีต้อนรับครับ!', 'success');
      } else {
        loginError.textContent = data.error || 'รหัสผ่านไม่ถูกต้อง';
        loginError.style.display = 'block';
      }
    } catch (err) {
      loginError.textContent = 'ไม่สามารถเชื่อมต่อกับเซิร์ฟเวอร์ได้';
      loginError.style.display = 'block';
    } finally {
      btnLogin.disabled = false;
      btnLogin.innerHTML = '<span>เข้าสู่ระบบหลังบ้าน</span> ➔';
    }
  });

  btnLogout.addEventListener('click', () => {
    if (confirm('ต้องการออกจากระบบผู้ดูแลหรือไม่?')) {
      localStorage.removeItem('trang_admin_token');
      adminToken = null;
      if (sseSource) sseSource.close();
      showLogin();
      showToast('ออกจากระบบเรียบร้อยแล้ว', 'info');
    }
  });

  // ================= 2. Dashboard Init & Real-Time Sync =================
  function initDashboard() {
    loadStats();
    loadKrathongs();
    initSSE();

    if (uptimeInterval) clearInterval(uptimeInterval);
    uptimeInterval = setInterval(updateUptimeDisplay, 1000);
  }

  async function loadStats() {
    try {
      const res = await fetch('/api/admin/stats', {
        headers: { 'x-admin-token': adminToken }
      });
      if (!res.ok) return;
      const data = await res.json();

      if (data.ok) {
        statTotalKrathongs.textContent = Number(data.totalKrathongs).toLocaleString();
        statTotalReactions.textContent = Number(data.totalReactions).toLocaleString();
        uptimeSeconds = data.serverUptime || 0;
        updateUptimeDisplay();

        // Render type breakdown & determine top type
        renderTypeBreakdown(data.typeCounts || {}, data.totalKrathongs || 0);
      }
    } catch (e) {
      console.warn('Failed to load stats:', e);
    }
  }

  function renderTypeBreakdown(typeCounts, total) {
    typeBarsContainer.innerHTML = '';
    let topName = '-';
    let topVal = -1;

    Object.keys(KRATHONG_TYPES).forEach(typeKey => {
      const count = typeCounts[typeKey] || 0;
      const percent = total > 0 ? ((count / total) * 100).toFixed(1) : 0;
      const info = KRATHONG_TYPES[typeKey];

      if (count > topVal) {
        topVal = count;
        topName = info.name;
      }

      const item = document.createElement('div');
      item.className = 'type-bar-item';
      item.innerHTML = `
        <div class="type-bar-header">
          <span class="type-bar-name">
            <img src="${info.icon}" alt="${info.name}" style="width:20px;height:20px;object-fit:contain;">
            ${info.name}
          </span>
          <span class="type-bar-count">${count} ใบ (${percent}%)</span>
        </div>
        <div class="type-bar-track">
          <div class="type-bar-fill" style="width: ${percent}%;"></div>
        </div>
      `;
      typeBarsContainer.appendChild(item);
    });

    if (topVal > 0) {
      statTopType.textContent = topName;
      statTopCount.textContent = `${topVal} ใบ (${((topVal / total) * 100).toFixed(0)}%)`;
    } else {
      statTopType.textContent = '-';
      statTopCount.textContent = '0 ใบ';
    }
  }

  function updateUptimeDisplay() {
    uptimeSeconds++;
    const hrs = String(Math.floor(uptimeSeconds / 3600)).padStart(2, '0');
    const mins = String(Math.floor((uptimeSeconds % 3600) / 60)).padStart(2, '0');
    const secs = String(uptimeSeconds % 60).padStart(2, '0');
    statServerUptime.textContent = `${hrs}:${mins}:${secs}`;
    statServerTime.textContent = new Date().toLocaleTimeString('th-TH');
  }

  // ================= 3. Krathongs Table & Moderation =================
  async function loadKrathongs() {
    try {
      const res = await fetch('/api/admin/krathongs', {
        headers: { 'x-admin-token': adminToken }
      });
      if (!res.ok) return;
      const data = await res.json();
      if (data.ok && Array.isArray(data.krathongs)) {
        allKrathongs = data.krathongs;
        renderTable();
      }
    } catch (e) {
      console.warn('Failed to load krathongs:', e);
    }
  }

  function renderTable() {
    const searchTerm = searchInput.value.trim().toLowerCase();
    const selectedType = typeFilter.value;

    const filtered = allKrathongs.filter(k => {
      const matchSearch = !searchTerm || 
        (k.senderName && k.senderName.toLowerCase().includes(searchTerm)) ||
        (k.wishText && k.wishText.toLowerCase().includes(searchTerm));
      const matchType = selectedType === 'all' || k.krathongType === selectedType;
      return matchSearch && matchType;
    });

    if (filtered.length === 0) {
      krathongsTableBody.innerHTML = `
        <tr>
          <td colspan="6" class="text-center py-8 text-muted">
            ${allKrathongs.length === 0 ? 'ยังไม่มีกระทงในสายน้ำ' : 'ไม่พบกระทงที่ตรงกับเงื่อนไขการค้นหา'}
          </td>
        </tr>
      `;
      return;
    }

    krathongsTableBody.innerHTML = '';
    filtered.forEach((k, idx) => {
      const info = KRATHONG_TYPES[k.krathongType] || KRATHONG_TYPES.royal;
      const dateStr = new Date(k.timestamp || Date.now()).toLocaleTimeString('th-TH', { hour: '2-digit', minute: '2-digit', second: '2-digit' });

      const tr = document.createElement('tr');
      tr.id = `row_${k.id}`;
      tr.innerHTML = `
        <td><strong>${idx + 1}</strong></td>
        <td>
          <img src="${info.icon}" alt="${info.name}" class="kr-thumb-icon" title="${info.name}">
        </td>
        <td>
          <strong>${escapeHtml(k.senderName || 'ผู้โดยสารนิรนาม')}</strong>
        </td>
        <td style="color: #f1f5f9; font-size: 0.92rem;">
          ${escapeHtml(k.wishText || '-')}
        </td>
        <td class="text-muted" style="font-size: 0.82rem;">
          ${dateStr}
        </td>
        <td class="text-center">
          <button class="btn-table-action btn-table-spotlight" onclick="window.__adminHighlight('${k.id}')" title="สปอตไลท์บนจอใหญ่">
            ⭐ สปอตไลท์
          </button>
          <button class="btn-table-action btn-table-delete" onclick="window.__adminDelete('${k.id}', '${escapeHtml(k.senderName || '')}')" title="ลบออกจากจอใหญ่">
            🗑️ ลบ
          </button>
        </td>
      `;
      krathongsTableBody.appendChild(tr);
    });
  }

  searchInput.addEventListener('input', renderTable);
  typeFilter.addEventListener('change', renderTable);

  // Global actions for inline table buttons
  window.__adminHighlight = async (id) => {
    try {
      const res = await fetch('/api/admin/highlight', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-token': adminToken
        },
        body: JSON.stringify({ id })
      });
      const data = await res.json();
      if (data.ok) {
        showToast('ฉายสปอตไลท์ VIP บนจอใหญ่แล้ว!', 'success');
      }
    } catch (e) {
      showToast('ไม่สามารถส่งคำสั่งสปอตไลท์ได้', 'error');
    }
  };

  window.__adminDelete = async (id, senderName) => {
    if (!confirm(`ต้องการลบกระทงของ "${senderName || id}" ออกจากจอใหญ่และฐานข้อมูลทันทีหรือไม่?`)) {
      return;
    }

    try {
      const res = await fetch('/api/admin/delete', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-token': adminToken
        },
        body: JSON.stringify({ id })
      });
      const data = await res.json();
      if (data.ok) {
        allKrathongs = allKrathongs.filter(k => k.id !== id);
        renderTable();
        loadStats();
        showToast(`ลบกระทงของ "${senderName}" ออกจากจอใหญ่เรียบร้อยแล้ว`, 'info');
      } else {
        showToast(data.error || 'ไม่สามารถลบกระทงได้', 'error');
      }
    } catch (e) {
      showToast('เกิดข้อผิดพลาดในการลบกระทง', 'error');
    }
  };

  // ================= 4. Quick Actions =================
  // A. Trigger Fireworks
  btnTriggerFireworks.addEventListener('click', async () => {
    btnTriggerFireworks.disabled = true;
    try {
      const res = await fetch('/api/admin/fireworks', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-token': adminToken
        }
      });
      const data = await res.json();
      if (data.ok) {
        showToast('🎆 จุดพลุชุดใหญ่เฉลิมฉลองบนจอเรียบร้อยแล้ว!', 'success');
      }
    } catch (e) {
      showToast('เกิดข้อผิดพลาดในการจุดพลุ', 'error');
    } finally {
      setTimeout(() => btnTriggerFireworks.disabled = false, 3000);
    }
  });

  // B. Export CSV
  btnExportCSV.addEventListener('click', () => {
    window.open(`/api/admin/export?token=${encodeURIComponent(adminToken)}`, '_blank');
    showToast('กำลังดาวน์โหลดรายงาน CSV สำหรับ Excel...', 'success');
  });

  // C. Refresh Data
  btnRefreshData.addEventListener('click', () => {
    loadStats();
    loadKrathongs();
    showToast('ซิงค์ข้อมูลล่าสุดเรียบร้อยแล้ว', 'info');
  });

  // D. Reset Modal Handling
  btnResetAll.addEventListener('click', () => {
    confirmResetPassword.value = '';
    resetError.style.display = 'none';
    resetModal.style.display = 'flex';
    confirmResetPassword.focus();
  });

  btnCancelReset.addEventListener('click', () => {
    resetModal.style.display = 'none';
  });

  btnConfirmReset.addEventListener('click', async () => {
    const password = confirmResetPassword.value.trim();
    if (!password) {
      resetError.textContent = 'กรุณากรอกรหัสผ่านเพื่อยืนยัน';
      resetError.style.display = 'block';
      return;
    }

    btnConfirmReset.disabled = true;
    btnConfirmReset.textContent = 'กำลังล้างและสำรองข้อมูล...';

    try {
      const res = await fetch('/api/admin/reset', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-admin-token': adminToken
        },
        body: JSON.stringify({ password })
      });
      const data = await res.json();

      if (data.ok) {
        resetModal.style.display = 'none';
        allKrathongs = [];
        renderTable();
        loadStats();
        showToast('สำรองไฟล์และรีเซ็ตสระน้ำเป็น 0 สำเร็จเรียบร้อย!', 'success');
      } else {
        resetError.textContent = data.error || 'รหัสผ่านไม่ถูกต้อง';
        resetError.style.display = 'block';
      }
    } catch (e) {
      resetError.textContent = 'เกิดข้อผิดพลาดในการรีเซ็ต';
      resetError.style.display = 'block';
    } finally {
      btnConfirmReset.disabled = false;
      btnConfirmReset.textContent = 'ยืนยันรีเซ็ตสระน้ำ';
    }
  });

  // ================= 5. Live SSE Listener =================
  function initSSE() {
    if (sseSource) sseSource.close();
    sseSource = new EventSource('/api/events');

    sseSource.addEventListener('new_krathong', (e) => {
      try {
        const k = JSON.parse(e.data);
        allKrathongs.unshift(k);
        renderTable();
        loadStats();
        showToast(`🪷 กระทงใหม่จาก "${k.senderName || 'ผู้โดยสาร'}" ลอยลงสู่สระ!`, 'info');
      } catch (err) {}
    });

    sseSource.addEventListener('krathong_reaction', (e) => {
      loadStats();
    });

    sseSource.addEventListener('delete_krathong', (e) => {
      try {
        const d = JSON.parse(e.data);
        allKrathongs = allKrathongs.filter(k => k.id !== d.id);
        renderTable();
        loadStats();
      } catch (err) {}
    });

    sseSource.addEventListener('clear', () => {
      allKrathongs = [];
      renderTable();
      loadStats();
    });

    sseSource.onerror = () => {
      console.warn('[Admin SSE] Connection lost, retrying automatically...');
    };
  }

  function escapeHtml(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }
})();
