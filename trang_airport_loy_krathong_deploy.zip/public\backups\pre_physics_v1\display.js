/**
 * Trang Airport Loy Krathong 2026 - Perspective River View
 * Features:
 * 1. Realistic River Water Simulation, Moonlight Reflection Trail & Krathong Light Reflections (Canvas)
 * 2. Celebratory Fireworks Engine (Sky Canvas with Web Audio FX)
 * 3. Skyline of Thai Temples & City Buildings with Illuminated Windows
 * 4. Real-time SSE Stream, Dynamic QR Code & 2.5D Slow Perspective Drift
 */

(() => {
  // DOM Elements
  const scenicSky = document.getElementById('scenicSky');
  const scenicMoon = document.getElementById('scenicMoon');
  const riverStage = document.getElementById('riverStage');
  const krathongsRiverLayer = document.getElementById('krathongsRiverLayer');
  const effectsLayer = document.getElementById('effectsLayer');
  const starsLayer = document.getElementById('starsLayer');
  const lanternsContainer = document.getElementById('lanternsContainer');
  const krCountEl = document.getElementById('krCount');
  const newToast = document.getElementById('newToast');
  const toastSender = document.getElementById('toastSender');
  const toastWish = document.getElementById('toastWish');

  // Canvases
  const riverCanvas = document.getElementById('riverCanvas');
  const riverCtx = riverCanvas.getContext('2d');
  const fireworksCanvas = document.getElementById('fireworksCanvas');
  const fwCtx = fireworksCanvas.getContext('2d');

  // Controls & QR
  const qrCard = document.getElementById('qrCard');
  const qrToggleBtn = document.getElementById('qrToggleBtn');
  const qrUrlBox = document.getElementById('qrUrlBox');
  const qrSubtitle = document.getElementById('qrSubtitle');
  const qrcodeContainer = document.getElementById('qrcode');
  const btnModePublic = document.getElementById('btnModePublic');
  const btnModeLocal = document.getElementById('btnModeLocal');
  const btnAudio = document.getElementById('btnAudio');
  const btnFireworks = document.getElementById('btnFireworks');
  const btnFullscreen = document.getElementById('btnFullscreen');
  const btnSimulate = document.getElementById('btnSimulate');

  // Modal Detail
  const krModalBackdrop = document.getElementById('krModalBackdrop');
  const krDetailModal = document.getElementById('krDetailModal');
  const krModalClose = document.getElementById('krModalClose');
  const modalKrImg = document.getElementById('modalKrImg');
  const modalSender = document.getElementById('modalSender');
  const modalType = document.getElementById('modalType');
  const modalTime = document.getElementById('modalTime');
  const modalWish = document.getElementById('modalWish');

  // Krathong Types Meta (Pristine Transparent Cutout PNGs)
  const KR_TYPES = {
    royal: { title: 'ราชพฤกษ์ทอง', image: 'assets/images/royal.png' },
    minimal: { title: 'บัวมินิมัล', image: 'assets/images/minimal.png' },
    lotus: { title: 'บัวจันทร์', image: 'assets/images/lotus.png' },
    marigold: { title: 'มณีบุปผา', image: 'assets/images/marigold.png' },
    eco: { title: 'ธาราธรรมชาติ', image: 'assets/images/eco.png' },
    bread: { title: 'ขนมปังนำโชค', image: 'assets/images/bread.png' },
    airplane: { title: 'เวหานำโชค', image: 'assets/images/airplane.png' },
    dugong: { title: 'พะยูนธารา', image: 'assets/images/dugong.png' }
  };

  // State
  const krathongsMap = new Map(); // id -> RiverKrathong
  let audioEnabled = false;
  let audioCtx = null;
  let activeMode = 'public';
  let currentPublicUrl = '';
  let currentLocalUrl = '';

  // Resize Canvases
  let skyWidth = 0, skyHeight = 0;
  let rWidth = 0, rHeight = 0;

  function resizeCanvases() {
    if (scenicSky && fireworksCanvas) {
      skyWidth = scenicSky.clientWidth || window.innerWidth;
      skyHeight = scenicSky.clientHeight || (window.innerHeight * 0.52);
      fireworksCanvas.width = skyWidth;
      fireworksCanvas.height = skyHeight;
    }
    if (riverStage && riverCanvas) {
      rWidth = riverStage.clientWidth || window.innerWidth;
      rHeight = riverStage.clientHeight || (window.innerHeight * 0.5);
      riverCanvas.width = rWidth;
      riverCanvas.height = rHeight;
    }
  }

  window.addEventListener('resize', resizeCanvases);
  resizeCanvases();

  // ================= 1. Background Environment (Stars & Lanterns) =================
  function initStars() {
    if (!starsLayer) return;
    const count = 65;
    for (let i = 0; i < count; i++) {
      const star = document.createElement('div');
      star.className = 'star';
      const size = Math.random() < 0.2 ? 2.5 : (Math.random() < 0.6 ? 1.8 : 1.2);
      star.style.width = `${size}px`;
      star.style.height = `${size}px`;
      star.style.left = `${Math.random() * 100}%`;
      star.style.top = `${Math.random() * 95}%`;
      star.style.setProperty('--duration', `${2 + Math.random() * 3.5}s`);
      star.style.animationDelay = `${Math.random() * 3}s`;
      starsLayer.appendChild(star);
    }
  }

  function initLanterns() {
    if (!lanternsContainer) return;
    const count = 12;
    for (let i = 0; i < count; i++) {
      const lantern = document.createElement('div');
      lantern.className = 'lantern';
      lantern.style.left = `${5 + Math.random() * 90}%`;
      const speed = 18 + Math.random() * 16;
      lantern.style.setProperty('--speed', `${speed}s`);
      lantern.style.setProperty('--drift-x', `${(Math.random() - 0.5) * 80}px`);
      lantern.style.animationDelay = `${Math.random() * speed}s`;
      lanternsContainer.appendChild(lantern);
    }
  }

  // ================= 1.2 Moon Water Sparkles Pool (ประกายระยิบระยับผิวน้ำกระทบแสงจันทร์) =================
  const MOON_SPARKLE_COUNT = 90;
  const moonSparkles = [];
  function initMoonSparkles() {
    moonSparkles.length = 0;
    for (let i = 0; i < MOON_SPARKLE_COUNT; i++) {
      moonSparkles.push({
        depth: 0.03 + Math.random() * 0.95, // 0 (horizon) to 1 (foreground)
        offsetNorm: (Math.random() + Math.random() - 1), // Gaussian-like bell distribution (-1 to 1)
        baseSize: 1.0 + Math.random() * 1.8,
        twinklePhase: Math.random() * Math.PI * 2,
        twinkleSpeed: 0.003 + Math.random() * 0.005
      });
    }
  }

  // ================= 2. Web Audio Sound Engine =================
  function initAudio() {
    if (!audioCtx) {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      audioCtx = new AudioContext();
    }
    if (audioCtx.state === 'suspended') {
      audioCtx.resume();
    }
  }

  function playLandingChime() {
    if (!audioEnabled || !audioCtx) return;
    try {
      const now = audioCtx.currentTime;

      // Soft water splash
      const bufferSize = audioCtx.sampleRate * 0.45;
      const buffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
      const output = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        output[i] = (Math.random() * 2 - 1) * Math.exp(-i / (audioCtx.sampleRate * 0.12));
      }
      const noise = audioCtx.createBufferSource();
      noise.buffer = buffer;
      const noiseFilter = audioCtx.createBiquadFilter();
      noiseFilter.type = 'lowpass';
      noiseFilter.frequency.setValueAtTime(800, now);

      const noiseGain = audioCtx.createGain();
      noiseGain.gain.setValueAtTime(0.08, now);
      noiseGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.45);

      noise.connect(noiseFilter);
      noiseFilter.connect(noiseGain);
      noiseGain.connect(audioCtx.destination);
      noise.start(now);

      // Tibetan singing bowl bell chime
      const freqs = [528, 792, 1056];
      freqs.forEach((freq, idx) => {
        const osc = audioCtx.createOscillator();
        const oscGain = audioCtx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, now + idx * 0.08);

        oscGain.gain.setValueAtTime(0.12 / (idx + 1), now + idx * 0.08);
        oscGain.gain.exponentialRampToValueAtTime(0.0001, now + 2.2);

        osc.connect(oscGain);
        oscGain.connect(audioCtx.destination);
        osc.start(now + idx * 0.08);
        osc.stop(now + 2.4);
      });
    } catch (e) {
      console.warn('Audio play error:', e);
    }
  }

  function playFireworkSound() {
    if (!audioEnabled || !audioCtx) return;
    try {
      const now = audioCtx.currentTime;
      const osc = audioCtx.createOscillator();
      const oscGain = audioCtx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(140, now);
      osc.frequency.exponentialRampToValueAtTime(35, now + 0.45);

      oscGain.gain.setValueAtTime(0.18, now);
      oscGain.gain.exponentialRampToValueAtTime(0.001, now + 0.5);

      osc.connect(oscGain);
      oscGain.connect(audioCtx.destination);
      osc.start(now);
      osc.stop(now + 0.55);

      const bufferSize = audioCtx.sampleRate * 0.6;
      const buffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i++) {
        data[i] = (Math.random() < 0.08 ? (Math.random() * 2 - 1) : 0) * Math.exp(-i / (audioCtx.sampleRate * 0.2));
      }
      const crackle = audioCtx.createBufferSource();
      crackle.buffer = buffer;
      const cGain = audioCtx.createGain();
      cGain.gain.setValueAtTime(0.06, now + 0.08);
      cGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.7);

      crackle.connect(cGain);
      cGain.connect(audioCtx.destination);
      crackle.start(now + 0.08);
    } catch (e) {
      console.warn('Firework audio error:', e);
    }
  }

  // ================= 3. Fireworks Engine =================
  const fireworks = [];
  const FW_COLORS = [
    { primary: '#ffea79', glow: '#f39c12' },
    { primary: '#ff7675', glow: '#d63031' },
    { primary: '#74b9ff', glow: '#0984e3' },
    { primary: '#55efc4', glow: '#00b894' },
    { primary: '#fd79a8', glow: '#e84393' },
    { primary: '#a29bfe', glow: '#6c5ce7' }
  ];

  class FireworkRocket {
    constructor(startX, startY, targetX, targetY, color) {
      this.x = startX;
      this.y = startY;
      this.targetX = targetX;
      this.targetY = targetY;
      this.color = color;
      this.speed = 4.2 + Math.random() * 1.8;
      const angle = Math.atan2(targetY - startY, targetX - startX);
      this.vx = Math.cos(angle) * this.speed;
      this.vy = Math.sin(angle) * this.speed;
      this.trail = [];
      this.exploded = false;
    }

    update() {
      this.trail.push({ x: this.x, y: this.y, alpha: 0.8 });
      if (this.trail.length > 8) this.trail.shift();

      this.x += this.vx;
      this.y += this.vy;

      if (this.vy < 0 && this.y <= this.targetY) {
        this.explode();
      }
    }

    explode() {
      this.exploded = true;
      playFireworkSound();

      const count = 55 + Math.floor(Math.random() * 30);
      for (let i = 0; i < count; i++) {
        fireworks.push(new FireworkParticle(this.x, this.y, this.color));
      }
    }

    draw(ctx) {
      ctx.save();
      for (let i = 0; i < this.trail.length; i++) {
        const pt = this.trail[i];
        const alpha = (i / this.trail.length) * 0.8;
        ctx.fillStyle = `rgba(255, 230, 150, ${alpha})`;
        ctx.beginPath();
        ctx.arc(pt.x, pt.y, 1.8, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.fillStyle = '#ffffff';
      ctx.beginPath();
      ctx.arc(this.x, this.y, 2.5, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }
  }

  class FireworkParticle {
    constructor(x, y, color) {
      this.x = x;
      this.y = y;
      this.color = color;
      const angle = Math.random() * Math.PI * 2;
      const speed = 1.2 + Math.random() * 4.5;
      this.vx = Math.cos(angle) * speed;
      this.vy = Math.sin(angle) * speed;
      this.friction = 0.955;
      this.gravity = 0.055;
      this.alpha = 1.0;
      this.decay = 0.012 + Math.random() * 0.014;
      this.radius = 1.6 + Math.random() * 1.6;
    }

    update() {
      this.vx *= this.friction;
      this.vy *= this.friction;
      this.vy += this.gravity;
      this.x += this.vx;
      this.y += this.vy;
      this.alpha -= this.decay;
    }

    draw(ctx) {
      if (this.alpha <= 0) return;
      ctx.save();
      ctx.globalAlpha = Math.max(0, this.alpha);

      ctx.fillStyle = this.color.primary;
      ctx.shadowColor = this.color.glow;
      ctx.shadowBlur = 6;
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
      ctx.fill();

      if (Math.random() < 0.25) {
        ctx.fillStyle = '#ffffff';
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.radius * 0.6, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.restore();
    }
  }

  function launchFirework(startX, targetX, targetY) {
    if (!skyWidth || !skyHeight) resizeCanvases();
    const sx = startX ?? (skyWidth * (0.15 + Math.random() * 0.7));
    const sy = skyHeight + 10;
    const tx = targetX ?? (sx + (Math.random() - 0.5) * 120);
    const ty = targetY ?? (skyHeight * (0.12 + Math.random() * 0.32));
    const color = FW_COLORS[Math.floor(Math.random() * FW_COLORS.length)];

    fireworks.push(new FireworkRocket(sx, sy, tx, ty, color));
  }

  function launchCelebrationBurst() {
    launchFirework(skyWidth * 0.35, skyWidth * 0.32, skyHeight * 0.22);
    setTimeout(() => {
      launchFirework(skyWidth * 0.65, skyWidth * 0.68, skyHeight * 0.18);
    }, 450);
    setTimeout(() => {
      launchFirework(skyWidth * 0.50, skyWidth * 0.50, skyHeight * 0.15);
    }, 950);
  }

  let lastAmbientFwTime = performance.now();
  let nextAmbientFwInterval = 4500;

  function updateFireworks(now) {
    if (!fwCtx || !fireworksCanvas) return;
    fwCtx.clearRect(0, 0, skyWidth, skyHeight);

    if (now - lastAmbientFwTime > nextAmbientFwInterval) {
      lastAmbientFwTime = now;
      nextAmbientFwInterval = 3800 + Math.random() * 3500;
      launchFirework();
    }

    for (let i = fireworks.length - 1; i >= 0; i--) {
      const p = fireworks[i];
      p.update();
      p.draw(fwCtx);

      if (p.exploded || p.alpha <= 0) {
        fireworks.splice(i, 1);
      }
    }
  }

  // ================= 4. Realistic River Canvas: Waves, Moonlight & Reflections =================
  function renderRiverWater(now) {
    if (!rWidth || !rHeight) return;

    riverCtx.clearRect(0, 0, rWidth, rHeight);

    // 1. Deep Water Gradient (Calm River Night Water)
    const waterGrad = riverCtx.createLinearGradient(0, 0, 0, rHeight);
    waterGrad.addColorStop(0, '#0c1a36');
    waterGrad.addColorStop(0.35, '#071229');
    waterGrad.addColorStop(0.75, '#040b1b');
    waterGrad.addColorStop(1, '#02050e');
    riverCtx.fillStyle = waterGrad;
    riverCtx.fillRect(0, 0, rWidth, rHeight);

    // 2. Flowing Horizontal Water Ripples (Similar to the reference video)
    const waveCount = 7;
    for (let w = 0; w < waveCount; w++) {
      const progress = w / waveCount;
      const baseY = rHeight * (0.08 + progress * 0.88);
      const speed = 0.0006 + progress * 0.0008;
      const freq = 0.005 + (1 - progress) * 0.003;
      const amp = 1.0 + progress * 2.5;

      riverCtx.beginPath();
      riverCtx.moveTo(0, baseY);

      for (let x = 0; x <= rWidth; x += 30) {
        const waveY = baseY + Math.sin(x * freq + now * speed + w * 1.4) * amp;
        riverCtx.lineTo(x, waveY);
      }

      const waveGrad = riverCtx.createLinearGradient(0, 0, rWidth, 0);
      waveGrad.addColorStop(0, 'rgba(79, 195, 247, 0)');
      waveGrad.addColorStop(0.2, 'rgba(139, 212, 176, 0.12)');
      waveGrad.addColorStop(0.5, 'rgba(243, 212, 137, 0.22)');
      waveGrad.addColorStop(0.8, 'rgba(79, 195, 247, 0.14)');
      waveGrad.addColorStop(1, 'rgba(79, 195, 247, 0)');

      riverCtx.strokeStyle = waveGrad;
      riverCtx.lineWidth = 1.2 + progress * 1.6;
      riverCtx.stroke();
    }

    // 3. Realistic Shimmering Moonlight Water Reflection (เงาพระจันทร์บนน้ำงดงามสมจริง)
    let moonCenterX = rWidth * 0.81; // default fallback aligned with moon
    if (scenicMoon) {
      const moonRect = scenicMoon.getBoundingClientRect();
      const riverRect = riverStage ? riverStage.getBoundingClientRect() : null;
      if (moonRect.width > 0 && window.innerWidth > 0) {
        moonCenterX = (moonRect.left + moonRect.width * 0.5);
        if (riverRect && riverRect.left > 0) {
          moonCenterX -= riverRect.left;
        }
      }
    }

    // 3A. Deep Ambient Radiant Water Sheen (แสงจันทร์ตกกระทบแผ่ซึมลงผิวน้ำอย่างนุ่มนวล ไร้รอยตัด)
    const ambientSlices = 12;
    for (let s = 0; s < ambientSlices; s++) {
      const sDepth = s / (ambientSlices - 1);
      const sy = sDepth * rHeight;
      const sWidth = (80 + sDepth * 340);
      const sAlpha = (0.32 * (1 - sDepth * 0.45)) * (0.85 + Math.sin(now * 0.002 + s * 0.5) * 0.15);

      const sGrad = riverCtx.createRadialGradient(moonCenterX, sy, 2, moonCenterX, sy, sWidth * 0.65);
      sGrad.addColorStop(0, `rgba(255, 248, 220, ${(sAlpha * 0.8).toFixed(3)})`);
      sGrad.addColorStop(0.35, `rgba(255, 228, 145, ${(sAlpha * 0.4).toFixed(3)})`);
      sGrad.addColorStop(0.7, `rgba(243, 212, 137, ${(sAlpha * 0.12).toFixed(3)})`);
      sGrad.addColorStop(1, 'rgba(243, 212, 137, 0)');

      riverCtx.fillStyle = sGrad;
      riverCtx.beginPath();
      riverCtx.ellipse(moonCenterX, sy, sWidth * 0.5, (rHeight / ambientSlices) * 1.5, 0, 0, Math.PI * 2);
      riverCtx.fill();
    }

    // 3B. Cascading Organic Caustic Wave Ribbons (ริ้วคลื่นน้ำระยับสะท้อนแสงจันทร์)
    const moonSteps = 42;
    const stepH = rHeight / moonSteps;

    for (let i = 1; i < moonSteps; i++) {
      const depthRatio = i / moonSteps; // 0 to 1
      const y = i * stepH;

      // Perspective width expansion from horizon to foreground
      const colWidth = (36 + depthRatio * 250) * (0.92 + Math.sin(now * 0.0018 + depthRatio * 4.2) * 0.08);

      // Multi-harmonic current wobble
      const wobble = Math.sin(y * 0.025 + now * 0.0022) * (7 + depthRatio * 18)
                   + Math.sin(y * 0.06 - now * 0.0038) * (3 + depthRatio * 8);

      const cx = moonCenterX + wobble;
      const pulseAlpha = (0.55 * (1 - depthRatio * 0.35)) * (0.8 + Math.sin(now * 0.003 + i * 0.65) * 0.2);

      // Soft radiant elliptical glow disc at this step
      const radGrad = riverCtx.createRadialGradient(cx, y, 1, cx, y, colWidth * 0.5);
      radGrad.addColorStop(0, `rgba(255, 252, 225, ${(pulseAlpha * 0.75).toFixed(3)})`);
      radGrad.addColorStop(0.35, `rgba(255, 230, 145, ${(pulseAlpha * 0.42).toFixed(3)})`);
      radGrad.addColorStop(0.7, `rgba(243, 212, 137, ${(pulseAlpha * 0.15).toFixed(3)})`);
      radGrad.addColorStop(1, 'rgba(243, 212, 137, 0)');

      riverCtx.fillStyle = radGrad;
      riverCtx.beginPath();
      riverCtx.ellipse(cx, y, colWidth * 0.48, stepH * 0.85, 0, 0, Math.PI * 2);
      riverCtx.fill();

      // Main undulating wave ribbon with specular ivory crest
      const ribbonW = colWidth * (0.55 + Math.sin(now * 0.0035 + i * 0.75) * 0.32);
      const waveWave1 = Math.sin(now * 0.0045 + i * 0.8) * (1.8 + depthRatio * 3.5);
      const waveWave2 = -Math.cos(now * 0.004 + i * 0.8) * (1.8 + depthRatio * 3.5);

      const strokeGrad = riverCtx.createLinearGradient(cx - ribbonW * 0.5, y, cx + ribbonW * 0.5, y);
      strokeGrad.addColorStop(0, 'rgba(255, 240, 180, 0)');
      strokeGrad.addColorStop(0.25, `rgba(255, 235, 170, ${(pulseAlpha * 0.65).toFixed(3)})`);
      strokeGrad.addColorStop(0.5, `rgba(255, 255, 240, ${(pulseAlpha * 0.95).toFixed(3)})`); // Ivory crest
      strokeGrad.addColorStop(0.75, `rgba(255, 235, 170, ${(pulseAlpha * 0.65).toFixed(3)})`);
      strokeGrad.addColorStop(1, 'rgba(255, 240, 180, 0)');

      riverCtx.strokeStyle = strokeGrad;
      riverCtx.lineWidth = 1.0 + depthRatio * 1.8;
      riverCtx.beginPath();
      riverCtx.moveTo(cx - ribbonW * 0.5, y);
      riverCtx.bezierCurveTo(
        cx - ribbonW * 0.22, y + waveWave1,
        cx + ribbonW * 0.22, y + waveWave2,
        cx + ribbonW * 0.5, y
      );
      riverCtx.stroke();

      // Secondary fine shimmering filament on alternate steps
      if (i % 2 === 0) {
        const subW = ribbonW * 0.65;
        const subY = y + stepH * 0.4;
        riverCtx.strokeStyle = `rgba(255, 250, 220, ${(pulseAlpha * 0.7).toFixed(3)})`;
        riverCtx.lineWidth = 0.8 + depthRatio * 0.9;
        riverCtx.beginPath();
        riverCtx.moveTo(cx - subW * 0.5, subY);
        riverCtx.bezierCurveTo(
          cx - subW * 0.15, subY - waveWave2 * 0.7,
          cx + subW * 0.15, subY + waveWave1 * 0.7,
          cx + subW * 0.5, subY
        );
        riverCtx.stroke();
      }
    }

    // 3C. Dancing Specular Water Glints / Sparkles (ประกายระยิบระยับผิวน้ำกระทบแสงจันทร์)
    moonSparkles.forEach(sp => {
      const sy = sp.depth * rHeight;
      const d = sp.depth;
      const colW = (38 + d * 240);
      const wobbleY = Math.sin(sy * 0.025 + now * 0.0022) * (7 + d * 18);
      const sx = (moonCenterX + wobbleY) + sp.offsetNorm * (colW * 0.44);

      const twinkle = (Math.sin(now * sp.twinkleSpeed + sp.twinklePhase) + 1) * 0.5; // 0 to 1
      if (twinkle < 0.28) return; // Only draw when glowing

      const alpha = (twinkle * (0.35 + (1 - d * 0.25))) * (0.75 + 0.25 * Math.sin(now * 0.004 + sp.twinklePhase));
      const sz = sp.baseSize * (0.85 + d * 0.8) * (0.7 + twinkle * 0.6);

      riverCtx.save();
      riverCtx.fillStyle = `rgba(255, 255, 240, ${alpha.toFixed(3)})`;
      riverCtx.shadowColor = 'rgba(255, 235, 170, 0.95)';
      riverCtx.shadowBlur = 4 * (1 + d * 0.6);

      // Horizontal specular diamond / ellipse glint
      riverCtx.beginPath();
      riverCtx.ellipse(sx, sy, sz * 2.4, sz * 0.65, 0, 0, Math.PI * 2);
      riverCtx.fill();

      // Bright white specular core
      if (twinkle > 0.72) {
        riverCtx.fillStyle = `rgba(255, 255, 255, ${(alpha * 1.1).toFixed(3)})`;
        riverCtx.beginPath();
        riverCtx.arc(sx, sy, sz * 0.55, 0, Math.PI * 2);
        riverCtx.fill();
      }
      riverCtx.restore();
    });

    // 4. Vertical Shimmering Light Reflections under EVERY Krathong (เงาสะท้อนตรงตามคลิป)
    krathongsMap.forEach(kr => {
      if (kr.isDescending && kr.descentProgress < 0.6) return;

      const posX = kr.x * rWidth;
      const posY = kr.currentY;
      const scale = kr.currentScale;
      const depth = kr.depth;

      // Candle Light reflection column starting at water contact point
      const baseWaterY = posY + 24 * scale;
      const beamLength = (55 + Math.sin(now * 0.004 + kr.bobPhase) * 14) * scale;
      const beamWidth = (24 + Math.cos(now * 0.0035 + kr.bobPhase) * 6) * scale;
      const flameAlpha = (0.7 + depth * 0.25) * (0.85 + Math.sin(now * 0.006 + kr.bobPhase) * 0.15);

      // Vertical shimmering golden column
      const flameGrad = riverCtx.createLinearGradient(posX, baseWaterY, posX, baseWaterY + beamLength);
      flameGrad.addColorStop(0, `rgba(255, 240, 190, ${flameAlpha.toFixed(2)})`);
      flameGrad.addColorStop(0.25, `rgba(255, 180, 80, ${(flameAlpha * 0.65).toFixed(2)})`);
      flameGrad.addColorStop(0.65, `rgba(243, 212, 137, ${(flameAlpha * 0.3).toFixed(2)})`);
      flameGrad.addColorStop(1, 'rgba(243, 212, 137, 0)');

      riverCtx.fillStyle = flameGrad;
      riverCtx.beginPath();
      riverCtx.ellipse(posX, baseWaterY + beamLength * 0.45, beamWidth * 0.5, beamLength * 0.55, 0, 0, Math.PI * 2);
      riverCtx.fill();

      // Water contact ellipse glow
      const discWidth = 72 * scale;
      const discHeight = 18 * scale;
      const discGrad = riverCtx.createRadialGradient(
        posX, baseWaterY, 3,
        posX, baseWaterY, discWidth * 0.5
      );
      discGrad.addColorStop(0, `rgba(255, 220, 140, ${(0.45 * flameAlpha).toFixed(2)})`);
      discGrad.addColorStop(1, 'rgba(8, 22, 44, 0)');

      riverCtx.fillStyle = discGrad;
      riverCtx.beginPath();
      riverCtx.ellipse(posX, baseWaterY, discWidth * 0.5, discHeight * 0.5, 0, 0, Math.PI * 2);
      riverCtx.fill();

      // Horizontal Shimmer Ripple Lines underneath Krathong (Exactly like the video clip)
      const rippleCount = 4;
      for (let r = 1; r <= rippleCount; r++) {
        const ry = baseWaterY + (r * 11) * scale;
        const rw = discWidth * (0.75 - r * 0.12) * (1 + Math.sin(now * 0.0035 + kr.bobPhase + r) * 0.2);
        riverCtx.strokeStyle = `rgba(255, 238, 180, ${(0.5 * flameAlpha / r).toFixed(2)})`;
        riverCtx.lineWidth = 1.3 * scale;
        riverCtx.beginPath();
        riverCtx.moveTo(posX - rw * 0.5, ry);
        riverCtx.lineTo(posX + rw * 0.5, ry);
        riverCtx.stroke();
      }
    });
  }

  // ================= 5. Krathong 2.5D River Physics =================
  class RiverKrathong {
    constructor(data, isNew = false) {
      this.data = data;
      this.id = data.id || `k_${Date.now()}_${Math.random()}`;
      this.isNew = isNew;

      this.rWidth = rWidth || window.innerWidth;
      this.rHeight = rHeight || (window.innerHeight * 0.5);

      // Depth (0.0 = Horizon/Far, 1.0 = Foreground/Near)
      if (isNew) {
        this.targetDepth = 0.65 + Math.random() * 0.3;
        this.depth = this.targetDepth;
        this.x = 0.25 + Math.random() * 0.5;
        this.isDescending = true;
        this.descentDuration = 3200; // ms
        this.descentStartTime = performance.now();
        this.descentStartY = -240;
        this.descentProgress = 0;
      } else {
        this.depth = 0.08 + Math.random() * 0.88;
        this.x = Math.random();
        this.isDescending = false;
        this.descentProgress = 1;
      }

      // Very slow, tranquil river drift speed
      this.driftSpeed = (0.000005 + this.depth * 0.000008) * (Math.random() < 0.25 ? -1 : 1);
      this.bobPhase = Math.random() * Math.PI * 2;
      this.bobSpeed = 0.0016 + Math.random() * 0.0012;
      this.swayPhase = Math.random() * Math.PI * 2;

      this.currentY = 0;
      this.currentScale = 0.38 + this.depth * 0.62;

      this.createDOM();
    }

    createDOM() {
      const typeMeta = KR_TYPES[this.data.krathongType] || KR_TYPES.royal;

      this.el = document.createElement('div');
      this.el.className = 'krathong-river-item' + (this.isNew ? ' new-arrival' : '');
      this.el.dataset.id = this.id;

      this.el.innerHTML = `
        ${this.isNew ? `
          <div class="kr-new-badge">
            <span class="badge-sparkle">✨</span>
            <span class="badge-txt">กระทงใหม่</span>
          </div>
          <div class="kr-spotlight-aura"></div>
        ` : ''}
        <div class="kr-body-wrap">
          <img src="${typeMeta.image}" alt="${typeMeta.title}" class="kr-cutout-img">
        </div>
        <div class="kr-name-badge">${escapeHTML(this.data.senderName || 'ผู้โดยสารนิรนาม')} ✦</div>
      `;

      this.el.addEventListener('click', (e) => {
        e.stopPropagation();
        openKrathongDetail(this.data);
      });

      krathongsRiverLayer.appendChild(this.el);

      if (this.isNew) {
        this.startStardustEmitter();
      }
    }

    startStardustEmitter() {
      const symbols = ['✨', '✦', '⋆', '•', '🌟'];
      this.stardustInterval = setInterval(() => {
        if (!this.el || !this.el.parentNode) {
          if (this.stardustInterval) clearInterval(this.stardustInterval);
          return;
        }
        const particle = document.createElement('div');
        particle.className = 'kr-stardust-particle';
        particle.textContent = symbols[Math.floor(Math.random() * symbols.length)];
        const startX = (Math.random() * 80 - 40);
        const startY = (Math.random() * 30 - 15);
        const driftX = (Math.random() * 50 - 25);
        particle.style.left = `calc(50% + ${startX.toFixed(1)}px)`;
        particle.style.top = `calc(40% + ${startY.toFixed(1)}px)`;
        particle.style.setProperty('--sd-dx', `${driftX.toFixed(1)}px`);
        this.el.appendChild(particle);

        setTimeout(() => {
          if (particle.parentNode) particle.parentNode.removeChild(particle);
        }, 1600);
      }, 220);

      // Fade out and cleanup new-arrival effects after 8.5 seconds
      setTimeout(() => {
        if (this.stardustInterval) clearInterval(this.stardustInterval);
        if (this.el) {
          const badge = this.el.querySelector('.kr-new-badge');
          const aura = this.el.querySelector('.kr-spotlight-aura');
          if (badge) badge.style.opacity = '0';
          if (aura) aura.style.opacity = '0';
          setTimeout(() => {
            if (badge && badge.parentNode) badge.parentNode.removeChild(badge);
            if (aura && aura.parentNode) aura.parentNode.removeChild(aura);
            if (this.el) this.el.classList.remove('new-arrival');
          }, 900);
        }
      }, 8500);
    }

    update(now) {
      this.currentScale = 0.38 + this.depth * 0.62;

      if (this.isDescending) {
        const elapsed = now - this.descentStartTime;
        this.descentProgress = Math.min(1, elapsed / this.descentDuration);
        const ease = 1 - Math.pow(1 - this.descentProgress, 3);

        const targetY = this.depth * rHeight;
        this.currentY = this.descentStartY + (targetY - this.descentStartY) * ease;
        this.currentScale = (0.35 + (this.currentScale - 0.35) * ease) * (1 + (1 - ease) * 0.4);

        if (this.descentProgress >= 1) {
          this.isDescending = false;
          const splashX = this.x * rWidth;
          createWaterSplash(splashX, targetY + 30 * this.currentScale);
          createArrivalSpotlight(splashX, targetY + 18 * this.currentScale);
          playLandingChime();
        }
      } else {
        this.x += this.driftSpeed * 16;
        if (this.x > 1.06) this.x = -0.06;
        if (this.x < -0.06) this.x = 1.06;

        const bobAmp = 1.6 + this.depth * 3.4;
        const bobOffset = Math.sin(now * this.bobSpeed + this.bobPhase) * bobAmp;
        this.currentY = (this.depth * rHeight) + bobOffset;
      }

      const swayAngle = Math.sin(now * 0.0014 + this.swayPhase) * (1.0 + this.depth * 1.2);

      const posX = this.x * rWidth;
      const zIndex = Math.floor(this.depth * 1000);

      this.el.style.left = `${posX}px`;
      this.el.style.top = `${this.currentY}px`;
      this.el.style.transform = `translate(-50%, -65%) scale(${this.currentScale.toFixed(3)}) rotate(${swayAngle.toFixed(2)}deg)`;
      this.el.style.zIndex = zIndex;
    }

    destroy() {
      if (this.stardustInterval) clearInterval(this.stardustInterval);
      if (this.el && this.el.parentNode) this.el.parentNode.removeChild(this.el);
    }
  }

  // ================= 6. Water Splash & Arrival Spotlight Effect =================
  function createWaterSplash(x, y) {
    const splash = document.createElement('div');
    splash.className = 'splash-container';
    splash.style.left = `${x}px`;
    splash.style.top = `${y}px`;

    const ring1 = document.createElement('div');
    ring1.className = 'splash-ring ring-1';
    const ring2 = document.createElement('div');
    ring2.className = 'splash-ring ring-2';
    const ring3 = document.createElement('div');
    ring3.className = 'splash-ring ring-3';

    splash.appendChild(ring1);
    splash.appendChild(ring2);
    splash.appendChild(ring3);

    effectsLayer.appendChild(splash);

    setTimeout(() => {
      if (splash.parentNode) splash.parentNode.removeChild(splash);
    }, 1800);
  }

  function createArrivalSpotlight(x, y) {
    if (!effectsLayer) return;
    const wrapper = document.createElement('div');
    wrapper.className = 'spotlight-arrival-wrapper';
    wrapper.style.left = `${x}px`;
    wrapper.style.top = `${y}px`;

    wrapper.innerHTML = `
            <div class="spotlight-water-rings">
        <div class="spotlight-ring r1"></div>
        <div class="spotlight-ring r2"></div>
        <div class="spotlight-ring r3"></div>
      </div>
      <div class="spotlight-glow-pool"></div>
    `;

    effectsLayer.appendChild(wrapper);

    setTimeout(() => {
      if (wrapper.parentNode) wrapper.parentNode.removeChild(wrapper);
    }, 8600);
  }

  // ================= 7. Toast Announcements =================
  let toastTimer = null;
  function showToast(sender, wish) {
    if (!newToast) return;
    toastSender.textContent = `คุณ ${sender}`;
    toastWish.textContent = `“${wish}”`;

    newToast.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      newToast.classList.remove('show');
    }, 6500);
  }

  // ================= 8. Modal Krathong Detail =================
  function openKrathongDetail(data) {
    const typeMeta = KR_TYPES[data.krathongType] || KR_TYPES.royal;
    modalKrImg.src = typeMeta.image;
    modalSender.textContent = `คุณ ${data.senderName || 'ผู้โดยสารนิรนาม'}`;
    modalType.textContent = `“กระทง${typeMeta.title}”`;
    modalWish.textContent = data.wishText || 'ขอให้ปีนี้มีความสุข สมหวังทุกประการ';

    if (data.timestamp) {
      const d = new Date(data.timestamp);
      modalTime.textContent = `ลอยเมื่อเวลา ${d.getHours().toString().padStart(2, '0')}:${d.getMinutes().toString().padStart(2, '0')} น.`;
    } else {
      modalTime.textContent = 'ลอยในค่ำคืนนี้';
    }

    krModalBackdrop.classList.add('active');
    krDetailModal.classList.add('active');
  }

  function closeKrathongDetail() {
    krModalBackdrop.classList.remove('active');
    krDetailModal.classList.remove('active');
  }

  if (krModalClose) krModalClose.addEventListener('click', closeKrathongDetail);
  if (krModalBackdrop) krModalBackdrop.addEventListener('click', closeKrathongDetail);

  // ================= 9. Add & Manage Krathongs =================
  function addOrUpdateKrathong(data, isNew = false) {
    if (!data || !data.id) return;

    if (krathongsMap.has(data.id)) {
      return;
    }

    const rk = new RiverKrathong(data, isNew);
    krathongsMap.set(data.id, rk);

    updateKrCount();

    if (isNew) {
      showToast(data.senderName || 'ผู้โดยสารนิรนาม', data.wishText || 'เดินทางปลอดภัย ไร้อุปสรรค');
      launchCelebrationBurst();
    }
  }

  function updateKrCount() {
    if (krCountEl) {
      krCountEl.textContent = krathongsMap.size;
    }
  }

  // ================= 10. QR Code Setup with Live Re-render =================
  function renderQRCode(urlToEncode) {
    if (!urlToEncode || !qrcodeContainer) return;
    if (qrUrlBox) qrUrlBox.textContent = urlToEncode;
    qrcodeContainer.innerHTML = '';

    if (window.QRCode) {
      new QRCode(qrcodeContainer, {
        text: urlToEncode,
        width: 150,
        height: 150,
        colorDark: '#040916',
        colorLight: '#ffffff',
        correctLevel: QRCode.CorrectLevel.M
      });
    }

    if (qrSubtitle) {
      if (activeMode === 'public') {
        qrSubtitle.textContent = '🟢 สแกนได้ทั้งเน็ต 4G/5G และ Wi-Fi';
        qrSubtitle.style.color = '#8bd4b0';
      } else {
        qrSubtitle.textContent = '🏠 สำหรับเครื่องที่ต่อ Wi-Fi เดียวกัน';
        qrSubtitle.style.color = '#f3d489';
      }
    }
  }

  async function fetchServerInfo() {
    try {
      const res = await fetch('/api/info');
      const info = await res.json();
      currentLocalUrl = info.localUrl || `http://${info.ip}:${info.port}/mobile.html`;
      if (info.publicUrl) {
        currentPublicUrl = info.publicUrl;
      }

      const target = (activeMode === 'public' && currentPublicUrl) ? currentPublicUrl : currentLocalUrl;
      renderQRCode(target);
    } catch (e) {
      console.warn('Could not fetch server info, fallback to current origin:', e);
      renderQRCode(window.location.origin + '/mobile.html');
    }
  }

  if (btnModePublic) {
    btnModePublic.addEventListener('click', () => {
      activeMode = 'public';
      btnModePublic.classList.add('active');
      btnModeLocal.classList.remove('active');
      renderQRCode(currentPublicUrl || currentLocalUrl);
    });
  }

  if (btnModeLocal) {
    btnModeLocal.addEventListener('click', () => {
      activeMode = 'local';
      btnModeLocal.classList.add('active');
      btnModePublic.classList.remove('active');
      renderQRCode(currentLocalUrl);
    });
  }

  if (qrToggleBtn && qrCard) {
    qrToggleBtn.addEventListener('click', () => {
      qrCard.classList.toggle('minimized');
      qrToggleBtn.textContent = qrCard.classList.contains('minimized') ? '+' : '−';
    });
  }

  // ================= 11. Controls Bar =================
  if (btnAudio) {
    btnAudio.addEventListener('click', () => {
      initAudio();
      audioEnabled = !audioEnabled;
      btnAudio.querySelector('.icon').textContent = audioEnabled ? '🔊' : '🔇';
      btnAudio.querySelector('.label').textContent = audioEnabled ? 'เปิดเสียง' : 'ปิดเสียง';
    });
  }

  if (btnFireworks) {
    btnFireworks.addEventListener('click', () => {
      initAudio();
      launchCelebrationBurst();
    });
  }

  if (btnFullscreen) {
    btnFullscreen.addEventListener('click', () => {
      if (!document.fullscreenElement) {
        document.documentElement.requestFullscreen().catch(err => console.warn(err));
      } else {
        document.exitFullscreen().catch(err => console.warn(err));
      }
    });
  }

  // Simulator Test Button
  if (btnSimulate) {
    btnSimulate.addEventListener('click', () => {
      const sampleNames = ['น้องฟ้าใส', 'กัปตันชานนท์', 'แอนนา', 'คุณภีร์', 'ญาญ่า', 'ผู้โดยสารตรัง'];
      const sampleWishes = [
        'ขอให้ทุกเที่ยวบินปลอดภัย ราบรื่นตลอดเส้นทาง',
        'การงานก้าวหน้า ค้าขายร่ำรวย เงินทองไหลมาเทมา',
        'ขอให้ปีนี้เป็นปีที่ใจดี มีรอยยิ้มในทุกๆ วัน',
        'สุขภาพร่างกายแข็งแรง ไร้โรคภัยเบียดเบียน'
      ];
      const types = ['royal', 'minimal', 'lotus', 'marigold', 'eco', 'bread', 'airplane', 'dugong'];

      addOrUpdateKrathong({
        id: `sim_${Date.now()}`,
        senderName: sampleNames[Math.floor(Math.random() * sampleNames.length)],
        wishText: sampleWishes[Math.floor(Math.random() * sampleWishes.length)],
        krathongType: types[Math.floor(Math.random() * types.length)],
        timestamp: Date.now()
      }, true);
    });
  }

  // ================= 12. Real-time SSE Stream =================
  function initSSE() {
    const eventSource = new EventSource('/api/events');

    eventSource.onopen = () => {
      console.log('[SSE] River Display connected to real-time events.');
    };

    eventSource.addEventListener('init', (e) => {
      try {
        const list = JSON.parse(e.data);
        console.log(`[SSE] Initialized ${list.length} krathongs.`);
        list.forEach(k => addOrUpdateKrathong(k, false));
      } catch (err) {
        console.error('Error parsing init krathongs:', err);
      }
    });

    eventSource.addEventListener('tunnel_url', (e) => {
      try {
        const d = JSON.parse(e.data);
        console.log('[SSE] Live Tunnel URL received:', d);
        if (d.publicUrl) {
          currentPublicUrl = d.publicUrl;
          if (activeMode === 'public') {
            renderQRCode(currentPublicUrl);
          }
        }
        if (d.localUrl) currentLocalUrl = d.localUrl;
      } catch (err) {
        console.error('Error parsing tunnel_url:', err);
      }
    });

    eventSource.addEventListener('new_krathong', (e) => {
      try {
        const k = JSON.parse(e.data);
        console.log('[SSE] New Krathong arrived on river:', k);
        addOrUpdateKrathong(k, true);
      } catch (err) {
        console.error('Error parsing new krathong:', err);
      }
    });

    eventSource.addEventListener('clear', () => {
      krathongsMap.forEach(k => k.destroy());
      krathongsMap.clear();
      updateKrCount();
    });

    eventSource.onerror = (err) => {
      console.warn('[SSE] EventSource disconnected, retrying automatically...', err);
    };
  }

  // ================= 13. 60 FPS Render Loop =================
  function animate(now) {
    // 1. Update Krathongs DOM physics
    krathongsMap.forEach(k => k.update(now));

    // 2. Render Canvas River Water, Waves, Moonlight & Krathong Reflections
    renderRiverWater(now);

    // 3. Render Canvas Fireworks & Particle System
    updateFireworks(now);

    requestAnimationFrame(animate);
  }

  // Helper
  function escapeHTML(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  // ================= 8. Riverbank Fireflies =================
  function initFireflies() {
    const container = document.getElementById('firefliesLayer');
    if (!container) return;
    const fireflyCount = 18;
    for (let i = 0; i < fireflyCount; i++) {
      const f = document.createElement('div');
      f.className = 'firefly';

      // Cluster: 45% left shore, 45% right shore, 10% center water line
      let xPos;
      if (i < 8) {
        xPos = 2 + Math.random() * 26; // 2% to 28% (left shore reeds)
      } else if (i < 16) {
        xPos = 72 + Math.random() * 26; // 72% to 98% (right shore reeds)
      } else {
        xPos = 30 + Math.random() * 40; // 30% to 70% (center water pads)
      }
      const yPos = 32 + Math.random() * 62; // 32% to 94% of riverbank height

      f.style.left = `${xPos.toFixed(1)}%`;
      f.style.top = `${yPos.toFixed(1)}%`;

      const dur = (5 + Math.random() * 4).toFixed(1);
      const glowDur = (2.2 + Math.random() * 2.5).toFixed(1);
      const delay = (Math.random() * 5).toFixed(1);
      const driftX = (Math.random() * 40 - 20).toFixed(0);
      const driftY = (-(15 + Math.random() * 28)).toFixed(0);

      f.style.setProperty('--f-dur', `${dur}s`);
      f.style.setProperty('--f-glow-dur', `${glowDur}s`);
      f.style.setProperty('--f-drift-x', `${driftX}px`);
      f.style.setProperty('--f-drift-y', `${driftY}px`);
      f.style.animationDelay = `${delay}s`;

      container.appendChild(f);
    }
  }

  // Init Execution
  initStars();
  initLanterns();
  initMoonSparkles();
  initFireflies();
  fetchServerInfo();
  initSSE();
  requestAnimationFrame(animate);

  // Periodic poll check in case Cloudflare tunnel was delayed
  setInterval(() => {
    if (!currentPublicUrl) {
      fetchServerInfo();
    }
  }, 5000);
})();
