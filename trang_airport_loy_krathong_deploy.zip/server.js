/**
 * Trang Airport Loy Krathong 2026 - Real-time Server
 * With Cloudflare Public Tunnel for instant 4G/5G/Wi-Fi mobile scanning
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const url = require('url');
const { spawn } = require('child_process');
const { filterKrathongInput } = require('./profanityFilter');

// Unhandled Crash Guards: Never allow the server process to crash on network blips or unhandled promises
process.on('uncaughtException', (err) => {
    console.error('[Process Uncaught Exception]:', err && err.stack ? err.stack : err);
});
process.on('unhandledRejection', (reason, promise) => {
    console.error('[Process Unhandled Rejection]:', reason);
});

const PORT = process.env.PORT || 3000;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'trang2569';
let totalReactions = 0;
const PUBLIC_DIR = path.join(__dirname, 'public');
const DATA_DIR = path.join(__dirname, 'data');
const DATA_FILE = path.join(DATA_DIR, 'krathongs.json');
const CLOUDFLARED_BIN = path.join(__dirname, 'cloudflared.exe');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Load or initialize krathongs data
let krathongs = [];
if (fs.existsSync(DATA_FILE)) {
    try {
        const raw = fs.readFileSync(DATA_FILE, 'utf8');
        krathongs = JSON.parse(raw);
    } catch (e) {
        console.error('[Storage] Error reading krathongs.json:', e);
        krathongs = [];
    }
}

function saveKrathongs() {
    try {
        fs.writeFileSync(DATA_FILE, JSON.stringify(krathongs, null, 2), 'utf8');
    } catch (e) {
        console.error('[Storage] Failed to save krathongs:', e);
    }
}

// Get primary local IPv4 address
function getLocalIP() {
    const interfaces = os.networkInterfaces();
    let bestIP = 'localhost';
    for (const name of Object.keys(interfaces)) {
        for (const net of interfaces[name]) {
            if (net.family === 'IPv4' && !net.internal) {
                if (net.address.startsWith('192.168.') || net.address.startsWith('10.') || net.address.startsWith('172.')) {
                    return net.address;
                }
                bestIP = net.address;
            }
        }
    }
    return bestIP;
}

const localIP = getLocalIP();
let publicTunnelUrl = process.env.RENDER_EXTERNAL_URL || process.env.PUBLIC_URL || null;
let tunnelProcess = null;

// SSE Client Pool
const sseClients = new Set();

function broadcastEvent(eventType, data) {
    const payload = `event: ${eventType}\ndata: ${JSON.stringify(data)}\n\n`;
    for (const client of sseClients) {
        try {
            client.res.write(payload);
        } catch (e) {
            sseClients.delete(client);
        }
    }
}

// Start Cloudflare Tunnel for instant public 4G/5G mobile access (local development / on-premise)
function startTunnel() {
    if (process.env.RENDER || process.env.RENDER_EXTERNAL_URL || process.env.PUBLIC_URL) {
        console.log(`[Cloud] Running in Cloud/Render environment: ${publicTunnelUrl || 'Ready'}`);
        return;
    }
    if (!fs.existsSync(CLOUDFLARED_BIN)) {
        console.log('[Tunnel] cloudflared.exe not found, using Local IP only.');
        return;
    }

    console.log('[Tunnel] Starting Cloudflare Public Tunnel for port ' + PORT + '...');
    try {
        tunnelProcess = spawn(CLOUDFLARED_BIN, ['tunnel', '--url', `http://localhost:${PORT}`]);

        const urlRegex = /https:\/\/[a-z0-9-]+\.trycloudflare\.com/;

        tunnelProcess.stderr.on('data', chunk => {
            const str = chunk.toString();
            const match = str.match(urlRegex);
            if (match && !publicTunnelUrl) {
                publicTunnelUrl = match[0];
                const activeUrl = `${publicTunnelUrl}/mobile.html`;
                try {
                    fs.writeFileSync(path.join(DATA_DIR, 'active_url.txt'), activeUrl, 'utf8');
                } catch (e) {}

                console.log(`\n========================================================================`);
                console.log(`  🌐 PUBLIC 4G/5G URL READY: ${activeUrl}`);
                console.log(`========================================================================\n`);

                // Broadcast to big screen so QR code updates live
                broadcastEvent('tunnel_url', {
                    publicUrl: activeUrl,
                    localUrl: `http://${localIP}:${PORT}/mobile.html`,
                    mobileUrl: activeUrl
                });
            }
        });

        tunnelProcess.on('error', err => {
            console.warn('[Tunnel] Failed to spawn cloudflared:', err.message);
        });

        tunnelProcess.on('exit', code => {
            console.log('[Tunnel] Tunnel process exited with code:', code, 'Reconnecting in 3s...');
            publicTunnelUrl = null;
            setTimeout(startTunnel, 3000);
        });
    } catch (err) {
        console.warn('[Tunnel] Error launching tunnel:', err.message);
    }
}

// Cleanup on exit
process.on('SIGINT', cleanup);
process.on('SIGTERM', cleanup);
process.on('exit', cleanup);

function cleanup() {
    if (tunnelProcess) {
        try { tunnelProcess.kill(); } catch (e) {}
    }
}

// MIME types lookup
const MIME_TYPES = {
    '.html': 'text/html; charset=utf-8',
    '.css': 'text/css; charset=utf-8',
    '.js': 'application/javascript; charset=utf-8',
    '.json': 'application/json; charset=utf-8',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.svg': 'image/svg+xml',
    '.ico': 'image/x-icon',
    '.mp3': 'audio/mpeg',
    '.wav': 'audio/wav'
};

const server = http.createServer((req, res) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

    if (req.method === 'OPTIONS') {
        res.writeHead(204);
        res.end();
        return;
    }

    // Auto-detect public URL from host header if running on Cloud / Reverse Proxy
    const hostHeader = req.headers['x-forwarded-host'] || req.headers.host;
    const protoHeader = req.headers['x-forwarded-proto'] || (req.connection && req.connection.encrypted ? 'https' : 'http');
    if (!publicTunnelUrl && hostHeader && !hostHeader.includes('localhost') && !hostHeader.includes('127.0.0.1') && !hostHeader.includes(localIP)) {
        publicTunnelUrl = `${protoHeader}://${hostHeader}`;
        console.log(`[Cloud] Auto-detected public origin: ${publicTunnelUrl}`);
        broadcastEvent('tunnel_url', {
            publicUrl: `${publicTunnelUrl}/mobile.html`,
            localUrl: `http://${localIP}:${PORT}/mobile.html`,
            mobileUrl: `${publicTunnelUrl}/mobile.html`
        });
    }

    const parsedUrl = url.parse(req.url, true);
    const pathname = parsedUrl.pathname;

    // API: System Info & Mobile URL
    // Ping / Health check endpoint
    if (pathname === '/api/ping' && req.method === 'GET') {
        res.writeHead(200, { 'Content-Type': 'text/plain' });
        res.end('pong');
        return;
    }

    if (pathname === '/api/info' && req.method === 'GET') {
        const localUrl = `http://${localIP}:${PORT}/mobile.html`;
        const activeMobileUrl = publicTunnelUrl ? `${publicTunnelUrl}/mobile.html` : localUrl;

        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
            ip: localIP,
            port: PORT,
            localUrl,
            publicUrl: publicTunnelUrl ? `${publicTunnelUrl}/mobile.html` : null,
            mobileUrl: activeMobileUrl,
            totalKrathongs: krathongs.length,
            serverTime: Date.now()
        }));
        return;
    }

    // API: Get all floating krathongs
    if (pathname === '/api/krathongs' && req.method === 'GET') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(krathongs));
        return;
    }

    // API: Real-time Event Stream (SSE)
    if (pathname === '/api/events' && req.method === 'GET') {
        res.writeHead(200, {
            'Content-Type': 'text/event-stream',
            'Cache-Control': 'no-cache, no-transform',
            'Connection': 'keep-alive'
        });
        res.write('\n');

        const client = { id: Date.now(), res };
        sseClients.add(client);

        // Send current full list on connect
        res.write(`event: init\ndata: ${JSON.stringify(krathongs)}\n\n`);

        // If public tunnel is already active, send it
        if (publicTunnelUrl) {
            res.write(`event: tunnel_url\ndata: ${JSON.stringify({
                publicUrl: `${publicTunnelUrl}/mobile.html`,
                localUrl: `http://${localIP}:${PORT}/mobile.html`,
                mobileUrl: `${publicTunnelUrl}/mobile.html`
            })}\n\n`);
        }

        req.on('close', () => {
            sseClients.delete(client);
        });
        return;
    }

    // API: Float a new Krathong (From Mobile)
    if (pathname === '/api/float' && req.method === 'POST') {
        req.setEncoding('utf8');
        let body = '';
        req.on('data', chunk => {
            body += chunk;
            if (body.length > 500000) req.destroy();
        });

        req.on('end', () => {
            try {
                const data = JSON.parse(body);

                // Background Profanity & Security Sanitization (Silent, no UI warnings)
                const filtered = filterKrathongInput(data.senderName, data.wishText);
                const senderName = filtered.senderName;
                const wishText = filtered.wishText;

                const krathongType = ['royal', 'minimal', 'lotus', 'marigold', 'eco', 'bread', 'airplane', 'dugong'].includes(data.krathongType) 
                    ? data.krathongType 
                    : 'royal';

                const newKrathong = {
                    id: (data.id && typeof data.id === 'string' && data.id.startsWith('kr_')) 
                        ? data.id 
                        : ('kr_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6)),
                    senderName,
                    wishText,
                    krathongType,
                    timestamp: Date.now(),
                    x: 0.22 + Math.random() * 0.56,
                    y: 0.25 + Math.random() * 0.35
                };

                krathongs.push(newKrathong);
                saveKrathongs();

                broadcastEvent('new_krathong', newKrathong);
                console.log(`[Float] From: "${senderName}" (${krathongType}). Total: ${krathongs.length}`);

                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({
                    success: true,
                    message: 'กระทงของคุณลอยลงสู่สระน้ำเรียบร้อยแล้ว!',
                    krathong: newKrathong
                }));
            } catch (err) {
                res.writeHead(400, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ success: false, error: 'ข้อมูลไม่ถูกต้อง' }));
            }
        });
        return;
    }

    // API: Live Krathong Reaction (❤️ Heart / ✨ Sparkle)
    if (pathname === '/api/reaction' && req.method === 'POST') {
        req.setEncoding('utf8');
        let body = '';
        req.on('data', chunk => {
            body += chunk;
            if (body.length > 5000) req.destroy();
        });

        req.on('end', () => {
            try {
                const { krathongId, type } = JSON.parse(body);
                if (krathongId && (type === 'heart' || type === 'sparkle')) {
                    totalReactions++;
                    broadcastEvent('krathong_reaction', {
                        krathongId,
                        type,
                        timestamp: Date.now()
                    });
                    console.log(`[Reaction] ${type} sent to ${krathongId}`);
                    res.writeHead(200, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ ok: true, totalReactions }));
                    return;
                }
                res.writeHead(400, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ ok: false, error: 'Invalid parameters' }));
            } catch (err) {
                res.writeHead(400, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ ok: false, error: 'Invalid JSON' }));
            }
        });
        return;
    }

    // ================= ADMIN APIS =================
    function verifyAdminRequest(req, res) {
        const token = req.headers['x-admin-token'] || req.headers['authorization'];
        if (token === `Bearer ${ADMIN_PASSWORD}` || token === ADMIN_PASSWORD) {
            return true;
        }
        res.writeHead(401, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: false, error: 'Unauthorized: รหัสผ่านไม่ถูกต้อง' }));
        return false;
    }

    // Admin API: Login Verification
    if (pathname === '/api/admin/login' && req.method === 'POST') {
        let body = '';
        req.on('data', chunk => body += chunk);
        req.on('end', () => {
            try {
                const { password } = JSON.parse(body);
                if (password === ADMIN_PASSWORD) {
                    res.writeHead(200, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ ok: true, token: ADMIN_PASSWORD }));
                } else {
                    res.writeHead(401, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ ok: false, error: 'รหัสผ่านแอดมินไม่ถูกต้อง' }));
                }
            } catch (e) {
                res.writeHead(400, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ ok: false, error: 'Invalid JSON' }));
            }
        });
        return;
    }

    // Admin API: Statistics
    if (pathname === '/api/admin/stats' && req.method === 'GET') {
        if (!verifyAdminRequest(req, res)) return;

        const typeCounts = {
            royal: 0,
            lotus: 0,
            marigold: 0,
            eco: 0,
            bread: 0,
            airplane: 0,
            dugong: 0,
            minimal: 0
        };

        krathongs.forEach(k => {
            const t = k.krathongType || 'royal';
            typeCounts[t] = (typeCounts[t] || 0) + 1;
        });

        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
            ok: true,
            totalKrathongs: krathongs.length,
            totalReactions,
            typeCounts,
            publicUrl: publicTunnelUrl ? `${publicTunnelUrl}/mobile.html` : null,
            localUrl: `http://${localIP}:${PORT}/mobile.html`,
            serverUptime: Math.floor(process.uptime()),
            serverTime: Date.now()
        }));
        return;
    }

    // Admin API: Full Krathongs List (Latest first)
    if (pathname === '/api/admin/krathongs' && req.method === 'GET') {
        if (!verifyAdminRequest(req, res)) return;
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: true, krathongs: [...krathongs].reverse() }));
        return;
    }

    // Admin API: Delete specific Krathong
    if (pathname === '/api/admin/delete' && req.method === 'POST') {
        if (!verifyAdminRequest(req, res)) return;
        let body = '';
        req.on('data', chunk => body += chunk);
        req.on('end', () => {
            try {
                const { id } = JSON.parse(body);
                const idx = krathongs.findIndex(k => k.id === id);
                if (idx !== -1) {
                    const deleted = krathongs.splice(idx, 1)[0];
                    saveKrathongs();
                    broadcastEvent('delete_krathong', { id });
                    console.log(`[Admin] Deleted krathong ${id} from "${deleted.senderName}"`);
                    res.writeHead(200, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ ok: true, id, remaining: krathongs.length }));
                } else {
                    res.writeHead(404, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ ok: false, error: 'ไม่พบกระทงที่ต้องการลบ' }));
                }
            } catch (e) {
                res.writeHead(400, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ ok: false, error: 'Invalid JSON' }));
            }
        });
        return;
    }

    // Admin API: Spotlight Highlight Krathong
    if (pathname === '/api/admin/highlight' && req.method === 'POST') {
        if (!verifyAdminRequest(req, res)) return;
        let body = '';
        req.on('data', chunk => body += chunk);
        req.on('end', () => {
            try {
                const { id } = JSON.parse(body);
                broadcastEvent('highlight_krathong', { id });
                console.log(`[Admin] Highlighted krathong ${id}`);
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ ok: true, id }));
            } catch (e) {
                res.writeHead(400, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ ok: false, error: 'Invalid JSON' }));
            }
        });
        return;
    }

    // Admin API: Grand Fireworks Burst on Big Screen
    if (pathname === '/api/admin/fireworks' && req.method === 'POST') {
        if (!verifyAdminRequest(req, res)) return;
        broadcastEvent('grand_fireworks', { count: 8 });
        console.log(`[Admin] Triggered Grand Fireworks from dashboard`);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ ok: true }));
        return;
    }

    // Admin API: Reset all Krathongs with automatic backup
    if (pathname === '/api/admin/reset' && req.method === 'POST') {
        if (!verifyAdminRequest(req, res)) return;
        let body = '';
        req.on('data', chunk => body += chunk);
        req.on('end', () => {
            try {
                const { password } = JSON.parse(body);
                if (password !== ADMIN_PASSWORD) {
                    res.writeHead(403, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ ok: false, error: 'รหัสยืนยันไม่ถูกต้อง' }));
                    return;
                }

                // Automatic backup
                const backupFile = path.join(DATA_DIR, `backup_krathongs_${Date.now()}.json`);
                fs.writeFileSync(backupFile, JSON.stringify(krathongs, null, 2), 'utf8');
                console.log(`[Admin] Backed up ${krathongs.length} krathongs to ${backupFile}`);

                krathongs = [];
                totalReactions = 0;
                saveKrathongs();
                broadcastEvent('clear', { timestamp: Date.now() });

                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ ok: true, message: 'รีเซ็ตข้อมูลและสำรองไฟล์เรียบร้อยแล้ว' }));
            } catch (e) {
                res.writeHead(400, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ ok: false, error: 'Invalid JSON' }));
            }
        });
        return;
    }

    // Admin API: Export CSV (UTF-8 BOM for Excel)
    if (pathname === '/api/admin/export' && req.method === 'GET') {
        const token = parsedUrl.query.token || req.headers['x-admin-token'];
        if (token !== ADMIN_PASSWORD) {
            res.writeHead(401, { 'Content-Type': 'text/plain; charset=utf-8' });
            res.end('Unauthorized: กรุณาเข้าสู่ระบบแอดมิน');
            return;
        }

        let csv = '\uFEFFลำดับ,รหัสกระทง,ชื่อผู้ส่ง,คำอวยพร,ประเภทกระทง,วันเวลาที่ลอย\n';
        krathongs.forEach((k, idx) => {
            const dateStr = new Date(k.timestamp || Date.now()).toLocaleString('th-TH', { timeZone: 'Asia/Bangkok' });
            const sender = `"${(k.senderName || '').replace(/"/g, '""')}"`;
            const wish = `"${(k.wishText || '').replace(/"/g, '""')}"`;
            const type = k.krathongType || 'royal';
            csv += `${idx + 1},${k.id},${sender},${wish},${type},"${dateStr}"\n`;
        });

        const filename = `krathongs_trang_airport_${Date.now()}.csv`;
        res.writeHead(200, {
            'Content-Type': 'text/csv; charset=utf-8',
            'Content-Disposition': `attachment; filename="${filename}"`
        });
        res.end(csv);
        return;
    }

    // API: Save Cutout Transparent Krathong PNGs
    if (pathname === '/api/save-cutout' && req.method === 'POST') {
        let body = '';
        req.on('data', chunk => body += chunk);
        req.on('end', () => {
            try {
                const { key, dataUrl } = JSON.parse(body);
                if (key && dataUrl) {
                    const base64 = dataUrl.replace(/^data:image\/png;base64,/, '');
                    const dest = path.join(PUBLIC_DIR, 'assets', 'images', `${key}.png`);
                    fs.writeFileSync(dest, Buffer.from(base64, 'base64'));
                    console.log(`[Asset] Saved transparent cutout: ${key}.png`);
                }
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ ok: true }));
            } catch (e) {
                res.writeHead(500, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ error: e.message }));
            }
        });
        return;
    }

    // API: Clear pond (Admin)
    if (pathname === '/api/clear' && req.method === 'POST') {
        krathongs = [];
        saveKrathongs();
        broadcastEvent('clear_pond', { timestamp: Date.now() });
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: true, message: 'ล้างสระน้ำเรียบร้อยแล้ว' }));
        return;
    }

    // Static File Serving
    let safePath = path.normalize(pathname).replace(/^(\.\.[\/\\])+/, '');
    if (safePath === '/' || safePath === '\\') {
        const userAgent = req.headers['user-agent'] || '';
        const isMobile = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(userAgent);
        safePath = isMobile ? '/mobile.html' : '/display.html';
    }

    let filePath = path.join(PUBLIC_DIR, safePath);

    fs.stat(filePath, (err, stats) => {
        if (err || !stats.isFile()) {
            res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
            res.end('404 Not Found - ท่าอากาศยานตรัง');
            return;
        }

        const ext = path.extname(filePath).toLowerCase();
        const contentType = MIME_TYPES[ext] || 'application/octet-stream';

        // Dynamically inject absolute Open Graph URLs for Facebook & Social Crawlers on mobile.html
        if (filePath.endsWith('mobile.html')) {
            fs.readFile(filePath, 'utf8', (readErr, content) => {
                if (readErr) {
                    res.writeHead(500);
                    res.end('Error loading mobile.html');
                    return;
                }
                const proto = req.headers['x-forwarded-proto'] || 'https';
                const host = req.headers.host || `localhost:${PORT}`;
                const absoluteOrigin = `${proto}://${host}`;
                const modified = content
                    .replace(/content="assets\/images\/card_template_trang\.jpg"/g, `content="${absoluteOrigin}/assets/images/card_template_trang.jpg"`)
                    .replace(/<meta property="og:url"[^>]*>/g, `<meta property="og:url" content="${absoluteOrigin}/mobile.html">`);
                res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
                res.end(modified);
            });
            return;
        }

        res.writeHead(200, { 'Content-Type': contentType });
        const stream = fs.createReadStream(filePath);
        stream.on('error', () => {
            if (!res.headersSent) res.writeHead(500);
            res.end();
        });
        res.on('error', () => {
            stream.destroy();
        });
        stream.pipe(res);
    });
});

server.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
        console.log(`[Server] Port ${PORT} already running and active.`);
    } else {
        console.error('[Server Error]:', err);
    }
});

setInterval(() => {
    broadcastEvent('ping', { time: Date.now() });
}, 15000);

server.listen(PORT, '0.0.0.0', () => {
    console.log(`
========================================================================
  🌕 TRANG AIRPORT - LOY KRATHONG ONLINE 2026 🪷
  เทศกาลลอยกระทงออนไลน์ ท่าอากาศยานตรัง
========================================================================
  🖥️  จอใหญ่สระน้ำ (Big Screen):
      http://localhost:${PORT}/display.html

  📱  จอมือถือ (Local Wi-Fi):
      http://${localIP}:${PORT}/mobile.html
========================================================================
`);
    startTunnel();
});
