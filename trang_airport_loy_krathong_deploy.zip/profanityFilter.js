/**
 * Profanity & Threat Filter for Trang Airport Loy Krathong 2026
 * Filters inappropriate, vulgar, obscene, or security-sensitive words silently in the background.
 */

const THAI_PATTERNS = [
  // เย็ด / เยด / เย็ดแม่
  /เย็[\s._\-*]*ด[\s._\-*]*แม่+/gi,
  /เย[\s._\-*]*ด[\s._\-*]*แม่+/gi,
  /เ[\s._\-*]*ย็[\s._\-*]*ด+/gi,
  /เ[\s._\-*]*ย[\s._\-*]*ด+/gi,
  /ยสตน+/gi,

  // ควย and variations
  /ค[\s._\-*]*ว[\s._\-*]*ย+/gi,
  /ค[\s._\-*]*ว[\s._\-*]*อ[\s._\-*]*ย+/gi,
  /ไอ้[\s._\-*]*ควย/gi,
  /อี[\s._\-*]*ควย/gi,
  /ค\.ว\.ย\./gi,
  /อม[\s._\-*]*ควย+/gi,
  /ดูด[\s._\-*]*ควย+/gi,
  /แดก[\s._\-*]*ควย+/gi,
  /เลีย[\s._\-*]*ควย+/gi,
  
  // เหี้ย and variations
  /เ[\s._\-*]*หี้[\s._\-*]*ย+/gi,
  /เ[\s._\-*]*หี[\s._\-*]*ย+/gi,
  /เ[\s._\-*]*ห้[\s._\-*]*ย+/gi,
  /ห[\s._\-*]*ยี่[\s._\-*]*ย+/gi,
  /ไอ้[\s._\-*]*เหี้ย/gi,
  /อี[\s._\-*]*เหี้ย/gi,
  
  // สัส / สัตว์ / สัด
  /สั[\s._\-*]*ส+/gi,
  /สั[\s._\-*]*ด+/gi,
  /ไอ้[\s._\-*]*สัส/gi,
  /อี[\s._\-*]*สัส/gi,
  /ไอ้[\s._\-*]*สัด/gi,
  /อี[\s._\-*]*สัด/gi,
  
  // หี / แตด / ลามก
  /หี[\s._\-*]*แฉะ+/gi,
  /หี+/gi,
  /แตด+/gi,
  /หำ+/gi,
  /จู๋+/gi,
  /เงี่ยน+/gi,
  /นมโต+/gi,
  /แตก[\s._\-*]*ใน+/gi,
  
  // ดอก / ดอ / ห่า
  /ดอ[\s._\-*]*ก[\s._\-*]*ทอ[\s._\-*]*ง/gi,
  /อี[\s._\-*]*ดอ[\s._\-*]*ก+/gi,
  /อี่[\s._\-*]*ดอ[\s._\-*]*ก+/gi,
  /อี[\s._\-*]*ห่า+/gi,
  /ไอ้[\s._\-*]*ห่า+/gi,
  /ห่า[\s._\-*]*ราก+/gi,
  
  // ส้นตีน / หน้าตัวเมีย / จัญไร / ชาติหมา / ระยำ / ด่าทอ
  /ส้น[\s._\-*]*ตี[\s._\-*]*น+/gi,
  /หน้า[\s._\-*]*ตัว[\s._\-*]*เมีย/gi,
  /ชาติ[\s._\-*]*หมา/gi,
  /ชาติ[\s._\-*]*ชั่ว/gi,
  /จัญ[\s._\-*]*ไร+/gi,
  /ระ[\s._\-*]*ยำ+/gi,
  /เสนียด+/gi,
  /สถุล+/gi,
  /แม่[\s._\-*]*มึง[\s._\-*]*ตาย+/gi,
  /พ่อ[\s._\-*]*มึง[\s._\-*]*ตาย+/gi,
  /มึง[\s._\-*]*ตาย+/gi,
  /ไป[\s._\-*]*ตาย+/gi,
  /ไอ้[\s._\-*]*เวร+/gi,
  /ควาย+/gi,
  /กู+/gi,
  /มึง+/gi,
  
  // Security / airport sensitive threats
  /วาง[\s._\-*]*ระ[\s._\-*]*เบิด+/gi,
  /ระ[\s._\-*]*เบิด+/gi,
  /บึ้ม+/gi,
  /ปล้น[\s._\-*]*เครื่อง[\s._\-*]*บิน+/gi,
  /ก่อ[\s._\-*]*การ[\s._\-*]*ร้าย+/gi
];

const ENGLISH_PATTERNS = [
  /\bf+[\s._\-*]*u+[\s._\-*]*c+[\s._\-*]*k+[\w]*/gi,
  /\bs+[\s._\-*]*h+[\s._\-*]*i+[\s._\-*]*t+[\w]*/gi,
  /\bb+[\s._\-*]*i+[\s._\-*]*t+[\s._\-*]*c+[\s._\-*]*h+[\w]*/gi,
  /\bc+[\s._\-*]*u+[\s._\-*]*n+[\s._\-*]*t+[\w]*/gi,
  /\bd+[\s._\-*]*i+[\s._\-*]*c+[\s._\-*]*k+[\w]*/gi,
  /\bp+[\s._\-*]*u+[\s._\-*]*s+[\s._\-*]*s+[\s._\-*]*y+[\w]*/gi,
  /\ba+[\s._\-*]*s+[\s._\-*]*s+[\s._\-*]*h+[\s._\-*]*o+[\s._\-*]*l+[\s._\-*]*e+[\w]*/gi,
  /\bb+[\s._\-*]*a+[\s._\-*]*s+[\s._\-*]*t+[\s._\-*]*a+[\s._\-*]*r+[\s._\-*]*d+[\w]*/gi,
  /\bs+[\s._\-*]*l+[\s._\-*]*u+[\s._\-*]*t+[\w]*/gi,
  /\bw+[\s._\-*]*h+[\s._\-*]*o+[\s._\-*]*r+[\s._\-*]*e+[\w]*/gi,
  /\bb+[\s._\-*]*o+[\s._\-*]*m+[\s._\-*]*b+[\w]*/gi,
  /\bt+[\s._\-*]*e+[\s._\-*]*r+[\s._\-*]*r+[\s._\-*]*o+[\s._\-*]*r+[\s._\-*]*i+[\s._\-*]*s+[\s._\-*]*t+[\w]*/gi,
  /\bh+[\s._\-*]*i+[\s._\-*]*j+[\s._\-*]*a+[\s._\-*]*c+[\s._\-*]*k+[\w]*/gi
];

function sanitizeText(text, fallback = '') {
  if (!text || typeof text !== 'string') return fallback;

  let cleaned = text.trim();

  // 1. Filter Thai patterns
  for (const pattern of THAI_PATTERNS) {
    cleaned = cleaned.replace(pattern, '***');
  }

  // 2. Filter English patterns
  for (const pattern of ENGLISH_PATTERNS) {
    cleaned = cleaned.replace(pattern, '***');
  }

  // 3. If the entire text was offensive (now just symbols/asterisks)
  const remainingRealChars = cleaned.replace(/[*_.\-\s()]/g, '');
  if (remainingRealChars.length === 0) {
    return fallback;
  }

  return cleaned;
}

function filterKrathongInput(senderName, wishText) {
  const cleanName = sanitizeText(
    senderName, 
    'ผู้โดยสารท่าอากาศยานตรัง'
  ).slice(0, 40);

  const cleanWish = sanitizeText(
    wishText, 
    'ขอให้มีความสุข ความเจริญ และเดินทางปลอดภัยทุกเส้นทาง'
  ).slice(0, 200);

  return {
    senderName: cleanName,
    wishText: cleanWish
  };
}

module.exports = {
  sanitizeText,
  filterKrathongInput
};
